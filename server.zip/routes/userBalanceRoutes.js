const express = require('express');
const UserBalanceController = require('../controllers/UserBalanceController');
const {isUser, isAdmin} = require('../middleware/authMiddleware');
const router = express.Router();

console.log('Registering user balance routes');


router.get('/', isAdmin, UserBalanceController.findAll);
router.get('/:id', isUser, UserBalanceController.findById);


module.exports = router;