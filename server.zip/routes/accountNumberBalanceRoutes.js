const express = require('express');
const AccountNumberBalanceController = require('../controllers/AccountNumberBalanceController');
const {isAdmin} = require('../middleware/authMiddleware');

const router = express.Router();

// Account Number Balance Routes
router.post('/', isAdmin, AccountNumberBalanceController.create);
router.get('/', isAdmin, AccountNumberBalanceController.findAll);
router.get('/:id', isAdmin, AccountNumberBalanceController.findById);
router.put('/:id', isAdmin, AccountNumberBalanceController.update);
router.delete('/:id', isAdmin, AccountNumberBalanceController.delete);

module.exports = router;