const express = require('express');
const P2PLimitController = require('../controllers/P2PLimitController');
const { isAdmin} = require('../middleware/authMiddleware');
const router = express.Router();


// Debug: Log route registrations
console.log('Registering p2p limit routes');
console.log('P2PLimitController methods:', Object.keys(P2PLimitController));

router.post('/', isAdmin, P2PLimitController.create.bind(P2PLimitController));
router.get('/', isAdmin, P2PLimitController.findAll.bind(P2PLimitController));
router.put('/:id', isAdmin, P2PLimitController.update.bind(P2PLimitController));
router.delete('/:id', isAdmin, P2PLimitController.delete.bind(P2PLimitController));



module.exports = router;