const express = require('express');
const router = express.Router();
const P2PTradingController = require('../controllers/P2PTradingController');
const {isAdmin, isUser, isUserOrAdmin} = require('../middleware/authMiddleware');
console.log('Registering P2P trading routes');


// Get user's P2P offers
router.get('/offers/p2p', isUserOrAdmin, P2PTradingController.getUserP2POffers);

// Get The P2P transaction History
router.get('/', isAdmin, P2PTradingController.getHistory);

// Seller creates a sell offer
router.post('/sell', isUser, P2PTradingController.createSellOffer);

// Anyone can view pending (active) sell offers
router.get('/offers', isUserOrAdmin, P2PTradingController.getPendingOffers);

// A buyer purchases an offer by its id
router.post('/offers/:id/buy', isUser, P2PTradingController.buyOffer);

// Get user's approved offers
router.get('/p2p_approved_offers/', isUserOrAdmin, P2PTradingController.getUserApprovedOffers);



module.exports = router;