const express = require('express');
const UserGiveAwayHistoryController = require('../controllers/UserGiveAwayHistoryController');
const { isAdmin, isUser , isUserOrAdmin} = require('../middleware/authMiddleware');
const router = express.Router();


// Debug: Log route registrations
console.log('Registering user give away history routes');
console.log('UserGiveAwayHistoryController methods:', Object.keys(UserGiveAwayHistoryController));

router.post('/', isUser, UserGiveAwayHistoryController.create.bind(UserGiveAwayHistoryController));
router.get('/', isUserOrAdmin, UserGiveAwayHistoryController.findAll.bind(UserGiveAwayHistoryController));
router.put('/:id', isAdmin, UserGiveAwayHistoryController.update.bind(UserGiveAwayHistoryController));
// router.delete('/:id', isAdmin, UserGiveAwayHistoryController.delete.bind(UserGiveAwayHistoryController));
router.get('/by_user/', isUser, UserGiveAwayHistoryController.findByUserId.bind(UserGiveAwayHistoryController));


module.exports = router;