const express = require('express');
const CashWithdrawController = require('../controllers/CashWithdrawController');
const rateLimit = require('express-rate-limit');
const {isUser, isAdmin} = require('../middleware/authMiddleware');
const router = express.Router();

// Custom key generator function to use the user's ID as the rate limit key
const userKeyGenerator = (req) => {
  if (req.user && req.user.id) {
    return `user_${req.user.id}`;
  }
  return 'guest';
};

// User-based rate limiter
const userWithdrawLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 105,
  keyGenerator: userKeyGenerator,
  message: 'Too many withdrawal attempts. Please try again later.'
});


// Admin-based rate limiter
const adminStatusUpdateLimiter = rateLimit({
  windowMs: 2 * 60 * 1000, // 2 minutes
  max: 100,
  keyGenerator: userKeyGenerator,
  message: 'Too many status update attempts. Please try again later.'
});

router.post('/', isUser,  userWithdrawLimiter, CashWithdrawController.create.bind(CashWithdrawController));
router.get('/',isAdmin, CashWithdrawController.findAll.bind(CashWithdrawController));
router.put('/:id/status', isAdmin, adminStatusUpdateLimiter, CashWithdrawController.updateStatus.bind(CashWithdrawController));
router.get('/user/:user_id', isUser, CashWithdrawController.getUserWithdrawals.bind(CashWithdrawController));

module.exports = router;