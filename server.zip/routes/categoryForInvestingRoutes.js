const express = require('express');
const CategoryForInvestingController = require('../controllers/CategoryForInvestingController');
const {isAdmin} = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/', isAdmin, CategoryForInvestingController.create);
router.put('/:id', isAdmin, CategoryForInvestingController.update);
router.get('/', isAdmin, CategoryForInvestingController.findAll);
router.delete('/:id', isAdmin, CategoryForInvestingController.delete);


module.exports = router;