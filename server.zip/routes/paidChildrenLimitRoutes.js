const express = require('express');
const PaidChildrenLimitController = require('../controllers/PaidChildrenLimitController');
const {isAdmin} = require('../middleware/authMiddleware');
const router = express.Router();


// Debug: Log route registrations
console.log('Registering paid children limit routes');
console.log('PaidChildrenLimitController methods:', Object.keys(PaidChildrenLimitController));

router.post('/', isAdmin, PaidChildrenLimitController.create.bind(PaidChildrenLimitController));
router.get('/', isAdmin, PaidChildrenLimitController.findAll.bind(PaidChildrenLimitController));
router.get('/:id', isAdmin, PaidChildrenLimitController.findById.bind(PaidChildrenLimitController));
router.put('/:id', isAdmin, PaidChildrenLimitController.update.bind(PaidChildrenLimitController));
router.delete('/:id', isAdmin, PaidChildrenLimitController.delete.bind(PaidChildrenLimitController));



module.exports = router;