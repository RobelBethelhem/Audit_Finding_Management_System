const express = require('express');
const UserController = require('../controllers/UserController');
const passport = require('passport');
const router = express.Router();
const { isUser, isAdmin } = require('../middleware/authMiddleware');


// Debug: Log route registrations
console.log('Registering user routes');
console.log('UserController methods:', Object.keys(UserController));

router.get('/check-auth', (req,res) =>{
  if (req.isAuthenticated()) {
    res.json({ isAuthenticated: true, user: req.user });
  } 
  else {
    res.json({ isAuthenticated: false });
  }
})  
router.get('/transaction-history', isUser, UserController.getTransactionHistory);

router.get('/userDashData', isUser, UserController.getUserDashData);
router.get('/top-users', isUser, UserController.getTopUsersByTeamSize);

router.post('/referral-tree', isUser, UserController.getReferralTree);
router.get('/referral-tree/:id', isAdmin, UserController.getReferralTreeById);
router.post('/give-up/:userId', isUser, UserController.giveUp);
router.post('/can-sell', isUser, UserController.UserCanSellCoin);
router.post('/paid-referral-commissions', isUser, UserController.getPaidReferralCommissions);

router.post('/', (req, res) => {
    console.log('POST / route called');
    if (UserController.register) {
      UserController.register(req, res);
    } else {
      console.error('register method is undefined');
      res.status(500).json({ error: 'Internal server error' });
    }
  });






router.post('/logout', (req, res, next) => {
  req.logout(function(err) {
    if (err) {
      return next(err);
    }
    res.json({ message: 'Logout successful' });
  });
});

router.get('/', isAdmin, UserController.findAll);
router.get('/user_detail/:id', isAdmin, UserController.findById);
router.put('/', isUser, UserController.update);
router.delete('/:id', isUser, UserController.delete);
router.post('/login', passport.authenticate('local-user'), UserController.login);





module.exports = router;