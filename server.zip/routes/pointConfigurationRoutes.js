const express = require('express');
const PointConfigurationController = require('../controllers/PointConfigurationController');
const {isUser, isAdmin} = require('../middleware/authMiddleware');
const router = express.Router();


router.post('/', isAdmin, PointConfigurationController.create.bind(PointConfigurationController));
router.get('/', isAdmin, PointConfigurationController.findAll.bind(PointConfigurationController));
router.get('/', isAdmin, PointConfigurationController.findById.bind(PointConfigurationController));
router.put('/:id', isAdmin, PointConfigurationController.update.bind(PointConfigurationController));
router.delete('/:id', isAdmin, PointConfigurationController.delete.bind(PointConfigurationController));





module.exports = router;