const express = require('express');
const UserTaskSubmissionController = require('../controllers/UserTaskSubmissionController');
const {isUser} = require('../middleware/authMiddleware');
const router = express.Router();

// Debug: Log route registrations
console.log('Registering user task submission routes');

router.post('/submit', isUser, UserTaskSubmissionController.submitTaskAnswer.bind(UserTaskSubmissionController));
router.get('/point-balance/:user_id', isUser, UserTaskSubmissionController.getUserPointBalance.bind(UserTaskSubmissionController));
router.get('/history/:user_id', isUser, UserTaskSubmissionController.getUserTaskHistory.bind(UserTaskSubmissionController));

module.exports = router;