const express = require('express');
const LevelController = require('../controllers/LevelController');
const { isAdmin, isUser , isUserOrAdmin} = require('../middleware/authMiddleware');
const router = express.Router();


// Debug: Log route registrations
console.log('Registering level routes');
console.log('LevelController methods:', Object.keys(LevelController));

router.post('/', isAdmin, LevelController.create.bind(LevelController));
router.get('/', isUserOrAdmin, LevelController.findAll.bind(LevelController));
router.get('/:id', isAdmin, LevelController.findById.bind(LevelController));
router.put('/:id', isAdmin, LevelController.update.bind(LevelController));
router.delete('/:id', isAdmin, LevelController.delete.bind(LevelController));



module.exports = router;