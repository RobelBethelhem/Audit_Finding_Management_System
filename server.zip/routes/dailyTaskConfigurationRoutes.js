const express = require('express');
const DailyTaskConfigurationController = require('../controllers/DailyTaskConfigurationController');
const {isAdmin} = require('../middleware/authMiddleware');
const router = express.Router();

// Debug: Log route registrations
console.log('Registering daily task configuration routes');

router.post('/', isAdmin, DailyTaskConfigurationController.create.bind(DailyTaskConfigurationController));
router.get('/', isAdmin, DailyTaskConfigurationController.findAll.bind(DailyTaskConfigurationController));
router.get('/:id', isAdmin, DailyTaskConfigurationController.findById.bind(DailyTaskConfigurationController));
router.put('/:id', isAdmin, DailyTaskConfigurationController.update.bind(DailyTaskConfigurationController));
router.delete('/:id', isAdmin, DailyTaskConfigurationController.delete.bind(DailyTaskConfigurationController));

module.exports = router;