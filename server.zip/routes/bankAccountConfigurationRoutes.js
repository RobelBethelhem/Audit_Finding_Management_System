const express = require('express');
const BankAccountConfigurationController = require('../controllers/BankAccountConfigurationController');
const {isAdmin, isUser} = require('../middleware/authMiddleware');
const router = express.Router();


router.post('/getBankAccount', BankAccountConfigurationController.getBankAccountForAmount);
router.post('/', isAdmin, BankAccountConfigurationController.create);
router.get('/', isAdmin, BankAccountConfigurationController.findAll);
router.get('/:id', isAdmin, BankAccountConfigurationController.findById);
router.put('/:id', isAdmin, BankAccountConfigurationController.update);
router.delete('/:id', isAdmin, BankAccountConfigurationController.delete);

module.exports = router;