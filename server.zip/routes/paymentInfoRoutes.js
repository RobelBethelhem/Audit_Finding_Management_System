const express = require('express');
const PaymentInformationController = require('../controllers/PaymentInformationController');
const {isUser, isAdmin} = require('../middleware/authMiddleware');
const router = express.Router();


// Debug: Log route registrations
console.log('Registering payment information routes');
console.log('PaymentInformationController methods:', Object.keys(PaymentInformationController));

router.post('/', isUser, PaymentInformationController.create.bind(PaymentInformationController));
router.get('/', isAdmin, PaymentInformationController.findAll.bind(PaymentInformationController));
router.get('/', isUser, PaymentInformationController.findById.bind(PaymentInformationController));
router.put('/:id', isUser, PaymentInformationController.update.bind(PaymentInformationController));
router.delete('/:id', isUser, PaymentInformationController.delete.bind(PaymentInformationController));
router.get('/user', isUser, PaymentInformationController.findByUserId.bind(PaymentInformationController));
//router.post('/generate-payment-link', isUser, PaymentInformationController.generatePaymentLink.bind(PaymentInformationController));


module.exports = router;