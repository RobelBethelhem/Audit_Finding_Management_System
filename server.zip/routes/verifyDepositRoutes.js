const express = require('express');
const VerifyDepositController = require('../controllers/VerifyDepositController');
const multer = require('multer');
const {isAdmin, isUser, isUserOrAdmin} = require('../middleware/authMiddleware');
const router = express.Router();
const upload = multer();

console.log('Registering verify deposit routes');

router.post('/', isUser, upload.single('payment_receipt'), VerifyDepositController.create);
router.get('/', isAdmin, VerifyDepositController.findAll);
router.get('/:id', isUserOrAdmin, VerifyDepositController.findById);
router.put('/:id', isAdmin, upload.single('payment_receipt'), VerifyDepositController.update);
router.delete('/:id', isAdmin, VerifyDepositController.delete);

module.exports = router;