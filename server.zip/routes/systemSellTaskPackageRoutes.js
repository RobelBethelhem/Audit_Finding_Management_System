const express = require('express');
const SystemSellTaskPackageController = require('../controllers/SystemSellTaskPackageController');
const { isAdmin, isUser , isUserOrAdmin} = require('../middleware/authMiddleware');
const router = express.Router();


// Debug: Log route registrations
console.log('Registering system sell task package routes');
console.log('SystemSellTaskPackageController methods:', Object.keys(SystemSellTaskPackageController));

router.post('/', isAdmin, SystemSellTaskPackageController.create.bind(SystemSellTaskPackageController));
router.get('/', isUserOrAdmin, SystemSellTaskPackageController.findAll.bind(SystemSellTaskPackageController));
router.put('/:id', isAdmin, SystemSellTaskPackageController.update.bind(SystemSellTaskPackageController));
router.delete('/:id', isAdmin, SystemSellTaskPackageController.delete.bind(SystemSellTaskPackageController));



module.exports = router;