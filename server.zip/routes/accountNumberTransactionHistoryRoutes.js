const express = require('express');
const AccountNumberTransactionHistoryController = require('../controllers/AccountNumberTransactionHistoryController');
const {isAdmin} = require('../middleware/authMiddleware');
const router = express.Router();

// Account Number Transaction History Routes
router.post('/', isAdmin,  AccountNumberTransactionHistoryController.create);
router.get('/get_by_account/:bank_account_configuration_id',  AccountNumberTransactionHistoryController.getByAccount);
router.get('/', isAdmin,  AccountNumberTransactionHistoryController.findAll);
router.get('/:id', isAdmin, AccountNumberTransactionHistoryController.findById);
router.put('/:id', isAdmin, AccountNumberTransactionHistoryController.update);
router.delete('/:id', isAdmin, AccountNumberTransactionHistoryController.delete);

module.exports = router;