const express = require('express');
const DailyTaskGameController = require('../controllers/DailyTaskGameController');
const {isAdmin, isUser, isUserOrAdmin} = require('../middleware/authMiddleware');
const { checkPuzzleSequence } = require('../controllers/CheckPuzzleSequence');

const router = express.Router();

// Debug: Log route registrations
console.log('Registering daily task game routes');

router.post('/', isAdmin, DailyTaskGameController.create.bind(DailyTaskGameController));
router.get('/', isUserOrAdmin, DailyTaskGameController.findAll.bind(DailyTaskGameController));
router.post('/user/check-puzzle-sequence', isUserOrAdmin, checkPuzzleSequence);
router.get('/cipher-hint', isUserOrAdmin, DailyTaskGameController.getCipherHint.bind(DailyTaskGameController));
router.get('/active', isUserOrAdmin, DailyTaskGameController.getActiveGames.bind(DailyTaskGameController));
router.get('/:id', isUserOrAdmin, DailyTaskGameController.findById.bind(DailyTaskGameController));
router.put('/:id', isAdmin, DailyTaskGameController.update.bind(DailyTaskGameController));
router.delete('/:id', isAdmin, DailyTaskGameController.delete.bind(DailyTaskGameController));
router.post('/expire-all', isAdmin, DailyTaskGameController.expireAllGames.bind(DailyTaskGameController));

module.exports = router;