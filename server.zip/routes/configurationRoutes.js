const express = require('express');
const router = express.Router();
const {Configuration, sequelize} = require('../models');
const {isAdmin} = require('../middleware/authMiddleware');

router.use(express.json());

// GET all configurations (or by category)
router.get('/config',isAdmin, async (req, res) => {
  const categoryFilter = req.query.category;
  let whereClause = {};
  if (categoryFilter) {
    whereClause = { category: categoryFilter };
  }
  try {
    const configurations = await Configuration.findAll({ where: whereClause });
    res.json(configurations);
  } catch (error) {
    console.error('Error fetching configurations:', error);
    res.status(500).json({ error: 'Failed to fetch configurations' });
  }
});

// GET configuration by key
router.get('/config/:key', isAdmin, async (req, res) => {
  const configKey = req.params.key;
  try {
    const configuration = await Configuration.findOne({ where: { configKey } });
    if (configuration) {
      res.json(configuration);
    } else {
      res.status(404).json({ message: 'Configuration not found' });
    }
  } catch (error) {
    console.error('Error fetching configuration:', error);
    res.status(500).json({ error: 'Failed to fetch configuration' });
  }
});

// POST new configuration
router.post('/config',isAdmin, async (req, res) => {
  const { configKey, configValue, category, description } = req.body;
  if (!configKey || configValue === undefined) { // Basic validation
    return res.status(400).json({ error: 'configKey and configValue are required' });
  }
  try {
    JSON.parse(JSON.stringify(configValue)); // Try to parse to validate JSON
    await Configuration.create({ configKey, configValue: JSON.stringify(configValue), category, description });
    res.status(201).json({ message: 'Configuration created successfully' });
  } catch (error) {
    console.error('Error creating configuration:', error);
    if (error instanceof SyntaxError) {
      return res.status(400).json({ error: 'Invalid JSON in configValue' });
    }
    res.status(500).json({ error: 'Failed to create configuration', details: error.errors });
  }
});

// PUT update configuration
router.put('/config/:key', isAdmin,  async (req, res) => {
  const configKey = req.params.key;
  const { configValue, category, description } = req.body;
  if (configValue === undefined) {
    return res.status(400).json({ error: 'configValue is required for update' });
  }
  try {
    JSON.parse(JSON.stringify(configValue)); // Validate JSON
    const configuration = await Configuration.findOne({ where: { configKey } });
    if (configuration) {
      await configuration.update({ configValue: JSON.stringify(configValue), category, description });
      res.json({ message: 'Configuration updated successfully' });
    } else {
      res.status(404).json({ message: 'Configuration not found' });
    }
  } catch (error) {
    console.error('Error updating configuration:', error);
    if (error instanceof SyntaxError) {
      return res.status(400).json({ error: 'Invalid JSON in configValue' });
    }
    res.status(500).json({ error: 'Failed to update configuration', details: error.errors });
  }
});

// DELETE configuration
router.delete('/config/:key', isAdmin, async (req, res) => {
  const configKey = req.params.key;
  try {
    const configuration = await Configuration.findOne({ where: { configKey } });
    if (configuration) {
      await configuration.destroy();
      res.json({ message: 'Configuration deleted successfully' });
    } else {
      res.status(404).json({ message: 'Configuration not found' });
    }
  } catch (error) {
    console.error('Error deleting configuration:', error);
    res.status(500).json({ error: 'Failed to delete configuration' });
  }
});

module.exports = router;