const express = require('express');
const UserAssignedToSystemSellTaskPackageController = require('../controllers/UserAssignedToSystemSellTaskPackageController');
const { isAdmin, isUser , isUserOrAdmin} = require('../middleware/authMiddleware');
const router = express.Router();


// Debug: Log route registrations
console.log('Registering user assigned to system sell task package routes');
console.log('UserAssignedToSystemSellTaskPackageController methods:', Object.keys(UserAssignedToSystemSellTaskPackageController));

router.post('/', isAdmin, UserAssignedToSystemSellTaskPackageController.create.bind(UserAssignedToSystemSellTaskPackageController));
router.get('/', isUserOrAdmin, UserAssignedToSystemSellTaskPackageController.findAll.bind(UserAssignedToSystemSellTaskPackageController));
router.put('/:id', isAdmin, UserAssignedToSystemSellTaskPackageController.update.bind(UserAssignedToSystemSellTaskPackageController));
router.delete('/:id', isAdmin, UserAssignedToSystemSellTaskPackageController.delete.bind(UserAssignedToSystemSellTaskPackageController));



module.exports = router;