const express = require('express');
const GLTransactionController = require('../controllers/GLTransactionController');
const {isAdmin} = require('../middleware/authMiddleware');
const router = express.Router();

// GL Account Routes
router.post('/', isAdmin, GLTransactionController.createTransaction);
router.get('/', isAdmin, GLTransactionController.findAll);
router.get('/:id', isAdmin, GLTransactionController.findById);
router.put('/:id', isAdmin, GLTransactionController.updateStatus);
router.delete('/:id', isAdmin, GLTransactionController.delete);

module.exports = router;