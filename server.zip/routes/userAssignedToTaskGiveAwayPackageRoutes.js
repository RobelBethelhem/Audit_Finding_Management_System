const express = require('express');
const UserAssignedToTaskGiveAwayPackageController = require('../controllers/UserAssignedToTaskGiveAwayPackageController');
const { isAdmin, isUser , isUserOrAdmin} = require('../middleware/authMiddleware');
const router = express.Router();


// Debug: Log route registrations
console.log('Registering user assigned to task give away package routes');
console.log('UserAssignedToTaskGiveAwayPackageController methods:', Object.keys(UserAssignedToTaskGiveAwayPackageController));

router.post('/', isAdmin, UserAssignedToTaskGiveAwayPackageController.create.bind(UserAssignedToTaskGiveAwayPackageController));
router.get('/', isUserOrAdmin, UserAssignedToTaskGiveAwayPackageController.findAll.bind(UserAssignedToTaskGiveAwayPackageController));
router.put('/:id', isAdmin, UserAssignedToTaskGiveAwayPackageController.update.bind(UserAssignedToTaskGiveAwayPackageController));
router.delete('/:id', isAdmin, UserAssignedToTaskGiveAwayPackageController.delete.bind(UserAssignedToTaskGiveAwayPackageController));



module.exports = router;