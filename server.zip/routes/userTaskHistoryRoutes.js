const express = require('express');
const UserTaskHistoryController = require('../controllers/UserTaskHistoryController');
const { isAdmin, isUser , isUserOrAdmin} = require('../middleware/authMiddleware');
const router = express.Router();


// Debug: Log route registrations
console.log('Registering user task history routes');
console.log('UserTaskHistoryController methods:', Object.keys(UserTaskHistoryController));

router.post('/', isUser, UserTaskHistoryController.create.bind(UserTaskHistoryController));
router.get('/', isUserOrAdmin, UserTaskHistoryController.findAll.bind(UserTaskHistoryController));
router.put('/:id', isAdmin, UserTaskHistoryController.update.bind(UserTaskHistoryController));
// router.delete('/:id', isAdmin, UserTaskHistoryController.delete.bind(UserTaskHistoryController));
router.get('/by_user/', isUser, UserTaskHistoryController.findByUserId.bind(UserTaskHistoryController));


module.exports = router;