const express = require('express');
const P2PSellBuyConfigurationController = require('../controllers/P2PSellBuyConfigurationController');
const { isAdmin} = require('../middleware/authMiddleware');
const router = express.Router();


// Debug: Log route registrations
console.log('Registering p2p sell buy configuration routes');
console.log('P2PSellBuyConfigurationController methods:', Object.keys(P2PSellBuyConfigurationController));

router.post('/', isAdmin, P2PSellBuyConfigurationController.create.bind(P2PSellBuyConfigurationController));
router.get('/', isAdmin, P2PSellBuyConfigurationController.findAll.bind(P2PSellBuyConfigurationController));
router.put('/:id', isAdmin, P2PSellBuyConfigurationController.update.bind(P2PSellBuyConfigurationController));
router.delete('/:id', isAdmin, P2PSellBuyConfigurationController.delete.bind(P2PSellBuyConfigurationController));



module.exports = router;