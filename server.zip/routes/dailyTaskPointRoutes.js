const express = require('express');
const DailyTaskPointController = require('../controllers/DailyTaskPointController');
const {isAdmin, isUser, isUserOrAdmin} = require('../middleware/authMiddleware');
const router = express.Router();

// Debug: Log route registrations
console.log('Registering daily task point routes');

router.post('/', isAdmin, DailyTaskPointController.create.bind(DailyTaskPointController));
router.get('/', isAdmin, DailyTaskPointController.findAll.bind(DailyTaskPointController));
router.get('/:id', isAdmin, DailyTaskPointController.findById.bind(DailyTaskPointController));
router.put('/:id', isAdmin, DailyTaskPointController.update.bind(DailyTaskPointController));
router.delete('/:id', isAdmin, DailyTaskPointController.delete.bind(DailyTaskPointController));

module.exports = router;