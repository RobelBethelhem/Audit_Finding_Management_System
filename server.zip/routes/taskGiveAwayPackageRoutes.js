const express = require('express');
const TaskGiveAwayPackageController = require('../controllers/TaskGiveAwayPackageController');
const { isAdmin, isUser , isUserOrAdmin} = require('../middleware/authMiddleware');
const router = express.Router();


// Debug: Log route registrations
console.log('Registering task give away package routes');
console.log('TaskGiveAwayPackageController methods:', Object.keys(TaskGiveAwayPackageController));

router.post('/', isAdmin, TaskGiveAwayPackageController.create.bind(TaskGiveAwayPackageController));
router.get('/', isUserOrAdmin, TaskGiveAwayPackageController.findAll.bind(TaskGiveAwayPackageController));
router.put('/:id', isAdmin, TaskGiveAwayPackageController.update.bind(TaskGiveAwayPackageController));
router.delete('/:id', isAdmin, TaskGiveAwayPackageController.delete.bind(TaskGiveAwayPackageController));



module.exports = router;