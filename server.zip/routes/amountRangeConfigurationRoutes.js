const express = require('express');
const AmountRangeConfigurationController = require('../controllers/AmountRangeConfigurationController');
const {isAdmin} = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/', isAdmin, AmountRangeConfigurationController.create);
router.get('/', isAdmin, AmountRangeConfigurationController.findAll);
router.get('/:id', isAdmin, AmountRangeConfigurationController.findById);
router.put('/:id',isAdmin, AmountRangeConfigurationController.update);
router.delete('/:id', isAdmin, AmountRangeConfigurationController.delete);

module.exports = router;