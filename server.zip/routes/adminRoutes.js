
const express = require('express');
const AdminController = require('../controllers/AdminController');
const passport = require('passport');
const router = express.Router();
const { isAdmin } = require('../middleware/authMiddleware');


// Admin Registration
router.get('/check-auth', (req,res) =>{
    if (req.isAuthenticated()) {
      res.json({ isAuthenticated: true, user: req.user });
    } 
    else {
      res.json({ isAuthenticated: false });
    }
  }) 


  router.post('/logout', (req, res, next) => {
    req.logout(function(err) {
      if (err) {
        return next(err);
      }
      res.json({ message: 'Logout successful' });
    });
  });

router.post('/', isAdmin, AdminController.register);
router.post('/login', passport.authenticate('local-admin'), AdminController.login);
router.post('/change-password', isAdmin, AdminController.changePassword);
router.get('/', isAdmin, AdminController.findAll);
router.get('/:id', isAdmin,  AdminController.findById);
router.put('/:id', isAdmin,  AdminController.update);
router.delete('/:id', isAdmin,  AdminController.delete);

module.exports = router;