const express = require('express');
const WithdrawInformationController = require('../controllers/WithdrawInformationController');
const rateLimit = require('express-rate-limit');
const {isUser, isAdmin, isUserOrAdmin} = require('../middleware/authMiddleware');
const router = express.Router();




/* const passwordChangeLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, 
    max: 5, 
    keyGenerator: (req) => {
      // Get the user's ID from the request (adjust based on your auth setup)
      const userId = req.user?.id || req.body?.user_id; // Example: Get from auth or body
      if (!userId) {
        // Fallback to IP if no user ID (adjust as needed)
        return req.ip;
      }
      return userId; // Unique key per user
    },
    handler: (req, res) => {
      res.status(429).json({
        error: 'Too many attempts from this user, please try again later'
      });
    }
  }); */



// Apply rate limiting middleware
const passwordChangeLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, 
    max: 5, 
    handler: (req, res) => {
      res.status(429).json({
        error: 'Too many password change attempts, please try again later'
      });
    }
  });



// Debug: Log route registrations
console.log('Registering withdraw information routes');
console.log('WithdrawInformationController methods:', Object.keys(WithdrawInformationController));

router.post('/', isUser, WithdrawInformationController.create.bind(WithdrawInformationController));
router.get('/', isAdmin, WithdrawInformationController.findAll.bind(WithdrawInformationController));
router.get('/:id', isUserOrAdmin, WithdrawInformationController.findById.bind(WithdrawInformationController));
router.put('/', isUser, passwordChangeLimiter, WithdrawInformationController.update.bind(WithdrawInformationController));
// router.delete('/:id', WithdrawInformationController.delete.bind(WithdrawInformationController));
router.get('/user/:userId', isUser, WithdrawInformationController.findByUserId.bind(WithdrawInformationController));


module.exports = router;