const express = require('express');
const GLAccountController = require('../controllers/GLAccountController');
const {isAdmin} = require('../middleware/authMiddleware');
const router = express.Router();

// GL Account Routes
router.post('/', isAdmin, GLAccountController.create);
router.get('/', isAdmin, GLAccountController.findAll);
router.get('/:id', isAdmin, GLAccountController.findById);
router.put('/:id', isAdmin, GLAccountController.update);
router.delete('/:id', isAdmin, GLAccountController.delete);

module.exports = router;