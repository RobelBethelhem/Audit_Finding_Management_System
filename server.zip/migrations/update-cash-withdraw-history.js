'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('cash_withdraw_histories', 'assigned_to', {
      type: Sequelize.UUID,
      allowNull: true,
    });
    await queryInterface.addColumn('cash_withdraw_histories', 'reference_number', {
      type: Sequelize.STRING,
      allowNull: true,
    });
  },

  down: async (queryInterface) => {
    await queryInterface.removeColumn('cash_withdraw_histories', 'assigned_to');
    await queryInterface.removeColumn('cash_withdraw_histories', 'reference_number');
  }
};