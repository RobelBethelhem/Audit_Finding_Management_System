module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('user_points_balances', {
          id: {
              type: Sequelize.UUID,
              primaryKey: true,
              defaultValue: Sequelize.UUIDV4
          },
          user_id: {
            type: Sequelize.UUID,
            allowNull: false
          },
          points: {
              type: Sequelize.INTEGER,
              allowNull: false,
              defaultValue: 0
          },
          createdAt: {
            type: Sequelize.DATE,
            allowNull: false
          },
          updatedAt: {
            type: Sequelize.DATE,
            allowNull: false
          }
        });
    
        await queryInterface.addIndex('user_points_balances', ['id', 'user_id']);
      },
      down: async (queryInterface) => {
        await queryInterface.dropTable('user_points_balances');
      }
    };