module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.addColumn('user_task_history', 'status', {
        type: Sequelize.ENUM('Pending', 'Accepted'),
        allowNull: false,
        defaultValue: 'Pending' 
      });
  
      await queryInterface.addIndex('user_task_history', ['status'], {
        name: 'idx_user_task_history_status' 
      });
    },
  
    down: async (queryInterface) => {
      await queryInterface.removeIndex('user_task_history', 'idx_user_task_history_status');
      await queryInterface.removeColumn('user_task_history', 'status');
    }
  };