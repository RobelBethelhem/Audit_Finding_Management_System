module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('admin_users', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        username: {
          type: Sequelize.STRING,
          allowNull: false
        },
        password: {
          type: Sequelize.STRING,
          allowNull: false
        },
        failed_attempts: {
            type: Sequelize.INTEGER,
            allowNull: false,
            defaultValue: 0
          },
        lockout_until: {
            type: Sequelize.DATE,
            allowNull: true
          },
        status: {
        type: Sequelize.ENUM('Active', 'Inactive',  'LockeOut'),
        defaultValue: 'Inactive'
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('admin_users', ['id', 'username', 'status']);
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('admin_users');
    }
  };