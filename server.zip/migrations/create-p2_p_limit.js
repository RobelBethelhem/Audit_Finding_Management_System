module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('p2_p_limit', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        min_amount: {
          type: Sequelize.DECIMAL(10, 2),
          allowNull: false
        },
        max_amount: {
          type: Sequelize.DECIMAL(10, 2),
          allowNull: false
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('p2_p_limit', ['id', 'min_amount', 'max_amount'], {
        name: 'idx_p2p_limit' // Custom index name
      });
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('p2_p_limit');
    }
  };