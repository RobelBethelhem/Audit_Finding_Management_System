module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('user_assigned_to_system_sell_task_package', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        user_id: {
          type: Sequelize.UUID,
          allowNull: false
        },
        system_sell_task_package_id: {
          type: Sequelize.UUID,
          allowNull: false
        },
        start_date: {
          type: Sequelize.DATE,
          allowNull: false
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('user_assigned_to_system_sell_task_package', ['id', 'system_sell_task_package_id', 'user_id']);
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('user_assigned_to_system_sell_task_package');
    }
  };