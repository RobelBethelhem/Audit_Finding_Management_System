module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.addColumn('levels', 'percentage', {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate: {
            min: 0,
            max: 100
        }
      });
    },
    down: async (queryInterface) => {
      await queryInterface.removeColumn('levels', 'percentage');
    }
  };