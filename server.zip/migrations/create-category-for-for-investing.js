module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('categories_for_for_investing', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        category_name: {
          type: Sequelize.STRING,
          allowNull: false
        },
        purpose: {
            type: Sequelize.STRING,
            allowNull: false
          },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('categories_for_for_investing', ['id', 'category_name']);
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('categories_for_for_investing');
    }
  };