'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {

    await queryInterface.addColumn('cash_withdraw_histories', 'bank_account_configuration_id', {
      type: Sequelize.UUID,
      allowNull: false,
    });
  },

  down: async (queryInterface) => {
    await queryInterface.removeColumn('cash_withdraw_histories', 'bank_account_configuration_id');
  }
};