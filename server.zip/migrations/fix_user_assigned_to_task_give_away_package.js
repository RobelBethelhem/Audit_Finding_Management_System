'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Drop the existing table if it exists
    await queryInterface.dropTable('user_assigned_to_task_give_away_package');

    // Create the table again with the correct definition
    await queryInterface.createTable('user_assigned_to_task_give_away_package', {
      id: {
        type: Sequelize.UUID,
        primaryKey: true,
        defaultValue: Sequelize.UUIDV4
      },
      user_id: {
        type: Sequelize.UUID,
        allowNull: false,
      },
      task_give_away_package_id: {
        type: Sequelize.UUID,
        allowNull: false,
      },
      start_date: {
        type: Sequelize.DATE,
        allowNull: false,
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
      },
    });

    // Add the index with the correct name
    await queryInterface.addIndex('user_assigned_to_task_give_away_package', ['id', 'task_give_away_package_id', 'user_id'], {
      name: 'idx_user_assigned_task_give_away', // Custom index name
    });
  },

  down: async (queryInterface) => {
    // Drop the table again in the down method
    await queryInterface.dropTable('user_assigned_to_task_give_away_package');
  },
};