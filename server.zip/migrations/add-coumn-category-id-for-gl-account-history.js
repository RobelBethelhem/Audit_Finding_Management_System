module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.addColumn('gl_account_histories', 'category_id', {
        type: Sequelize.UUID,
        allowNull: false
      });
    },
    down: async (queryInterface) => {
      await queryInterface.removeColumn('gl_account_histories', 'category_id');
    }
  };