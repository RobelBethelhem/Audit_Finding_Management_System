'use strict';

module.exports = {
  up: async (queryInterface) => {
    await queryInterface.removeColumn('account_number_transaction_histories', 'transaction_done_by');
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('account_number_transaction_histories', 'transaction_done_by', {
      type: Sequelize.UUID,
      allowNull: true 
    });
  }
};