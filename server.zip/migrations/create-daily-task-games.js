module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('daily_task_games', {
          id: {
              type: Sequelize.UUID,
              primaryKey: true,
              defaultValue: Sequelize.UUIDV4
          },
          daily_task_id: {
            type: Sequelize.UUID,
            allowNull: false
          },
          value: {
              type: Sequelize.STRING,
              allowNull: false,
          },
          isExpired: {
            type: Sequelize.BOOLEAN,
            allowNull: false,
            defaultValue: false
          },
          createdAt: {
            type: Sequelize.DATE,
            allowNull: false
          },
          updatedAt: {
            type: Sequelize.DATE,
            allowNull: false
          }
        });
    
        await queryInterface.addIndex('daily_task_games', ['id', 'daily_task_id']);
      },
      down: async (queryInterface) => {
        await queryInterface.dropTable('daily_task_games');
      }
    };