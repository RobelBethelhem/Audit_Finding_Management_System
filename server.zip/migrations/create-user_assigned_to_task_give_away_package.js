module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('user_assigned_to_task_give_away_package', {
      id: {
        type: Sequelize.UUID,
        primaryKey: true,
        defaultValue: Sequelize.UUIDV4
      },
      user_id: {
        type: Sequelize.UUID,
        allowNull: false
      },
      task_give_away_package_id: {
        type: Sequelize.UUID,
        allowNull: false
      },
      start_date: {
        type: Sequelize.DATE,
        allowNull: false
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });

    await queryInterface.addIndex('user_assigned_to_task_give_away_package', ['id', 'task_give_away_package_id', 'user_id'], {
      name: 'idx_user_assigned_task_give_away' // Custom index name
    });
  },
  down: async (queryInterface) => {
    await queryInterface.dropTable('user_assigned_to_task_give_away_package');
  }
};