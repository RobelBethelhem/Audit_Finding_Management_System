module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('daily_task_configurations', {
        id: {
            type: Sequelize.UUID,
            primaryKey: true,
            defaultValue: Sequelize.UUIDV4
        },
        task_name: {
          type: Sequelize.STRING,
          allowNull: false
        },
        description: {
            type: Sequelize.TEXT,
            allowNull: false
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('daily_task_configurations', ['id', 'task_name']);
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('daily_task_configurations');
    }
  };