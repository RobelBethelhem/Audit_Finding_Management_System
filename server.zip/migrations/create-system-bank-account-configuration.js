module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('bank_account_configurations', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        bank_name: {
          type: Sequelize.STRING,
          allowNull: false
        },
        account_number: {
          type: Sequelize.STRING,
          allowNull: false
        },
        account_holder_name: {
            type: Sequelize.STRING,
            allowNull: false
          },
        managed_by: {
            type: Sequelize.UUID,
            allowNull: true
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
         
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('bank_account_configurations', ['id', 'managed_by', 'account_number']);
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('bank_account_configurations');
    }
  };