module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('gl_account_histories', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        gl_account_id: {
          type: Sequelize.UUID,
          allowNull: false
        },
        transaction_amount: {
          type: Sequelize.DECIMAL(10, 2),
          allowNull: false
        },
        transaction_type:{
          type: Sequelize.ENUM('Credit', 'Debit'),
          allowNull: false,
          defaultValue: 'Debit'
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        transaction_done_by: {
          type: Sequelize.UUID,
          allowNull: false
        },
        status: {
          type: Sequelize.ENUM('Approved', 'Rejected', 'Pending'),
          allowNull: false,
          defaultValue: 'Pending'
        },
        checked_by: {
          type: Sequelize.UUID,
          allowNull: true
        }
      });
  
      await queryInterface.addIndex('gl_account_histories', ['id', 'gl_account_id', 'checked_by', 'status', 'transaction_done_by'],{
        name: 'idx_gl_account_history' 
      });
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('gl_account_histories');
    }
  };