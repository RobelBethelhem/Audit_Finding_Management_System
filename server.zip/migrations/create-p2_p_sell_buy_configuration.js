module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('p2_p_sell_buy_configuration', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        level_id: {
          type: Sequelize.UUID,
          allowNull: false
        },
        buy_limit: {
          type: Sequelize.INTEGER,
          allowNull: false
        },
        sell_limit: {
          type: Sequelize.INTEGER,
          allowNull: false
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('p2_p_sell_buy_configuration', ['id', 'level_id'], {
        name: 'idx_p2p_sell_buy_config' 
      });
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('p2_p_sell_buy_configuration');
    }
  };