module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('account_number_balances', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        bank_account_configuration_id: {
          type: Sequelize.UUID,
          allowNull: false
        },
        account_balance: {
          type: Sequelize.DECIMAL(10, 2),
          allowNull: false
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('account_number_balances', ['id', 'bank_account_configuration_id', 'account_balance'],{
        name: 'idx_account_number_balance', 
      });
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('account_number_balances');
    }
  };