module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('audit_logs', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        user_id: {
          type: Sequelize.UUID,
          allowNull: false
        },
        action_type: {
            type: Sequelize.STRING,
            allowNull: false
        },
        details: {
        type: Sequelize.TEXT,
        allowNull: true
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('audit_logs', ['user_id']);
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('audit_logs');
    }
  };