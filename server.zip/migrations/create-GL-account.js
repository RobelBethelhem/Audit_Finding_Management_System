module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('gl_accounts', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        account_number: {
          type: Sequelize.STRING,
          allowNull: false
        },
        available_balance: {
          type: Sequelize.DECIMAL(10, 2),
          allowNull: false
        },
        gl_account_type: {
          type: Sequelize.ENUM('Debit', 'Credit'),
          defaultValue: 'Debit'
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('gl_accounts', ['id', 'account_number', 'gl_account_type', 'available_balance']);
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('gl_accounts');
    }
  };