module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.addColumn('user_balances', 'point_selling_credit', {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false,
        defaultValue: 0.00
      });
    },
    down: async (queryInterface) => {
      await queryInterface.removeColumn('user_balances', 'point_selling_credit');
    }
  };