module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('cash_withdraw_histories', 'reason', {
      type: Sequelize.ENUM('Give_up', 'Withdraw'),
      defaultValue: 'Withdraw'
    });
  },
  down: async (queryInterface) => {
    await queryInterface.removeColumn('cash_withdraw_histories', 'reason');
  }
};