'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
   
    await queryInterface.addColumn('gl_account_histories', 'transaction_reference', {
      type: Sequelize.STRING,
      allowNull: true,
    });

    await queryInterface.removeIndex('gl_account_histories', 'idx_gl_account_history');
    await queryInterface.addIndex('gl_account_histories', ['id', 'gl_account_id', 'checked_by', 'status', 'transaction_done_by', 'transaction_reference'], {
      name: 'idx_gl_account_history'
    });
  },

  down: async (queryInterface) => {
   
    await queryInterface.removeColumn('gl_account_histories', 'transaction_reference');
    await queryInterface.removeIndex('gl_account_histories', 'idx_gl_account_history');
    await queryInterface.addIndex('gl_account_histories', ['id', 'gl_account_id', 'checked_by', 'status', 'transaction_done_by'], {
      name: 'idx_gl_account_history'
    });
  }
};