'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('admin_users', 'failed_attempts', {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 0
    });
  },

  down: async (queryInterface) => {
    await queryInterface.changeColumn('admin_users', 'failed_attempts', {
      type: Sequelize.INTEGER,
      allowNull: false 
    });
  }
};