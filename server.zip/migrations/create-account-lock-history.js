module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('account_lock_histories', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        user_id: {
          type: Sequelize.UUID,
          allowNull: false
        },
        previous_status: {
          type: Sequelize.ENUM('Active', 'Inactive', 'Give_up', 'LockeOut'),
          allowNull: false
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('account_lock_histories', ['user_id']);
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('account_lock_histories');
    }
  };