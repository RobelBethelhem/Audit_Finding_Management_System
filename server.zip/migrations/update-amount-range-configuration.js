'use strict';

const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface) => {
    
    await queryInterface.addColumn('amount_range_configurations', 'bank_account_configuration_id', {
      type: DataTypes.UUID,
      allowNull: false,
    });

    await queryInterface.changeColumn('amount_range_configurations', 'minimum_amount', {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
    });

    await queryInterface.changeColumn('amount_range_configurations', 'maximum_amount', {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
    });
    await queryInterface.addIndex('amount_range_configurations', ['bank_account_configuration_id']);
  },

  down: async (queryInterface) => {
    await queryInterface.removeColumn('amount_range_configurations', 'bank_account_configuration_id');
    await queryInterface.changeColumn('amount_range_configurations', 'minimum_amount', {
      type: DataTypes.INTEGER,
      allowNull: false,
    });
    await queryInterface.changeColumn('amount_range_configurations', 'maximum_amount', {
      type: DataTypes.INTEGER,
      allowNull: false,
    });
    await queryInterface.removeIndex('amount_range_configurations', ['bank_account_configuration_id']);
  }
};