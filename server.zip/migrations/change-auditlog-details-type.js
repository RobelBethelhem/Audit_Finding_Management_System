// migrations/change-auditlog-details-type.js
module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.changeColumn('audit_logs', 'details', {
        type: Sequelize.JSON
      });
    },
    down: async (queryInterface, Sequelize) => {
      await queryInterface.changeColumn('audit_logs', 'details', {
        type: Sequelize.TEXT
      });
    }
  };