module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.addColumn('verify_deposits', 'balance', {
        type: Sequelize.INTEGER,
        allowNull: false
      });
    },
    down: async (queryInterface) => {
      await queryInterface.removeColumn('verify_deposits', 'balance');
    }
  };