module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('user_task_history', {
      id: {
        type: Sequelize.UUID,
        primaryKey: true,
        defaultValue: Sequelize.UUIDV4
      },
      reffered_user_id: {
        type: Sequelize.UUID,
        allowNull: false
      },
      user_assigned_to_system_sell_task_package_id: {
        type: Sequelize.UUID,
        allowNull: false
      },
      date: {
        type: Sequelize.DATE,
        allowNull: false
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });

    await queryInterface.addIndex('user_task_history', ['id', 'reffered_user_id', 'user_assigned_to_system_sell_task_package_id'], {
      name: 'idx_user_task_history' // Custom index name
    });
  },
  down: async (queryInterface) => {
    await queryInterface.dropTable('user_task_history');
  }
};