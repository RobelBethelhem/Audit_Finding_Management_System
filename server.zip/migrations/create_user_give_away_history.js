module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('user_give_away_history', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        reffered_user_id: {
          type: Sequelize.UUID,
          allowNull: false
        },
        user_assigned_to_task_give_away_package_id: {
          type: Sequelize.UUID,
          allowNull: false
        },
        status: {
          type: Sequelize.ENUM('Pending', 'Accepted'),
          allowNull: false,
          defaultValue: 'Pending'
        },
        date: {
          type: Sequelize.DATE,
          allowNull: false
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('user_give_away_history', ['id', 'reffered_user_id', 'user_assigned_to_task_give_away_package_id'], {
        name: 'idx_user_give_away_history'
      });
    },
  
    down: async (queryInterface) => {
      await queryInterface.dropTable('user_give_away_history');
    }
  };