module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('daily_task_points', {
          id: {
              type: Sequelize.UUID,
              primaryKey: true,
              defaultValue: Sequelize.UUIDV4
          },
          daily_task_id: {
            type: Sequelize.UUID,
            allowNull: false
          },
          points: {
              type: Sequelize.INTEGER,
              allowNull: false,
              defaultValue: 0
          },
          createdAt: {
            type: Sequelize.DATE,
            allowNull: false
          },
          updatedAt: {
            type: Sequelize.DATE,
            allowNull: false
          }
        });
    
        await queryInterface.addIndex('daily_task_points', ['id', 'daily_task_id']);
      },
      down: async (queryInterface) => {
        await queryInterface.dropTable('daily_task_points');
      }
    };