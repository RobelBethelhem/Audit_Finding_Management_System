'use strict';

const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface) => {
    await queryInterface.addColumn('verify_deposits', 'bank_account_configuration_id', {
      type: DataTypes.UUID,
      allowNull: false,
    });

    await queryInterface.changeColumn('verify_deposits', 'balance', {
      type: DataTypes.DECIMAL(10, 2), 
      allowNull: false,
    });

    await queryInterface.addColumn('verify_deposits', 'approved_by', {
      type: DataTypes.UUID,
      allowNull: true, 
    });
  },

  down: async (queryInterface) => {
    await queryInterface.removeColumn('verify_deposits', 'bank_account_configuration_id');
    await queryInterface.changeColumn('verify_deposits', 'balance', {
      type: DataTypes.INTEGER, 
      allowNull: false,
    });
    await queryInterface.removeColumn('verify_deposits', 'approved_by');
  }
};