'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('users', 'status', {
      type: Sequelize.ENUM('Active', 'Inactive', 'Give_up', 'LockeOut'),
      allowNull: false,
      defaultValue: 'Inactive',
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('users', 'status', {
      type: Sequelize.ENUM('Active', 'Inactive', 'Give_up'),
      allowNull: false,
      defaultValue: 'Inactive',
    });
  },
};