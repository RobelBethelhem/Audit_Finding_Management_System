'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
  
    await queryInterface.addColumn('account_number_transaction_histories', 'admin_transaction_done_by', {
      type: Sequelize.UUID,
      allowNull: true, 
    });

    await queryInterface.addColumn('account_number_transaction_histories', 'user_transaction_done_by', {
      type: Sequelize.UUID,
      allowNull: true, 
    });

    await queryInterface.removeIndex('account_number_transaction_histories', 'idx_account_number_transaction_history');
    await queryInterface.addIndex('account_number_transaction_histories', {
      name: 'idx_account_number_transaction_history',
      fields: ['id', 'bank_account_configuration_id', 'checked_by', 'status', 'admin_transaction_done_by', 'user_transaction_done_by']
    });
  },

  down: async (queryInterface) => {
    await queryInterface.removeColumn('account_number_transaction_histories', 'admin_transaction_done_by');
    await queryInterface.removeColumn('account_number_transaction_histories', 'user_transaction_done_by');
    await queryInterface.removeIndex('account_number_transaction_histories', 'idx_account_number_transaction_history');
    await queryInterface.addIndex('account_number_transaction_histories', {
      name: 'idx_account_number_transaction_history',
      fields: ['id', 'bank_account_configuration_id', 'checked_by', 'status', 'transaction_done_by']
    });
  }
};