module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('paid_children_limits', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        first_generation_limit: {
          type: Sequelize.INTEGER,
          allowNull: false
        },
        second_generation_limit: {
            type: Sequelize.INTEGER,
            allowNull: false
        },
        third_generation_limit: {
            type: Sequelize.INTEGER,
            allowNull: false
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('paid_children_limits', ['id']);
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('paid_children_limits');
    }
  };