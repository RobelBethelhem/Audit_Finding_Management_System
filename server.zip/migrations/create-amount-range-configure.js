module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('amount_range_configurations', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        minimum_amount: {
          type: Sequelize.INTEGER,
          allowNull: false
        },
        maximum_amount: {
          type: Sequelize.INTEGER,
          allowNull: false
        },
        admin_user_id: {
          type: Sequelize.UUID,
          allowNull: true
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('amount_range_configurations', ['id', 'admin_user_id']);
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('amount_range_configurations');
    }
  };