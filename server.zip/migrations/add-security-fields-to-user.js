module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.addColumn('users', 'failed_attempts', {
        type: Sequelize.INTEGER,
        defaultValue: 0
      });
      await queryInterface.addColumn('users', 'lockout_until', {
        type: Sequelize.DATE,
        allowNull: true
      });
    },
    down: async (queryInterface) => {
      await queryInterface.removeColumn('users', 'failed_attempts');
      await queryInterface.removeColumn('users', 'lockout_until');
    }
  };