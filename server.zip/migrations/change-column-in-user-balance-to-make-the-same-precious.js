// migrations/change-withdraw-up-to-date-type.js
module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.changeColumn('user_balances', 'total_first_node_balance', {
        type: Sequelize.DECIMAL(10, 2),
            allowNull: false,
            defaultValue: 0.00
      });

      await queryInterface.changeColumn('user_balances', 'total_second_node_balance', {
        type: Sequelize.DECIMAL(10, 2),
            allowNull: false,
            defaultValue: 0.00
      });

      await queryInterface.changeColumn('user_balances', 'total_third_balance', {
        type: Sequelize.DECIMAL(10, 2),
            allowNull: false,
            defaultValue: 0.00
      });

      await  queryInterface.changeColumn('user_balances','current_balance', {
        type: Sequelize.DECIMAL(10, 2),
            allowNull: false,
            defaultValue: 0.00
      });

      await  queryInterface.changeColumn('user_balances','withdraw_up_to_date', {
        type: Sequelize.DECIMAL(10, 2),
            allowNull: false,
            defaultValue: 0.00
      });

    },
  
    down: async (queryInterface, Sequelize) => {
      await queryInterface.changeColumn('user_balances', 'total_first_node_balance', {
        type: Sequelize.DECIMAL(10, 2),
        defaultValue: 0
      });
      await queryInterface.changeColumn('user_balances', 'total_second_node_balance', {
        type: Sequelize.DECIMAL(10, 2),
        defaultValue: 0
      });
      await queryInterface.changeColumn('user_balances', 'total_third_balance', {
        type: Sequelize.DECIMAL(10, 2),
        defaultValue: 0
      });
      await queryInterface.changeColumn('user_balances', 'current_balance', {
        type: Sequelize.DECIMAL(10, 2),
        defaultValue: 0
      });

      await queryInterface.changeColumn('user_balances', 'withdraw_up_to_date', {
        type: Sequelize.DECIMAL(10, 2),
        defaultValue: 0
      });

    }
  };