module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.addColumn('p2_p_limit', 'min_price', {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false
      });
  
      await queryInterface.addColumn('p2_p_limit', 'max_price', {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false
      });
  
      await queryInterface.addIndex('p2_p_limit', ['min_price', 'max_price'], {
        name: 'idx_p2p_price' 
      });
    },
  
    down: async (queryInterface) => {
      await queryInterface.removeIndex('p2_p_limit', 'idx_p2p_price');
      await queryInterface.removeColumn('p2_p_limit', 'min_price');
      await queryInterface.removeColumn('p2_p_limit', 'max_price');
    }
  };