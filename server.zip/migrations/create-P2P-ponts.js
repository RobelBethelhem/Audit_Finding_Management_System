module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('p2_p_points', {
          id: {
              type: Sequelize.UUID,
              primaryKey: true,
              defaultValue: Sequelize.UUIDV4
          },
          seller_id: {
            type: Sequelize.UUID,
            allowNull: false
          },
          buyer_id: {
            type: Sequelize.UUID,
            allowNull: true
          },
          number_of_points: {
              type: Sequelize.INTEGER,
              allowNull: false,
          },

          unit_price: {
            type: Sequelize.DECIMAL(10, 2),
            allowNull: false,
            defaultValue: 1.00
          },

          Total_amount: {
            type: Sequelize.DECIMAL(10, 2),
            allowNull: false,
            defaultValue: 1.00
          },
          status: {
            type: Sequelize.ENUM('Pending', 'Approved', 'Rejected'),
            allowNull: false,
            defaultValue: 'Pending'
          },
          createdAt: {
            type: Sequelize.DATE,
            allowNull: false
          },
          updatedAt: {
            type: Sequelize.DATE,
            allowNull: false
          }
        });
    
        await queryInterface.addIndex('p2_p_points', ['id', 'seller_id', 'buyer_id']);
      },
      down: async (queryInterface) => {
        await queryInterface.dropTable('p2_p_points');
      }
    };