'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('account_number_transaction_histories', 'transaction_reference', {
      type: Sequelize.STRING,
      allowNull: true,
    });
  },


  down: async (queryInterface) => {
    await queryInterface.removeColumn('account_number_transaction_histories', 'transaction_reference');
  }
};