// migrations/change-withdraw-up-to-date-type.js
module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.changeColumn('user_balances', 'withdraw_up_to_date', {
        type: Sequelize.DECIMAL(10, 2),
        defaultValue: 0,
        allowNull: true
      });
    },
  
    down: async (queryInterface, Sequelize) => {
      await queryInterface.changeColumn('user_balances', 'withdraw_up_to_date', {
        type: Sequelize.DATE,
        defaultValue: 0,
        allowNull: true
      });
    }
  };