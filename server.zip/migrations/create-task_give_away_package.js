module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('task_give_away_package', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        level_id: {
          type: Sequelize.UUID,
          allowNull: false
        },
        active_days: {
          type: Sequelize.INTEGER,
          allowNull: false,
          validate: {
            min: 1
          }
        },
        refferal_limit: {
          type: Sequelize.INTEGER,
          allowNull: false,
          validate: {
            min: 1
          }
        },
        status: {
          type: Sequelize.ENUM('Active', 'Inactive'),
          defaultValue: 'Active'
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('task_give_away_package', ['id', 'level_id']);
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('task_give_away_package');
    }
  };