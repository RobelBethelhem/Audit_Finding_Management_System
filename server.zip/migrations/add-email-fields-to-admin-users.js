module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.addColumn('admin_users', 'email', {
        type: Sequelize.STRING,
        allowNull: false
      });
    },
    down: async (queryInterface) => {
      await queryInterface.removeColumn('admin_users', 'email');
    }
  };