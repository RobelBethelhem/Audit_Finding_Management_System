const BaseController = require('./BaseController');
const { Level, PointConfiguration,sequelize } = require('../models');
const sequelizee = require('sequelize');


class PointConfigurationController extends BaseController {
  constructor() {
    super(PointConfiguration);
    console.log('PointConfigurationController initialized');
  }

  // Custom create with validation (override BaseController)
  async create(req, res) {
    try {
      const { level_id, amount } = req.body;
      
      // Validate input
      if (!level_id || !amount) {
        return res.status(400).json({ error: 'level_id and amount are required' });
      }

      const existingLevel = await Level.findOne({ where: { id: level_id } });
      if (!existingLevel) {
        return res.status(400).json({ error: 'level_id does not exist' });
      }

      // Check for existing level_id
      const existingPointConfiguration = await PointConfiguration.findOne({ where: { level_id } });
      if (existingPointConfiguration) {
        return res.status(400).json({ error: 'level_id already configured' });
      }

      // Create using BaseController's create
      return super.create(req, res);
    } catch (error) {
      console.error('PointConfiguration creation error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Custom update with validation (override BaseController)
  async update(req, res) {
    try {
      const { id } = req.params;
      const { level_id, amount } = req.body;

      console.log("updateupdate", id, level_id, amount);

      const existingLevel = await Level.findOne({ where: { id: level_id } });
      if (!existingLevel) {
        return res.status(400).json({ error: 'level_id does not exist' });
      }

      // Check for existing level_id excluding current record
      if (level_id) {
        const existingLevel = await PointConfiguration.findOne({
          where: {
            level_id,
            id: { [sequelizee.Op.ne]: id }
          }
        });
        if (existingLevel) {
          return res.status(400).json({ error: 'level_id already configured' });
        }
      }

      // Update using BaseController's update
      return super.update(req, res);
    } catch (error) {
      console.error('PointConfiguration update error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Inherited methods (explicitly listed for clarity)
  async findAll(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const pointConfigurations = await PointConfiguration.findAll({
        include: [{
          model: Level,
          attributes: ['id', 'short_code', 'amount']
        }],
        transaction,
      });
      await transaction.commit();
      return res.json(pointConfigurations);
    } catch (error) {
      console.error('PointConfiguration findAll error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async findById(req, res) {
    return super.findById(req, res);
  }

  async delete(req, res) {
    return super.delete(req, res);
  }
}

module.exports = new PointConfigurationController();