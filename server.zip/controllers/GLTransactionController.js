const BaseController = require('./BaseController');
const { 
  GLAccount, 
  GLAccountHistory, 
  BankAccountConfiguration, 
  AccountNumberBalance, 
  AccountNumberTransactionHistory, 
  CategoryForInvesting,
  AdminUser,
  sequelize 
} = require('../models');
const Decimal = require('decimal.js');

class GLTransactionController extends BaseController {
  constructor() {
    super(GLAccountHistory);
  }

  async createTransaction(req, res) {
    console.log("req.body", req.body);
    const transaction = await sequelize.transaction();
    try {
      const admin_user_idd = req.user.id;
      req.body.admin_user_id = admin_user_idd;
      const { 
        admin_user_id, 
        bank_account_configuration_id, 
        gl_account_id, 
        category_id, 
        transaction_amount, 
        transaction_type, 
        transaction_reference 
      } = req.body;

      // Validate inputs
      if (!admin_user_id || !bank_account_configuration_id || !gl_account_id || !category_id || !transaction_amount || !transaction_type || !transaction_reference) {
        await transaction.rollback();
        return res.status(400).json({ error: 'All fields are required' });
      }

      // Validate transaction_type
      if (!['Debit', 'Credit'].includes(transaction_type)) {
        await transaction.rollback();
        return res.status(400).json({ error: 'transaction_type must be Debit or Credit' });
      }

      // Check if the admin manages the bank account
      const bankAccount = await BankAccountConfiguration.findOne({
        where: { id: bank_account_configuration_id, managed_by: admin_user_id },
        include: [{ model: AccountNumberBalance, as: 'AccountNumberBalance' }],
        transaction
      });

      if (!bankAccount) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Bank account not found or not managed by this admin' });
      }

      const accountBalanceRecord = bankAccount.AccountNumberBalance;
      if (!accountBalanceRecord) {
        await transaction.rollback();
        return res.status(400).json({ error: 'Account balance record not found' });
      }

      const bankBalance = new Decimal(accountBalanceRecord.account_balance);
      const glAccount = await GLAccount.findByPk(gl_account_id, { transaction });


      if (!glAccount) {
        await transaction.rollback();
        return res.status(404).json({ error: 'GL account not found' });
      }

      const category = await CategoryForInvesting.findByPk(category_id, { transaction });
      if (!category) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Category not found' });
      }

      const glBalance = new Decimal(glAccount.available_balance);
      const amount = new Decimal(transaction_amount);

      if (transaction_type === 'Debit') {
        // Debit from bank account, Credit to GL account
        if (bankBalance.lessThan(amount)) {
          await transaction.rollback();
          return res.status(400).json({ error: 'Insufficient funds in the bank account' });
        }

        // Update bank account balance
        const newBankBalance = bankBalance.minus(amount);
        await accountBalanceRecord.update({ account_balance: newBankBalance.toNumber() }, { transaction });

        // Update GL account balance
        const newGLBalance = glBalance.plus(amount);
        await glAccount.update({ available_balance: newGLBalance.toNumber() }, { transaction });

        // Record transaction in AccountNumberTransactionHistory (Debit from bank)
        await AccountNumberTransactionHistory.create({
          bank_account_configuration_id: bankAccount.id,
          transaction_amount: amount.toNumber(),
          transaction_type: 'Debit',
          admin_transaction_done_by: admin_user_id,
          status: 'Pending',
          checked_by: null,
          transaction_reference
        }, { transaction });

        // Record transaction in GLAccountHistory (Credit to GL)
        await GLAccountHistory.create({
          gl_account_id,
          category_id,
          transaction_amount: amount.toNumber(),
          transaction_type: 'Credit',
          transaction_done_by: admin_user_id,
          status: 'Pending',
          checked_by: null,
          transaction_reference
        }, { transaction });
      } else if (transaction_type === 'Credit') {
        // Credit to bank account, Debit from GL account
        if (glBalance.lessThan(amount)) {
          await transaction.rollback();
          return res.status(400).json({ error: 'Insufficient funds in the GL account' });
        }

        // Update bank account balance
        const newBankBalance = bankBalance.plus(amount);
        await accountBalanceRecord.update({ account_balance: newBankBalance.toNumber() }, { transaction });

        // Update GL account balance
        const newGLBalance = glBalance.minus(amount);
        await glAccount.update({ available_balance: newGLBalance.toNumber() }, { transaction });

        // Record transaction in AccountNumberTransactionHistory (Credit to bank)
        await AccountNumberTransactionHistory.create({
          bank_account_configuration_id: bankAccount.id,
          transaction_amount: amount.toNumber(),
          transaction_type: 'Credit',
          admin_transaction_done_by: admin_user_id,
          status: 'Pending',
          checked_by: null,
          transaction_reference
        }, { transaction });

        // Record transaction in GLAccountHistory (Debit from GL)
        await GLAccountHistory.create({
          gl_account_id,
          category_id,
          transaction_amount: amount.toNumber(),
          transaction_type: 'Debit',
          transaction_done_by: admin_user_id,
          status: 'Pending',
          checked_by: null,
          transaction_reference
        }, { transaction });
      }

      await transaction.commit();
      res.status(201).json({ 
        message: 'Transaction created successfully with status Pending',
        transaction_reference
      });
    } catch (error) {
      await transaction.rollback();
      console.error('GL transaction creation error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async updateStatus(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { id } = req.params;
      const checker_idd = req.user.id;
      req.body.checker_id = checker_idd;
      const { status, checker_id } = req.body;
  
      // Validate inputs
      if (!status || !checker_id) {
        await transaction.rollback();
        return res.status(400).json({ error: 'status and checker_id are required' });
      }
  
      if (!['Approved', 'Rejected'].includes(status)) {
        await transaction.rollback();
        return res.status(400).json({ error: 'Invalid status. Allowed values: Approved, Rejected' });
      }


     const adminCheckerUser = await AdminUser.findByPk(checker_id);
     if(!adminCheckerUser){
      await transaction.rollback();
      return res.status(404).json({ error: 'Checker not found' });
     }
  
      // Find the GL transaction history with associated models
      const glTransaction = await GLAccountHistory.findByPk(id, {
        include: [
          { 
            model: GLAccount,
            as: 'GLAccount',
            required: true // This ensures the GLAccount exists
          },
          { 
            model: AdminUser, 
            as: 'TransactionInitiator' 
          },
          { 
            model: CategoryForInvesting, 
            as: 'Category' 
          }
        ],
        transaction
      });
  
      // Add extensive logging
      console.log('GL Transaction Details:', JSON.stringify(glTransaction, null, 2));
  
      if (!glTransaction) {
        await transaction.rollback();
        return res.status(404).json({ error: 'GL transaction not found' });
      }
  
      // Verify GLAccount exists and has available balance
      if (!glTransaction.GLAccount) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Associated GL Account not found' });
      }
  
      // Ensure the checker is not the same as the maker
      if (glTransaction.transaction_done_by === checker_id) {
        await transaction.rollback();
        return res.status(403).json({ error: 'Checker cannot be the same as the maker' });
      }
  
      // Find the corresponding bank transaction history using transaction_reference
      const bankTransaction = await AccountNumberTransactionHistory.findOne({
        where: { 
          transaction_reference: glTransaction.transaction_reference
        },
        include: [
          { 
            model: BankAccountConfiguration, 
            as: 'BankAccountConfiguration',
            required: true, // Ensure bank account exists
            include: [
              { 
                model: AccountNumberBalance, 
                as: 'AccountNumberBalance',
                required: true // Ensure account balance exists
              }
            ]
          },
          { 
            model: AdminUser, 
            as: 'AdminInitiator' 
          }
        ],
        transaction
      });
  
      // Add logging for bank transaction
      console.log('Bank Transaction Details:', JSON.stringify(bankTransaction, null, 2));
  
      if (!bankTransaction) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Corresponding bank transaction not found' });
      }
  
      // Verify all necessary records exist
      const bankAccount = bankTransaction.BankAccountConfiguration;
      if (!bankAccount) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Bank account configuration not found' });
      }
  
      const accountBalanceRecord = bankAccount.AccountNumberBalance;
      if (!accountBalanceRecord) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Account balance record not found' });
      }
  
      const glAccount = glTransaction.GLAccount;
      const amount = new Decimal(glTransaction.transaction_amount);
  
      // Verify balance exists and is a valid number
      if (accountBalanceRecord.account_balance === null || accountBalanceRecord.account_balance === undefined) {
        await transaction.rollback();
        return res.status(400).json({ error: 'Invalid account balance' });
      }
  
      if (glAccount.available_balance === null || glAccount.available_balance === undefined) {
        await transaction.rollback();
        return res.status(400).json({ error: 'Invalid GL account balance' });
      }
  
      if (status === 'Approved') {
        // Update both transactions to Approved
        await glTransaction.update({ 
          status: 'Approved', 
          checked_by: checker_id 
        }, { transaction });
        
        await bankTransaction.update({ 
          status: 'Approved', 
          checked_by: checker_id 
        }, { transaction });
      } else if (status === 'Rejected') {
        // Reverse the transaction
        if (glTransaction.transaction_type === 'Credit') {
          // Original: Credit to GL, Debit from bank
          // Reverse: Debit GL, Credit bank
          const newBankBalance = new Decimal(accountBalanceRecord.account_balance).plus(amount);
          const newGLBalance = new Decimal(glAccount.available_balance).minus(amount);
  
          await accountBalanceRecord.update({ 
            account_balance: newBankBalance.toNumber() 
          }, { transaction });
          
          await glAccount.update({ 
            available_balance: newGLBalance.toNumber() 
          }, { transaction });
        } else if (glTransaction.transaction_type === 'Debit') {
          // Original: Debit from GL, Credit to bank
          // Reverse: Credit GL, Debit bank
          const newBankBalance = new Decimal(accountBalanceRecord.account_balance).minus(amount);
          const newGLBalance = new Decimal(glAccount.available_balance).plus(amount);
  
          await accountBalanceRecord.update({ 
            account_balance: newBankBalance.toNumber() 
          }, { transaction });
          
          await glAccount.update({ 
            available_balance: newGLBalance.toNumber() 
          }, { transaction });
        }
  
        // Update both transactions to Rejected
        await glTransaction.update({ 
          status: 'Rejected', 
          checked_by: checker_id 
        }, { transaction });
        
        await bankTransaction.update({ 
          status: 'Rejected', 
          checked_by: checker_id 
        }, { transaction });
      }
  
      await transaction.commit();
      res.status(200).json({ 
        message: `Transaction ${status.toLowerCase()} successfully`,
        transaction_id: id,
        new_status: status
      });
    } catch (error) {
      await transaction.rollback();
      console.error('GL transaction status update error:', error);
      console.error('Error stack:', error.stack);
      res.status(500).json({ error: error.message });
    }
  }

  async findAll(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const glTransactions = await GLAccountHistory.findAll({
        transaction,
        include: [
          {
            model: AdminUser,
            as: 'TransactionInitiator',
            attributes: ['username'], // Only fetch the username
          },
          {
            model: AdminUser,
            as: 'TransactionChecker',
            attributes: ['username'], // Only fetch the username
            required: false, // Make this include optional (checked_by can be null)
          },
          {
            model: CategoryForInvesting,
            as: 'Category',
            attributes: ['category_name'], // Only fetch the category_name
          },
        ],
      });

      // Manually adjust the output for clarity, because the previous include was making some duplicate

      const formattedGlTransactions = glTransactions.map((transaction) => {
        const transactionData = transaction.get({ plain: true });

        return {
          ...transactionData,
          transaction_done_by_username: transactionData.TransactionInitiator?.username || null,
          checked_by_username: transactionData.TransactionChecker?.username || null,
          category_name: transactionData.Category?.category_name || null,
          TransactionInitiator: undefined, 
          TransactionChecker: undefined,
          Category: undefined, 
        };
      });

      res.status(200).json(formattedGlTransactions);
      await transaction.commit();
    } catch (error) {
      await transaction.rollback();
      console.error('GL transaction findAll error:', error);
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = new GLTransactionController();