const BaseController = require('./BaseController');
const { UserAssignedToSystemSellTaskPackage, User, SystemSellTaskPackage, sequelize } = require('../models'); // Import necessary models
const sequelizee = require('sequelize');

class UserAssignedToSystemSellTaskPackageController extends BaseController {
    constructor() {
        super(UserAssignedToSystemSellTaskPackage);
        console.log('UserAssignedToSystemSellTaskPackageController initialized');
    }

    // Custom create with validation (and Transaction)
    async create(req, res) {
        let transaction;
        try {
            transaction = await sequelize.transaction(); // Start a transaction

            const { user_id, system_sell_task_package_id, start_date } = req.body;

            // Validate input
            if (!user_id || !system_sell_task_package_id || !start_date) {
                return res.status(400).json({ error: 'user_id, system_sell_task_package_id, and start_date are required' });
            }

            // Validate that user_id exists in the User model
            const existingUser = await User.findOne({
                where: {
                    id: user_id,
                    status: 'Active' 
                },
                transaction
            });
        
            if (!existingUser) {
                return res.status(400).json({ error: 'user_id does not exist in User model or is not active.' });
            }

            // Validate that system_sell_task_package_id exists in the SystemSellTaskPackage model
            const existingSystemSellTaskPackage = await SystemSellTaskPackage.findByPk(system_sell_task_package_id, { transaction });
            if (!existingSystemSellTaskPackage) {
                return res.status(400).json({ error: 'system_sell_task_package_id does not exist in SystemSellTaskPackage model' });
            }

            // Create using BaseController's create (with transaction)
            const item = await this.model.create(req.body, { transaction });

            await transaction.commit(); // Commit the transaction if everything is successful
            return res.status(201).json(item);

        } catch (error) {
            if (transaction) {
                await transaction.rollback(); // Rollback the transaction if any error occurs
            }
            console.error('UserAssignedToSystemSellTaskPackage creation error:', error);
            res.status(500).json({ error: error.message });
        }
    }

    // Custom update with validation (and explicit field definition and Transaction)
    async update(req, res) {
        let transaction;
        try {
            transaction = await sequelize.transaction(); // Start a transaction

            const { id } = req.params;
            const { user_id, system_sell_task_package_id, start_date } = req.body;

            // Validation: Check existence of related IDs if they are being updated
            if (user_id) {
                const existingUser = await User.findOne({
                    where: {
                        id: user_id,
                        status: 'Active' 
                    },
                    transaction
                });
            
                if (!existingUser) {
                    return res.status(400).json({ error: 'user_id does not exist in User model or is not active.' });
                }
            }

            if (system_sell_task_package_id) {
                const existingSystemSellTaskPackage = await SystemSellTaskPackage.findByPk(system_sell_task_package_id, { transaction });
                if (!existingSystemSellTaskPackage) {
                    return res.status(400).json({ error: 'system_sell_task_package_id does not exist in SystemSellTaskPackage model' });
                }
            }

            // Build the update object, only including allowed fields
            const updateData = {};
            if (user_id) {
                updateData.user_id = user_id;
            }
            if (system_sell_task_package_id) {
                updateData.system_sell_task_package_id = system_sell_task_package_id;
            }
            if (start_date) {
                updateData.start_date = start_date;
            }

            // Update using BaseController's update (with transaction)
            const [updated] = await this.model.update(updateData, {
                where: { id: req.params.id },
                transaction
            });

            if (updated) {
                const updatedItem = await this.model.findByPk(req.params.id, { transaction });
                await transaction.commit(); // Commit the transaction
                return res.status(200).json(updatedItem);
            } else {
              await transaction.rollback(); // Rollback the transaction
              return res.status(404).json({ error: 'UserAssignedToSystemSellTaskPackage not found' });
            }

        } catch (error) {
            if (transaction) {
                await transaction.rollback(); // Rollback the transaction if any error occurs
            }
            console.error('UserAssignedToSystemSellTaskPackage update error:', error);
            res.status(500).json({ error: error.message });
        }
    }

    // Inherited methods (explicitly listed for clarity)
    async findAll(req, res) {
        try {
            const items = await this.model.findAll({
                include: [{
                    model: SystemSellTaskPackage,
                    as: 'SystemSellTaskPackage',
                    attributes: ['id', 'package_name', 'value', 'refferal_limit', 'status']
                },
                {
                    model: User,
                    as: 'User',
                    attributes: ['id', 'username']
                }],
            });
            return res.status(200).json(items);
        } catch (error) {
            console.error('UserAssignedToSystemSellTaskPackage findAll error:', error);
            res.status(500).json({ error: error.message });
        }
    }

    async delete(req, res) {
        return super.delete(req, res);
    }
}

module.exports = new UserAssignedToSystemSellTaskPackageController();