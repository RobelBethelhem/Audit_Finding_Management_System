const BaseController = require('./BaseController');
const { BankAccountConfiguration, AmountRangeConfiguration, AdminUser, sequelize } = require('../models');

let roundRobinCounter = 0;
class BankAccountConfigurationController extends BaseController {
  constructor() {
    super(BankAccountConfiguration);
  }

  async create(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { bank_name, account_number, account_holder_name, managed_by } = req.body;

      // Validate required fields
      if (!bank_name || !account_number || !account_holder_name || !managed_by) {
        await transaction.rollback();
        return res.status(400).json({ error: 'All fields are required' });
      }

      // Check if the admin exists
      const admin = await AdminUser.findByPk(managed_by, { transaction });
      if (!admin) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Admin not found' });
      }

      // Create new bank account configuration
      const newConfig = await BankAccountConfiguration.create(
        {
          bank_name,
          account_number,
          account_holder_name,
          managed_by,
        },
        { transaction }
      );

      await transaction.commit();
      res.status(201).json(newConfig);
    } catch (error) {
      await transaction.rollback();
      console.error('Create bank account configuration error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async update(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { id } = req.params;
      const { bank_name, account_number, account_holder_name, managed_by } = req.body;

      const config = await BankAccountConfiguration.findByPk(id, { transaction });
      if (!config) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Bank account configuration not found' });
      }

      // Update fields if provided
      if (bank_name) config.bank_name = bank_name;
      if (account_number) config.account_number = account_number;
      if (account_holder_name) config.account_holder_name = account_holder_name;
      if (managed_by) {
        const admin = await AdminUser.findByPk(managed_by, { transaction });
        if (!admin) {
          await transaction.rollback();
          return res.status(404).json({ error: 'Admin not found' });
        }
        config.managed_by = managed_by;
      }

      await config.save({ transaction });
      await transaction.commit();
      res.status(200).json(config);
    } catch (error) {
      await transaction.rollback();
      console.error('Update bank account configuration error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async getBankAccountForAmount(req, res) {
    try {
        const amount = parseFloat(req.body.amount); 
       
        if (isNaN(amount)) {
            return res.status(400).json({ error: 'Invalid amount provided' });
        }

        const applicableRanges = await AmountRangeConfiguration.findAll({
            where: {
                minimum_amount: { [sequelize.Sequelize.Op.lte]: amount },
                maximum_amount: { [sequelize.Sequelize.Op.gte]: amount },
            },
            include: [{
                model: BankAccountConfiguration,
                required: true,
                attributes: [],
                include: [{
                    model: AdminUser,
                    as: 'Manager',
                    required: true,
                    attributes: [],
                    where: {
                      status: true
                    }
                }]
            }],
            order: [['createdAt', 'ASC']], // Optional:  Order by creation date to ensure consistent selection if multiple match and no real business reason to choose one over another.
            raw: true // Return plain JavaScript objects
        });

        if (!applicableRanges || applicableRanges.length === 0) {
            return res.status(404).json({ error: 'No bank account configuration found for this amount' });
        }

        let selectedRange;

        if (applicableRanges.length === 1) {
            selectedRange = applicableRanges[0];
        } else {
            // Round Robin Selection
            selectedRange = applicableRanges[roundRobinCounter % applicableRanges.length];
            roundRobinCounter++; // Increment for the next call
        }

        const bankAccount = await BankAccountConfiguration.findByPk(selectedRange.bank_account_configuration_id, { raw: true });

        if (!bankAccount) {
            console.error(`Bank Account Configuration not found for ID: ${selectedRange.bank_account_configuration_id}`); // Log this!
            return res.status(500).json({ error: 'Associated bank account configuration not found' });  //More descriptive error
        }

        const response = {
            bank_account_configuration_id: bankAccount.id,
            bank_name: bankAccount.bank_name,
            account_number: bankAccount.account_number,
            account_holder_name: bankAccount.account_holder_name,
        };

        res.status(200).json(response);

    } catch (error) {
        console.error('Error retrieving bank account for amount:', error);
        res.status(500).json({ error: error.message });
    }
}

  async findAll(req, res) {
    try {
      const bankAccountConfigurations = await BankAccountConfiguration.findAll(
        {
          include: [{
            model: AdminUser,
            as: 'Manager',
            attributes: ['username']
          }]
        }
      );
      const response = bankAccountConfigurations.map(bank => ({
        id: bank.id,
        bank_name: bank.bank_name,
        account_number: bank.account_number,
        account_holder_name: bank.account_holder_name,
        manager: bank.Manager ? bank.Manager.username : null,
        managed_by: bank.managed_by,
        createdAt: bank.createdAt,
        updatedAt: bank.updatedAt,
      }));

      res.status(200).json(response);
    } catch (error) {
      console.error('BankAccountConfiguration findAll error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async delete(req, res) {
    const { id } = req.params;
    try {
      const destroyed = await BankAccountConfiguration.destroy({
        where: { id },
      });
      if (destroyed) {
        return res.status(204).json({ message: 'Bank account configuration deleted successfully' });
      }
      throw new Error('Bank account configuration not found');
    } catch (error) {
      console.error('BankAccountConfiguration delete error:', error);
      res.status(400).json({ error: error.message });
    }
  }



  // findAll, findById, and delete are inherited from BaseController
}

module.exports = new BankAccountConfigurationController();