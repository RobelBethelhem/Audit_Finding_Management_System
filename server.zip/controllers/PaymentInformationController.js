const BaseController = require('./BaseController');
const { PaymentInformation, User, sequelize } = require('../models');
const { Op } = require('sequelize');

class PaymentInformationController extends BaseController {
  constructor() {
    super(PaymentInformation);
    console.log('PaymentInformationController initialized');
  }

  // Custom create with validation
  async create(req, res) {
    try {
      console.log("222222",req.body);
      const user_id = req.user.id;
      const { bank_name, account_number } = req.body;
      req.body.user_id = user_id;

      // Validate required fields
      if (!bank_name || !account_number) {
        return res.status(400).json({ 
          error: 'bank_name, and account_number are required' 
        });
      }

      // Check if user exists
      const user = await User.findByPk(user_id);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Check for existing account number for this user
      const existingAccount = await PaymentInformation.findOne({
        where: {
          user_id,
          account_number
        }
      });

      if (existingAccount) {
        return res.status(400).json({ 
          error: 'Account number already exists for this user' 
        });
      }

      return super.create(req, res);
    } catch (error) {
      console.error('Payment info creation error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Custom update with validation
  async update(req, res) {
    try {
      const { id } = req.params;
      const user_id = req.user.id;
      const { account_number } = req.body;
      req.body.user_id = user_id;

      // If updating user_id, check new user exists
      if (user_id) {
        const user = await User.findByPk(user_id);
        if (!user) {
          return res.status(404).json({ error: 'New user not found' });
        }
      }

      // If updating account number, check uniqueness for the user
      if (account_number) {
        const existingAccount = await PaymentInformation.findOne({
          where: {
            account_number,
            user_id: user_id || req.body.user_id,
            id: { [Op.ne]: id }
          }
        });

        if (existingAccount) {
          return res.status(400).json({ 
            error: 'Account number already exists for this user' 
          });
        }
      }

      return super.update(req, res);
    } catch (error) {
      console.error('Payment info update error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Find by user ID
  async findByUserId(req, res) {
    try {
      const  userId  = req.user.id;
      const paymentInfos = await PaymentInformation.findAll({
        where: { user_id: userId },
        include: [{
          model: User,
          attributes: ['id', 'username']
        }]
      });

      res.status(200).json(paymentInfos);
    } catch (error) {
      console.error('Find by user ID error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Generate payment link
  async generatePaymentLink(req, res) {
    try {
      const { amount, currency } = req.body;
      
      // Implement your payment gateway integration here
      const mockPaymentLink = `https://api.paymentgateway.com/pay/${amount}/${currency}`;
      
      res.status(200).json({
        payment_link: mockPaymentLink,
        expires_at: new Date(Date.now() + 3600000) // 1 hour from now
      });
    } catch (error) {
      console.error('Payment link generation error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Inherited methods
  async findAll(req, res) {
    return super.findAll(req, res);
  }

  async findById(req, res) {
    return super.findById(req, res);
  }

  async delete(req, res) {
    return super.delete(req, res);
  }
}

module.exports = new PaymentInformationController();