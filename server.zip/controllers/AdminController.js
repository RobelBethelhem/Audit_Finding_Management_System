const BaseController = require('./BaseController');
const { AdminUser, sequelize } = require('../models');
const bcrypt = require('bcrypt');

class AdminController extends BaseController {
  constructor() {
    super(AdminUser);
    this.register = this.register.bind(this);
    this.login = this.login.bind(this);
    this.changePassword = this.changePassword.bind(this);
    this.findAll = this.findAll.bind(this);
    this.update = this.update.bind(this);
    this.delete = this.delete.bind(this); // Bind the delete method
  }

  async register(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { username, password, email } = req.body;

      if (!username || !password || !email) {
        await transaction.rollback();
        return res.status(400).json({ error: 'All fields are required' });
      }

      // Check if admin username already exists
      const existingAdmin = await AdminUser.findOne({ where: { username }, transaction });
      if (existingAdmin) {
        await transaction.rollback();
        return res.status(400).json({ error: 'Username already taken' });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create new admin
      const newAdmin = await AdminUser.create({
        username,
        password: hashedPassword,
        email,
        status: 'Active'
      }, { transaction });

      await transaction.commit();
      res.status(201).json({ message: 'Admin registered successfully', admin: newAdmin });
    } catch (error) {
      await transaction.rollback();
      console.error('Admin registration error:', error);
      res.status(500).json({ error: error.message });
    }
  }


  async login(req, res) {
    try {
      if (!(req.user instanceof AdminUser)) {
        return res.status(403).json({ error: 'Unauthorized' });
      }

      req.session.adminSession = req.user; // Set admin session

      res.status(200).json({
        message: 'Login successful',
        admin: {
          id: req.user.id,
          username: req.user.username,
          role: 'admin'
        }
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }


  async changePassword(req, res) {
    if (!req.user || req.user.role !== 'admin') {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    const transaction = await sequelize.transaction();
    try {
      const { username, old_password, new_password, confirm_password } = req.body;

      if (!username || !old_password || !new_password || !confirm_password) {
        await transaction.rollback();
        return res.status(400).json({ error: 'All fields are required' });
      }

      if (new_password !== confirm_password) {
        await transaction.rollback();
        return res.status(400).json({ error: 'New password and confirm password do not match' });
      }

      const admin = await AdminUser.findOne({ where: { username }, transaction });
      if (!admin) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Admin not found' });
      }

      const isMatch = await bcrypt.compare(old_password, admin.password);
      if (!isMatch) {
        await transaction.rollback();
        return res.status(401).json({ error: 'Old password is incorrect' });
      }

      const hashedPassword = await bcrypt.hash(new_password, 10);
      await admin.update({ password: hashedPassword }, { transaction });

      await transaction.commit();
      res.status(200).json({ message: 'Password changed successfully' });
    } catch (error) {
      await transaction.rollback();
      console.error('Change password error:', error);
      res.status(500).json({ error: error.message });
    }
  }


  async findAll(req, res) {
    try {
      let { page = 1, limit = 10, sort = 'createdAt', order = 'DESC', ...filters } = req.query;

      page = parseInt(page, 10);
      limit = parseInt(limit, 10);

      if (isNaN(page) || page < 1) page = 1;
      if (isNaN(limit) || limit < 1) limit = 10;

      const offset = (page - 1) * limit;

      // Build where clause for filtering
      const whereClause = {};
      for (const key in filters) {
        if (filters.hasOwnProperty(key)) {
          whereClause[key] = filters[key]; // Add direct equality filtering
          // If you need more complex operators (like `like`, `gt`, etc.), adjust accordingly.
        }
      }

      const { count, rows } = await AdminUser.findAndCountAll({
        where: whereClause,
        order: [[sort, order]],
        offset: offset,
        limit: limit,

      });

      const totalPages = Math.ceil(count / limit);

      const response = {
        items: rows.map(adminUser => { // Sanitize the password
          const { password, ...safeAdminUser } = adminUser.get({ plain: true });
          return safeAdminUser;
        }),
        // pagination: {
        //   currentPage: page,
        //   totalPages: totalPages,
        //   totalItems: count,
        //   itemsPerPage: limit
        // }
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error in findAll:', error);
      res.status(500).json({ error: error.message });
    }
  }


  async update(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { id } = req.params; // Get ID from parameters
      const { username, email, status } = req.body;

      // Validate input
      if (!username || !email || !status) {
        await transaction.rollback();
        return res.status(400).json({ error: 'Username, email, and status are required' });
      }

      // Find the admin user
      const adminUser = await AdminUser.findByPk(id, { transaction });
      if (!adminUser) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Admin user not found' });
      }

      // Update only allowed fields
      adminUser.username = username;
      adminUser.email = email;
      adminUser.status = status;

      await adminUser.save({ transaction }); // Save the changes

      await transaction.commit();
      res.status(200).json({ message: 'Admin user updated successfully', adminUser });
    } catch (error) {
      await transaction.rollback();
      console.error('Error updating admin user:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async delete(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { id } = req.params;

      const adminUser = await AdminUser.findByPk(id, { transaction });
      if (!adminUser) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Admin user not found' });
      }

      await adminUser.destroy({ transaction });

      await transaction.commit();
      res.status(204).send();  // 204 No Content - successful deletion
    } catch (error) {
      await transaction.rollback();
      console.error('Error deleting admin user:', error);
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = new AdminController();