const BaseController = require('./BaseController');
const { P2PSellBuyConfiguration, Level, sequelize } = require('../models'); // Import the model and Level
const sequelizee = require('sequelize');

class P2PSellBuyConfigurationController extends BaseController {
    constructor() {
        super(P2PSellBuyConfiguration);
        console.log('P2PSellBuyConfigurationController initialized');
    }

    // Custom create with validation (and Transaction)
    async create(req, res) {
        let transaction;
        try {
            transaction = await sequelize.transaction(); // Start a transaction

            const { level_id, buy_limit, sell_limit } = req.body;

            // Validate input
            if (!level_id || !buy_limit || !sell_limit) {
                return res.status(400).json({ error: 'level_id, buy_limit, and sell_limit are required' });
            }

            // Validate that buy_limit and sell_limit are valid integers
            if (!Number.isInteger(Number(buy_limit))) {
                return res.status(400).json({ error: 'buy_limit must be a valid integer' });
            }
            if (!Number.isInteger(Number(sell_limit))) {
                return res.status(400).json({ error: 'sell_limit must be a valid integer' });
            }

            // Validate that level_id exists in the Level model
            const existingLevel = await Level.findByPk(level_id, { transaction });
            if (!existingLevel) {
                return res.status(400).json({ error: 'level_id does not exist in Level model' });
            }

            const existingP2PSellBuyConfiguration = await P2PSellBuyConfiguration.findOne({
                where: { level_id },
                transaction
            });
            if (existingP2PSellBuyConfiguration) {
                return res.status(400).json({ error: 'P2PSellBuyConfiguration already exists for this level' });
            }

            // Create using BaseController's create (with transaction)
            const item = await this.model.create(req.body, { transaction });

            await transaction.commit(); // Commit the transaction if everything is successful
            return res.status(201).json(item);

        } catch (error) {
            if (transaction) {
                await transaction.rollback(); // Rollback the transaction if any error occurs
            }
            console.error('P2PSellBuyConfiguration creation error:', error);
            res.status(500).json({ error: error.message });
        }
    }

    // Custom update with validation (and explicit field definition and Transaction)
    async update(req, res) {
        let transaction;
        try {
            transaction = await sequelize.transaction(); // Start a transaction

            const { id } = req.params;
            const { level_id, buy_limit, sell_limit } = req.body;

             // Validate that level_id exists in the Level model IF it is being updated
             if (level_id) {
                const existingLevel = await Level.findByPk(level_id, { transaction });
                if (!existingLevel) {
                    return res.status(400).json({ error: 'level_id does not exist in Level model' });
                }
            }

             // Validate that buy_limit and sell_limit are valid integers IF they are being updated
             if (buy_limit && !Number.isInteger(Number(buy_limit))) {
                return res.status(400).json({ error: 'buy_limit must be a valid integer' });
            }
            if (sell_limit && !Number.isInteger(Number(sell_limit))) {
                return res.status(400).json({ error: 'sell_limit must be a valid integer' });
            }

            // Validate that P2PSellBuyConfiguration exists for the given level_id
            const existingP2PSellBuyConfiguration = await P2PSellBuyConfiguration.findByPk(id, { transaction });
            if (!existingP2PSellBuyConfiguration) {
                return res.status(404).json({ error: 'P2PSellBuyConfiguration not found' });
            }


            // Build the update object, only including allowed fields
            const updateData = {};
            if (level_id) {
                updateData.level_id = level_id;
            }
            if (buy_limit) {
                updateData.buy_limit = buy_limit;
            }
            if (sell_limit) {
                updateData.sell_limit = sell_limit;
            }

            const [updated] = await this.model.update(updateData, {
                where: { id: req.params.id },
                transaction // Use the transaction
            });

            if (updated) {
                const updatedItem = await this.model.findByPk(req.params.id, {
                    transaction // Use the transaction
                });
                await transaction.commit(); // Commit the transaction
                return res.status(200).json(updatedItem);
            } else {
                await transaction.rollback(); // Rollback the transaction
                return res.status(404).json({ error: 'P2PSellBuyConfiguration not found' });
            }

        } catch (error) {
            if (transaction) {
                await transaction.rollback(); // Rollback the transaction if any error occurs
            }
            console.error('P2PSellBuyConfiguration update error:', error);
            res.status(500).json({ error: error.message });
        }
    }

    // Inherited methods (explicitly listed for clarity)
    async findAll(req, res) {
        try {
            const items = await this.model.findAll({
                include: [
                    {
                        model: Level,
                        as: 'Level',
                        attributes: ['id', 'short_code', 'amount']
                    }
                ]
            });
            return res.status(200).json(items);
        } catch (error) {
            console.error('P2PSellBuyConfiguration findAll error:', error);
            res.status(500).json({ error: error.message });
        }
    }

    async delete(req, res) {
        return super.delete(req, res);
    }
}

module.exports = new P2PSellBuyConfigurationController();