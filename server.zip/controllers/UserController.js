const BaseController = require('./BaseController');
const { User, ParentUser, FirstGeneration,UserPointBalance, BankAccountConfiguration, AccountLockHistory, WithdrawInformation, UserBalance, SecondGeneration, ThirdGeneration , Level , AdminUser, CashWithdrawHistory, PaymentInformation, VerifyDeposit, P2PPoints, AuditLog, sequelize} = require('../models');
const bcrypt = require('bcrypt');
const { Op } = require('sequelize'); // Add this line
const Decimal = require('decimal.js');


class UserController extends BaseController {
  constructor() {
    super(User);
    this.MAX_ATTEMPTS = 5;
    this.LOCKOUT_DURATION = 6 * 60 * 60 * 1000;
    console.log('UserController constructor called');

    this.register = this.register.bind(this);
    this.login = this.login.bind(this);
    this.create = this.create.bind(this);
    this.findAll = this.findAll.bind(this);
    this.findById = this.findById.bind(this);
    this.update = this.update.bind(this);
    this.delete = this.delete.bind(this);
    this.getReferralTree = this.getReferralTree.bind(this);
    this.getReferralTreeById = this.getReferralTreeById.bind(this);
    this.hasActiveReferrals = this.hasActiveReferrals.bind(this);
    this.giveUp = this.giveUp.bind(this);
    this.getDefaultPaymentInfo =  this.getDefaultPaymentInfo.bind(this);
    this.UserCanSellCoin = this.UserCanSellCoin.bind(this);
    this.getPaidReferralCommissions = this.getPaidReferralCommissions.bind(this);
    this.getTransactionHistory = this.getTransactionHistory.bind(this);
    this.getUserDashData = this.getUserDashData.bind(this);
    this.update = this.update.bind(this);
  }

  async logAction(userId, actionType, details = null) {
    await AuditLog.create({
      user_id: userId,
      action_type: actionType,
      details
    });
  }

  async update(req, res) {
    try {
      const  id  = req.user.id;
      const { old_login_password, new_login_password, confirm_new_login_password } = req.body;

      // Validate required fields
      if (!old_login_password || !new_login_password || !confirm_new_login_password) {
        return res.status(400).json({ 
          error: 'old_login_password, new_login_password, and confirm_new_login_password are required' 
        });
      }

       // Get withdraw info and associated user
       const userInfo = await User.findByPk(id);

      if (!userInfo) {
        return res.status(404).json({ error: 'User information not found' });
      } 


      const isLockedOut = await this.checkLockoutStatus(userInfo);
      if (isLockedOut) {
      return res.status(403).json({
          error: `Account locked until ${userInfo.lockout_until}. Try again later.`
      });
      }

      // Check if new passwords match
      if (new_login_password !== confirm_new_login_password) {
        return res.status(400).json({ 
          error: 'New password and confirmation do not match' 
        });
      }


      // Verify old password
      const isValid = await bcrypt.compare(old_login_password, userInfo.password);

     
      if (!isValid) {
        // Increment failed attempts
       
        const newAttempts = userInfo.failed_attempts + 1;
        const updateData = { failed_attempts: newAttempts };

        if (newAttempts >= this.MAX_ATTEMPTS) {

       

             // Store previous status
        await AccountLockHistory.create({
            user_id: req.user.id,
            previous_status: userInfo.status
        });

          updateData.status = 'LockeOut';
          updateData.lockout_until = new Date(Date.now() + this.LOCKOUT_DURATION);
        }

        await userInfo.update(updateData);

        await this.logAction(userInfo.id, 'Login_PASSWORD_CHANGE', {
          changed_at: new Date(),
          ip_address: req.ip
        });

        return res.status(401).json({
          error: `Invalid old password. Remaining attempts: ${this.MAX_ATTEMPTS - newAttempts}`,
          remaining_attempts: this.MAX_ATTEMPTS - newAttempts
        });
      }

      // Prepare update data
      const updateData = {
        failed_attempts: 0,
        lockout_until: null
      };


       // Restore original status if account was locked
    if (userInfo.status === 'LockeOut') {
        const latestLockHistory = await AccountLockHistory.findOne({
          where: { user_id: req.user.id },
          order: [['createdAt', 'DESC']]
        });
  
        if (latestLockHistory) {
          updateData.status = latestLockHistory.previous_status;
          await latestLockHistory.destroy();
        } else {
          // Fallback to Inactive if no history found
          updateData.status = 'Inactive';
        }
      }

       // Update user status
    await userInfo.update(updateData);

      // Hash new password
      const hashedPassword = await bcrypt.hash(new_login_password, 10);

      // Update password
      await User.update(
        { password: hashedPassword },
        { where: { id } }
      );

        // Audit log
        await this.logAction(req.user.id, 'LOGIN_PASSWORD_CHANGE', {
            changed_at: new Date(),
            ip_address: req.ip
          });


      const updatedInfo = await User.findByPk(id);
      return res.status(200).json({
        id: updatedInfo.id,
        user_id: updatedInfo.user_id,
        updated_at: updatedInfo.updatedAt
      });

     

    } catch (error) {
      console.error('Withdraw info update error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async checkLockoutStatus(user) {
    if (user.lockout_until && user.lockout_until > new Date()) {
      return true; // Still locked out
    }

    // Reset lockout if expired
    if (user.status === 'LockeOut' && user.lockout_until <= new Date()) {
     
     const  accountLockHistory = await AccountLockHistory.find({user_id: user.id});
     let prevStatus = "Inactive";
     if(accountLockHistory){
      prevStatus = accountLockHistory.previous_status;
     }

      await user.update({
        status: prevStatus,
        failed_attempts: 0,
        lockout_until: null
      });
    }
    return false;
  }
  
  async register(req, res) {
    const transaction = await sequelize.transaction();
    try {
      console.log('Register request received:', req.body);
      const { username, password, withdrawPassword, referral_code } = req.body;

      // Validate input
      if (!username || !password || !withdrawPassword) {
        await transaction.rollback();
        return res.status(400).json({ error: 'Username, password and withdrawPassword are required' });
      }

      // Check if username already exists
      const existingUser = await User.findOne({ where: { username }, transaction });
      if (existingUser) {
        await transaction.rollback();
        return res.status(400).json({ error: 'Username already exists' });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);
      const hashedWithdrawPassword = await bcrypt.hash(withdrawPassword, 10);
      let parentUser = null;
      console.log("referral_code", referral_code);

      // If referral code is provided, find the parent user
      if (referral_code) {
        parentUser = await User.findOne({ where: { id: referral_code }, transaction });
        if (!parentUser) {
          await transaction.rollback();
          return res.status(404).json({ error: 'Invalid referral code' });
        }
      }

      // Create new user
      let newUser;
      try {
        newUser = await User.create({
          username,
          password: hashedPassword,
          parent_user_id: parentUser ? parentUser.id : null,
          status: 'Inactive'
        }, { transaction });
        console.log('New user created:', newUser.toJSON());

        // Create withdraw info
        await WithdrawInformation.create({
          user_id: newUser.id,
          withdraw_password: hashedWithdrawPassword
        }, { transaction });




      } catch (createError) {
        console.error('User creation error:', createError);
        await transaction.rollback();
        return res.status(500).json({ error: 'Failed to create user', details: createError.message });
      }

      // Create parent user record
      try {
        await ParentUser.create({
          user_id: newUser.id,
          parent_user_id: parentUser ? parentUser.id : null
        }, { transaction });
      } catch (parentUserError) {
        console.error('Parent user record creation error:', parentUserError);
        await transaction.rollback();
        return res.status(500).json({ error: 'Failed to create parent record', details: parentUserError.message });
      }

      // If parent user exists, update generation tables using transaction
      if (parentUser) {
        try {
          await this.updateGenerations(parentUser.id, newUser.id, 1, transaction);
        } catch (generationError) {
          console.error('Generation update error:', generationError);
          await transaction.rollback();
          return res.status(500).json({ error: 'Failed to update generation data', details: generationError.message });
        }
      }

      await transaction.commit();
      res.status(201).json({
        message: 'User registered successfully',
        user: { id: newUser.id, username: newUser.username }
      });
    } catch (error) {
      await transaction.rollback();
      console.error('Registration error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async getUserDashData(req, res) {
    try {
      const userId = req.user.id;
      console.log('getUserDashDatagetUserDashDatagetUserDashDatagetUserDashDatagetUserDashData', userId);
      const user = await User.findByPk(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
     
      const balance = await UserBalance.findOne({
        where: { user_id: userId },
        attributes: ['current_balance'],
      });

      const userPointBalance = await UserPointBalance.findOne({
        where: { user_id: userId },
        attributes: ['points'],
      });

      const userLevel = await Level.findByPk(user.level_id, {
        attributes: ['short_code']
      });
      const levelShortCode = userLevel ? userLevel.short_code : null;
   
      const balanceValue = balance ? balance.current_balance : 0;
      const pointsValue = userPointBalance ? userPointBalance.points : 0;

      res.status(200).json({
        message: 'User dashboard data retrieved successfully',
        user: {
          id: user.id,
          username: user.username,
          balance: balanceValue,
          coins: pointsValue,
          level: levelShortCode,
          avatar: `https://ui-avatars.com/api/?name=${user.username}&background=random`
        }
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }



  async updateGenerations(parentUserId, newUserId, generationLevel, transaction) {
    if (generationLevel > 3) return; // Stop after the third generation

    // Update generation based on the level
    switch (generationLevel) {
      case 1:
        await this.updateGenerationRecord(FirstGeneration, parentUserId, newUserId, 10, transaction);
        break;
      case 2:
        await this.updateGenerationRecord(SecondGeneration, parentUserId, newUserId, 20, transaction);
        break;
      case 3:
        await this.updateGenerationRecord(ThirdGeneration, parentUserId, newUserId, 30, transaction);
        break;
      default:
        console.log('No generation record created');
    }

    // Find the parent of the current parent user and update recursively
    const parentUserRecord = await ParentUser.findOne({
      where: { user_id: parentUserId },
      transaction
    });
    if (parentUserRecord && parentUserRecord.parent_user_id) {
      await this.updateGenerations(parentUserRecord.parent_user_id, newUserId, generationLevel + 1, transaction);
    }
  }

  async updateGenerationRecord(Model, parentUserId, newUserId, maxReferrals, transaction) {
    try {
      const existingRecord = await Model.findOne({ where: { user_id: parentUserId }, transaction });
      let referralUsers = [];

      if (existingRecord) {
        if (typeof existingRecord.referral_users === 'string') {
          referralUsers = JSON.parse(existingRecord.referral_users);
        } else if (Array.isArray(existingRecord.referral_users)) {
          referralUsers = [...existingRecord.referral_users];
        }
      }

      // Prevent duplicates
      if (!referralUsers.includes(newUserId)) {
        referralUsers.push(newUserId);
      }

      if (existingRecord) {
        await existingRecord.update(
          { referral_users: referralUsers },
          { transaction }
        );
      } else {
        await Model.create(
          {
            user_id: parentUserId,
            referral_users: referralUsers
          },
          { transaction }
        );
      }
      console.log('Updated referral users:', referralUsers);
    } catch (error) {
      console.error('Error in updateGenerationRecord:', error);
      throw error;
    }
  }

  async login(req, res) {
    try {
      // const { username, password } = req.body;
      // const user = await  User.findOne({ where: { username } });
      
      // if (!user) {
      //   return res.status(404).json({ error: 'User not found' });
      // }

      // // Compare passwords
      // const isMatch = await bcrypt.compare(password, user.password);
      // if (!isMatch) {
      //   return res.status(401).json({ error: 'Invalid credentials' });
      // }
      if (!(req.user instanceof User)) {
        return res.status(403).json({ error: 'Unauthorized' });
      }

      const userr = await User.findByPk(req.user.id, {
        attributes: ['level_id', 'status', 'lockout_until'],
        include: [
          { 
            model: Level,
            attributes: ['short_code'] }
        ]
      });

      console.log("userr.statususerr.statususerr.statususerr.status", userr.status)
      if(userr.status === 'LockeOut'){
        return res.status(403).json({ error: `Account locked until ${userr.lockout_until}. Try again later.` });
      }
      const userBalance = await UserBalance.findOne({ where: { user_id: req.user.id } });
      
      const userPointBalance = await UserPointBalance.findOne({ where: { user_id: req.user.id } });

      const cashWithdrawHistory = await CashWithdrawHistory.findAll(
        {
          where: { 
            user_id: req.user.id,
            status: 'pending'
          }
        }
      );

      const totalAmount = cashWithdrawHistory.reduce((sum, record) => {
        return sum + (record.amount || 0); 
       }, 0);

      

      const levelShortCode = userr.Level ? userr.Level.short_code : 'VIP 0';
      const available_balance = userBalance ? userBalance.current_balance : 0;
      const coins = userPointBalance ? userPointBalance.points : 0;
      const blocked_amount = totalAmount? totalAmount : 0;
      const first_generation_balance = userBalance ? userBalance.total_first_node_balance : 0;
      const second_generation_balance = userBalance ? userBalance.total_second_node_balance : 0;
      const third_generation_balance = userBalance ? userBalance.total_third_balance : 0;
      const p2pCredit = userBalance ? userBalance.p2p_credit : 0;
      const p2pDebit = userBalance ? userBalance.p2p_debit : 0;
      const point_selling = userBalance ? userBalance.point_selling_credit : 0;
      const withdraw_up_to_date = userBalance ? userBalance.withdraw_up_to_date : 0;

      req.session.userSession = req.user; // Set user session
      res.status(200).json({ 
        message: 'Login successful', 
        user: {
          id: req.user.id,
          username: req.user.username,
          level: levelShortCode,
          available_balance: available_balance,
          coins: coins,
          blocked_amount: blocked_amount,
          first_generation_balance: first_generation_balance,
          second_generation_balance: second_generation_balance,
          third_generation_balance: third_generation_balance,
          p2pCredit: p2pCredit,
          p2pDebit: p2pDebit,
          point_selling: point_selling,
          withdraw_up_to_date: withdraw_up_to_date,
          role: 'user'
        }
      });


      // res.status(200).json({ 
      //   message: 'Login successful', 
      //   user: { 
      //     id: user.id, 
      //     username: user.username 
      //   } 
      // });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async getReferralTree(req, res) {
    try {
      if(!req.user) {
        return res.status(401).json({ error: 'Unauthorized' });
      }

      console.log("req.userreq.userreq.userreq.user",req.user);
      const userId = req.user.id;
     // const { userId } = req.params;
  
      // Helper function to get user details with parent and level
      const getUserDetailsWithParentAndLevel = async (userIds) => {
        if (!userIds || userIds.length === 0) return [];
  
        const users = await User.findAll({
          where: { id: { [Op.in]: userIds } },
          include: [
            { model: Level, attributes: ['amount', 'short_code'] },
            { 
              model: User, 
              as: 'Children', 
              attributes: ['id', 'username']
            }
          ],
          attributes: ['id', 'username', 'parent_user_id']
        });
  
        // Get parent details separately
        const usersWithParent = await Promise.all(users.map(async (u) => {
          let parent = null;
          if (u.parent_user_id) {
            const parentUser = await User.findByPk(u.parent_user_id, {
              attributes: ['username']
            });
            parent = parentUser ? { username: parentUser.username } : null;
          }
  
          return {
            id: u.id,
            username: u.username,
            level: u.Level ? {
              amount: u.Level.amount,
              short_code: u.Level.short_code
            } : null,
            parent: parent
          };
        }));
  
        return usersWithParent;
      };
  
      // Main user with level
      const user = await User.findByPk(userId, {
        include: [{ model: Level, attributes: ['amount', 'short_code'] }]
      });
  
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
  
      // Get parent information
      let parent = null;
      if (user.parent_user_id) {
        const parentUser = await User.findByPk(user.parent_user_id, {
          include: [{ model: Level, attributes: ['amount', 'short_code'] }],
          attributes: ['id', 'username']
        });
  
        parent = parentUser ? {
          id: parentUser.id,
          username: parentUser.username,
          level: parentUser.Level ? {
            amount: parentUser.Level.amount,
            short_code: parentUser.Level.short_code
          } : null
        } : null;
      }
  
      // Process generations
      const processGeneration = async (generationModel, userId) => {
        const generation = await generationModel.findOne({
          where: { user_id: userId }
        });
  
        if (!generation) return { referral_users: [], paid_referral_users: [] };
  
        const referralUsers = Array.isArray(generation.referral_users)
          ? generation.referral_users
          : typeof generation.referral_users === 'string'
            ? JSON.parse(generation.referral_users)
            : [];
  
        const paidReferralUsers = Array.isArray(generation.paid_referral_users)
          ? generation.paid_referral_users
          : typeof generation.paid_referral_users === 'string'
            ? JSON.parse(generation.paid_referral_users)
            : [];
  
        const referralsWithDetails = await getUserDetailsWithParentAndLevel(referralUsers);
        const paidReferralsWithDetails = await getUserDetailsWithParentAndLevel(paidReferralUsers);
  
        return {
          referral_users: referralsWithDetails,
          paid_referral_users: paidReferralsWithDetails
        };
      };
  
      // Get generations details
      const firstGeneration = await processGeneration(FirstGeneration, userId);
      const secondGeneration = await processGeneration(SecondGeneration, userId);
      const thirdGeneration = await processGeneration(ThirdGeneration, userId);
  
      // Construct response with simplified level details
      const response = {
        user: {
          id: user.id,
          username: user.username,
          level: user.Level ? {
            amount: user.Level.amount,
            short_code: user.Level.short_code
          } : null
        },
        parent: parent,
        first_generation: firstGeneration,
        second_generation: secondGeneration,
        third_generation: thirdGeneration
      };
  
      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching referral tree:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async getReferralTreeById(req, res) {
    try {
      const userId = req.params.id;
     // const { userId } = req.params;
  
      // Helper function to get user details with parent and level
      const getUserDetailsWithParentAndLevel = async (userIds) => {
        if (!userIds || userIds.length === 0) return [];
  
        const users = await User.findAll({
          where: { id: { [Op.in]: userIds } },
          include: [
            { model: Level, attributes: ['amount', 'short_code'] },
            { 
              model: User, 
              as: 'Children', 
              attributes: ['id', 'username']
            }
          ],
          attributes: ['id', 'username', 'parent_user_id']
        });
  
        // Get parent details separately
        const usersWithParent = await Promise.all(users.map(async (u) => {
          let parent = null;
          if (u.parent_user_id) {
            const parentUser = await User.findByPk(u.parent_user_id, {
              attributes: ['username']
            });
            parent = parentUser ? { username: parentUser.username } : null;
          }
  
          return {
            id: u.id,
            username: u.username,
            level: u.Level ? {
              amount: u.Level.amount,
              short_code: u.Level.short_code
            } : null,
            parent: parent
          };
        }));
  
        return usersWithParent;
      };
  
      // Main user with level
      const user = await User.findByPk(userId, {
        include: [{ model: Level, attributes: ['amount', 'short_code'] }]
      });
  
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
  
      // Get parent information
      let parent = null;
      if (user.parent_user_id) {
        const parentUser = await User.findByPk(user.parent_user_id, {
          include: [{ model: Level, attributes: ['amount', 'short_code'] }],
          attributes: ['id', 'username']
        });
  
        parent = parentUser ? {
          id: parentUser.id,
          username: parentUser.username,
          level: parentUser.Level ? {
            amount: parentUser.Level.amount,
            short_code: parentUser.Level.short_code
          } : null
        } : null;
      }
  
      // Process generations
      const processGeneration = async (generationModel, userId) => {
        const generation = await generationModel.findOne({
          where: { user_id: userId }
        });
  
        if (!generation) return { referral_users: [], paid_referral_users: [] };
  
        const referralUsers = Array.isArray(generation.referral_users)
          ? generation.referral_users
          : typeof generation.referral_users === 'string'
            ? JSON.parse(generation.referral_users)
            : [];
  
        const paidReferralUsers = Array.isArray(generation.paid_referral_users)
          ? generation.paid_referral_users
          : typeof generation.paid_referral_users === 'string'
            ? JSON.parse(generation.paid_referral_users)
            : [];
  
        const referralsWithDetails = await getUserDetailsWithParentAndLevel(referralUsers);
        const paidReferralsWithDetails = await getUserDetailsWithParentAndLevel(paidReferralUsers);
  
        return {
          referral_users: referralsWithDetails,
          paid_referral_users: paidReferralsWithDetails
        };
      };
  
      // Get generations details
      const firstGeneration = await processGeneration(FirstGeneration, userId);
      const secondGeneration = await processGeneration(SecondGeneration, userId);
      const thirdGeneration = await processGeneration(ThirdGeneration, userId);
  
      // Construct response with simplified level details
      const response = {
        user: {
          id: user.id,
          username: user.username,
          level: user.Level ? {
            amount: user.Level.amount,
            short_code: user.Level.short_code
          } : null
        },
        parent: parent,
        first_generation: firstGeneration,
        second_generation: secondGeneration,
        third_generation: thirdGeneration
      };
  
      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching referral tree:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async  getPaidReferralCommissions(req, res) {
    try {
      const userId = req.user.id;
  
      // Fetch the parent (base) user with its level details.
      const parentUser = await User.findByPk(userId, {
        include: [{ model: Level, attributes: ['amount', 'short_code', 'createdAt'] }]
      });
  
      if (!parentUser) {
        return res.status(404).json({ error: 'User not found' });
      }
      if (!parentUser.Level) {
        return res.status(400).json({ error: 'Parent user has no level assigned' });
      }
  
      const parentAmount = parentUser.Level.amount; // X value
  
      // Commission calculation helper using your formula.
      function calculateCommission(X, Y, parentLevel) {
        if (parentLevel < 1 || parentLevel > 3) {
          return null;
        }
        let baseRate, bonusRate;
        switch (parentLevel) {
          case 1:
            baseRate = new Decimal(0.25);
            bonusRate = new Decimal(0.022);
            break;
          case 2:
            baseRate = new Decimal(0.15);
            bonusRate = new Decimal(0.015);
            break;
          case 3:
            baseRate = new Decimal(0.10);
            bonusRate = new Decimal(0.01);
            break;
        }
        const decimalX = new Decimal(X);
        const decimalY = new Decimal(Y);
        if (decimalY.lte(decimalX)) {
          return decimalY.mul(baseRate).toNumber();
        } else {
          const commission = decimalX.mul(baseRate).plus(decimalY.sub(decimalX).mul(bonusRate));
          return commission.toNumber();
        }
      }
  
      // Generic function to process one generation.
      const processPaidReferrals = async (GenerationModel, generationNumber) => {
        const generationRecord = await GenerationModel.findOne({ where: { user_id: userId } });
        if (!generationRecord) return [];
  
        // Parse paid_referral_users (may be stored as JSON or a string)
        let paidReferralIds = [];
        if (Array.isArray(generationRecord.paid_referral_users)) {
          paidReferralIds = generationRecord.paid_referral_users;
        } else if (typeof generationRecord.paid_referral_users === 'string') {
          paidReferralIds = JSON.parse(generationRecord.paid_referral_users);
        }
  
        // For each referral id, fetch details and calculate commission.
        const paidReferrals = await Promise.all(
          paidReferralIds.map(async (referralId) => {
            const referralUser = await User.findByPk(referralId, {
              include: [{ model: Level, attributes: ['amount', 'short_code'] }]
            });
            if (!referralUser || !referralUser.Level) return null;
  
            const referralAmount = referralUser.Level.amount; // Y value
            const commission = calculateCommission(parentAmount, referralAmount, generationNumber);
  
            // Lookup the VerifyDeposit record for this referral user.
            const verifyDeposit = await VerifyDeposit.findOne({
              where: { user_id: referralUser.id },
              attributes: ['createdAt']
            });
            const subscriptionDate = verifyDeposit ? verifyDeposit.createdAt : null;
  
            return {
              username: referralUser.username,
              level: referralUser.Level.short_code,
              commission: commission,
              joinedTime: referralUser.createdAt,
              subscriptionDate: subscriptionDate
            };
          })
        );
  
        // Filter out any null values.
        return paidReferrals.filter((item) => item !== null);
      };
  
      // Process each generation.
      const firstGenerationPaid = await processPaidReferrals(FirstGeneration, 1);
      const secondGenerationPaid = await processPaidReferrals(SecondGeneration, 2);
      const thirdGenerationPaid = await processPaidReferrals(ThirdGeneration, 3);
  
      // Construct response.
      const response = {
        first_generation_paid: firstGenerationPaid,
        second_generation_paid: secondGenerationPaid,
        third_generation_paid: thirdGenerationPaid
      };
  
      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching paid referral commissions:', error);
      res.status(500).json({ error: error.message });
    }
  }
  



  async getTopUsersByTeamSize(req, res) {
    try {
      // Step 1: Fetch all users from the database
      const users = await User.findAll({
        attributes: ['id', 'username'], // Only fetch necessary attributes
      });
  
      // Check if any users exist
      if (!users || users.length === 0) {
        return res.status(404).json({ error: 'No users found' });
      }
  
      // Step 2: Helper function to count paid referrals for a given generation
      const getPaidReferralCount = async (GenerationModel, userId) => {
        const generationRecord = await GenerationModel.findOne({ where: { user_id: userId } });
        if (!generationRecord) return 0;
  
        let paidReferralIds = [];
        if (Array.isArray(generationRecord.paid_referral_users)) {
          paidReferralIds = generationRecord.paid_referral_users;
        } else if (typeof generationRecord.paid_referral_users === 'string') {
          try {
            paidReferralIds = JSON.parse(generationRecord.paid_referral_users);
          } catch (e) {
            console.error('Error parsing paid_referral_users:', e);
            return 0;
          }
        }
        return paidReferralIds.length; // Return the count of paid referrals
      };
  
      // Step 3: Calculate team size for each user in parallel
      const usersWithTeamSize = await Promise.all(
        users.map(async (user) => {
          const [firstGenCount, secondGenCount, thirdGenCount] = await Promise.all([
            getPaidReferralCount(FirstGeneration, user.id),
            getPaidReferralCount(SecondGeneration, user.id),
            getPaidReferralCount(ThirdGeneration, user.id),
          ]);
  
          const teamSize = firstGenCount + secondGenCount + thirdGenCount;
          return {
            id: user.id,
            username: user.username,
            teamSize: teamSize,
            avatar: `https://ui-avatars.com/api/?name=${user.username}&background=random`
          };
        })
      );
  
      // Step 4: Sort users by team size in descending order
      usersWithTeamSize.sort((a, b) => b.teamSize - a.teamSize);
  
      // Step 5: Select the top 5 users
      const top5Users = usersWithTeamSize.slice(0, 5);
  
      // Step 6: Send the response with the top 5 users
      res.status(200).json(top5Users);
    } catch (error) {
      console.error('Error fetching top users by team size:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }


  async giveUp(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const {userId} = req.params;
      const user_id = userId;
    
      //1. validate user exists
      const user = await User.findByPk(user_id, { transaction });
    
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      if(user.status === 'Give_up') {
        return res.status(400).json({ error: 'User is already Give_up' });
      }

      // 2. Check parent status
      const parentUser = await ParentUser.findOne({
        where: { user_id },
        attributes: ['parent_user_id'],
        transaction
      });
      const hasParent = parentUser?.parent_user_id ? true : false;

      // 3. Check children status
      const hasChildren = await this.hasActiveReferrals(user_id, transaction);
      if (hasChildren) {
        return res.status(400).json({
          error: 'You cannot give up - you have active referrals'
        });
      }

       // 4. Determine eligibility
       let withdrawalPercentage = 0;
       if (!hasParent && !hasChildren) {
         withdrawalPercentage = 90;
       } else if (hasParent && !hasChildren) {
         withdrawalPercentage = 40;
       } else {
         return res.status(400).json({
           error: 'You are not eligible to give up'
         });
       }

        // 5. Calculate withdrawal amount
      const level = await Level.findByPk(user.level_id, { transaction });
      if (!level) {
        return res.status(400).json({ error: 'You are Not eligibe' });
      }
      
      const initialDeposit = new Decimal(level.amount);
      const withdrawalAmount = initialDeposit.mul(withdrawalPercentage).div(100);

      // 6. Create withdrawal request
      const paymentInfo = await this.getDefaultPaymentInfo(user_id, transaction);
      if (!paymentInfo) {
        return res.status(400).json({
          error: 'No payment information found. Please configure first'
        });
      }

      await User.update(
        { status: 'Give_up' },
        { 
          where: { id: user_id },
          transaction 
        }
      );

      await CashWithdrawHistory.create({
        payment_information_id: paymentInfo.id,
        amount: withdrawalAmount.toNumber(),
        status: 'Pending',
        reason: 'Give_up'
      }, { transaction });

      // 7. Update user status after approval (handled in withdrawal update)
      await transaction.commit();
      res.status(201).json({
        message: 'Give-up request submitted successfully',
        withdrawal_amount: withdrawalAmount.toNumber()
      });
  }
  catch (error) {
    await transaction.rollback();
    console.error('Give-up error:', error);
    res.status(500).json({ error: error.message });
  }

}

  async hasActiveReferrals(user_id, transaction) {
   
    const checks = [
        FirstGeneration.findOne({ 
            where: { 
                user_id, 
                paid_referral_users: { [Op.ne]: [] } 
            }, 
            transaction 
        }),
        SecondGeneration.findOne({ 
            where: { 
                user_id, 
                paid_referral_users: { [Op.ne]: [] } 
            }, 
            transaction 
        }),
        ThirdGeneration.findOne({ 
            where: { 
                user_id, 
                paid_referral_users: { [Op.ne]: [] } 
            }, 
            transaction 
        })
    ];

    const results = await Promise.all(checks);
    return results.some(result => result !== null);
}


  async getDefaultPaymentInfo(user_id, transaction) {
    return PaymentInformation.findOne({
      where: { user_id },
      order: [['createdAt', 'ASC']], // Get oldest payment info
      transaction
    });
  }


  async UserCanSellCoin(req,res) {
  
    const {childAmount, parentAmount} = req.body;
    if(!childAmount) {
      return res.status(200).json({ message: 'Specify the Amount' });
    }

    if(!parentAmount) {
      return res.status(200).json({ message: 'Specify the Amount' });
    } 

    let maximumSellAmount = 0;
    const systemBuyOneCoin = 22;

    let youCanSellWith = 0;
    if(parentAmount >= 25000 && childAmount >= 1000){
       maximumSellAmount = childAmount * 0.25;
       youCanSellWith = 22;
    }
    else if((parentAmount < 25000 && parentAmount >= 10000) && childAmount >= 3000){
       maximumSellAmount = (childAmount * 0.25) * 0.8;
       youCanSellWith = 20;
    }
    else if((parentAmount < 10000 && parentAmount >= 1000) && childAmount >= 3000){
      maximumSellAmount = (childAmount * 0.25) * 0.5;
      youCanSellWith = 18;
    }
    else if(parentAmount < 1000 && childAmount > 5000){
      maximumSellAmount = (childAmount * 0.25) * 0.5;
      youCanSellWith = 15;
    }
    else{
      return res.status(200).json({ message: `Your are not eligibale to sell coin` });
    }
    const userCanSellNumberOfCoin = Math.floor(maximumSellAmount / systemBuyOneCoin);
    return res.status(200).json({ message: `You can sell ${userCanSellNumberOfCoin} coins with 1 Coin = ${youCanSellWith} ETB` });
  }


  async  getTransactionHistory(req, res) {
    try {
      const userId  = req.user.id;
      console.log("getTransactionHistnHistorygetTransactionHistorygetTransactionHistorygetTransactionHistorygetTransactionHistorygetTransactionHistorygetTransactionHistory")
      
      // Get all recharge transactions from VerifyDeposit for the user
      const verifyDeposits = await VerifyDeposit.findAll({
        where: { user_id: userId },
        attributes: ['balance', 'createdAt', 'status']
      });

      console.log("verifyDeposits", verifyDeposits)
      //const newStatus = verifyDeposits[0].status === 'Accepted' ? 'Approved' : verifyDeposits[0].status;
      
      // Map recharge transactions to a unified format
      const rechargeTransactions = verifyDeposits.map(deposit => ({
        amount: deposit.balance,
        createdAt: deposit.createdAt,
        requestType: "Recharge",  // fixed value for recharges
        status: deposit.status    // status from VerifyDeposit
      }));
      
      // Get all cash withdrawal transactions for the user.
      // (Assuming payment_information_id refers to the user's PaymentInformation)
      const cashWithdrawals = await CashWithdrawHistory.findAll({
        where: { user_id: userId },
        attributes: ['amount', 'createdAt', 'reason', 'status', 'payment_information_id']
      });
      
      // Map cash withdrawal transactions to a unified format.
      const withdrawalTransactions = await Promise.all(
        cashWithdrawals.map(async (withdrawal) => {
          // Get PaymentInformation details using payment_information_id
          const paymentInfo = await PaymentInformation.findByPk(withdrawal.payment_information_id, {
            attributes: ['bank_name', 'account_number']
          });
          
          return {
            amount: withdrawal.amount,
            createdAt: withdrawal.createdAt,
            requestType: withdrawal.reason, // Either "Give_up" or "Withdraw"
            status: withdrawal.status,
            bank_name: paymentInfo ? paymentInfo.bank_name : null,
            account_number: paymentInfo ? paymentInfo.account_number : null
          };
        })
      );
      
      // Combine the two arrays
      const combinedTransactions = [
        ...rechargeTransactions,
        ...withdrawalTransactions
      ];
      
      // Sort the combined array in chronological order (oldest first)
      combinedTransactions.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
      
      res.status(200).json(combinedTransactions);
    } catch (error) {
      console.error("Error fetching transaction history:", error);
      res.status(500).json({ error: error.message });
    }
  }
  
  
  async findAll(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const users = await User.findAll({
        attributes: ['id', 'username', 'status'],
        include:[
          {
            model: Level,
            as: 'Level',
            attributes: ['id', 'short_code', 'amount']
          }
        ],
        transaction
      });
      await transaction.commit();
      res.status(200).json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ error: error.message });
    }
  }




  async findById(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const user = await User.findByPk(req.params.id, {
        attributes: ['id', 'username', 'status'],
        include: [
          {
            model: Level,
            as: 'Level', // Matches User.belongsTo(Level, { foreignKey: 'level_id' })
            attributes: ['id', 'short_code', 'amount']
          },
          {
            model: PaymentInformation,
            as: 'PaymentInformation', // Matches User.hasOne(PaymentInformation, { foreignKey: 'user_id' })
            attributes: ['id', 'bank_name', 'account_number']
          },
          {
            model: CashWithdrawHistory,
            attributes: ['id', 'amount', 'status'],
            include: [
              {
                model: AdminUser,
                as: 'AssignedAdmin', 
                attributes: ['id', 'username']
              },
              {
                model: BankAccountConfiguration,
                attributes: ['id', 'bank_name', 'account_number']
              }
            ]
          },
          {
            model: VerifyDeposit,
            attributes: ['id', 'balance', 'status', 'transaction_id']
          },
          {
            model: P2PPoints,
            as: 'SellingPoints', 
            attributes: ['id', 'unit_price', 'number_of_points', 'status'],
            include: [
                {
                    model: User,
                    as: 'Buyer', 
                    attributes: ['id', 'username']
                }
            ]
        },
          {
            model: P2PPoints,
            as: 'PurchasedPoints', // Matches User.hasMany(P2PPoints, { foreignKey: 'buyer_id', as: 'PurchasedPoints' })
            attributes: ['id', 'unit_price', 'number_of_points', 'status'],
            include: [
              {
                model: User,
                as: 'Seller', // Matches P2PPoints.belongsTo(User, { foreignKey: 'buyer_id', as: 'Buyer' })
                attributes: ['id', 'username']
              }
            ]
          }
        ],
        transaction
      });
  
      await transaction.commit();
  
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
  
      res.status(200).json(user);
    } catch (error) {
      await transaction.rollback();
      console.error("Error fetching user:", error);
      res.status(500).json({ error: error.message });
    }
  }





}

module.exports = new UserController();