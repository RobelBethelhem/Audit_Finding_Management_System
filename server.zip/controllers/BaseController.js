class BaseController {
  constructor(model) {
    this.model = model;
  }

  async create(req, res) {
    try {
       
      const item = await this.model.create(req.body);
      res.status(201).json(item);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  async findAll(req, res) {
    try {
      const items = await this.model.findAll();
      res.status(200).json(items);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async findById(req, res) {
    try {
      const item = await this.model.findByPk(req.params.id);
      if (!item) {
        return res.status(404).json({ error: 'Item not found' });
      }
      res.status(200).json(item);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async update(req, res) {
    try {
      const [updated] = await this.model.update(req.body, {
        where: { id: req.params.id }
      });
      if (updated) {
        const updatedItem = await this.model.findByPk(req.params.id);
        return res.status(200).json(updatedItem);
      }
      throw new Error('Item not found');
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  async delete(req, res) {
    try {
      const deleted = await this.model.destroy({
        where: { id: req.params.id }
      });
      if (deleted) {
        return res.status(204).json({ message: 'Item deleted successfully' });
      }
      throw new Error('Item not found');
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }



  



}

module.exports = BaseController;