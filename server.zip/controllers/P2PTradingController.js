const { P2PPoints, UserPointBalance, UserBalance,User, P2PLimit, P2PSellBuyConfiguration, sequelize } = require('../models');
const Decimal = require('decimal.js');
const { Op } = require('sequelize');

class P2PTradingController {

// Seller creates a sell offer.
async createSellOffer(req, res) {
    const transaction = await sequelize.transaction();
    try {
          const seller_id = req.user.id;
          req.body.seller_id = seller_id;
          const { number_of_points, unit_price } = req.body;

          // Validate required fields.
          if (!number_of_points || !unit_price) {
            await transaction.rollback();
            return res.status(400).json({ error: 'number_of_points, and unit_price are required' });
          }
      
          // Ensure the number of points is a positive integer.
          const pointsToSell = parseInt(number_of_points, 10);
          if (isNaN(pointsToSell) || pointsToSell <= 0) {
            await transaction.rollback();
            return res.status(400).json({ error: 'number_of_points must be a positive integer' });
          }
      
          // Validate and parse unit_price.
          const price = new Decimal(unit_price);
          if (price.isNaN() || price.lte(0)) {
            await transaction.rollback();
            return res.status(400).json({ error: 'unit_price must be a number greater than 0' });
          }


           // --------------------- NEW VALIDATION LOGIC ---------------------
           // 1. Check P2PLimit.
        const p2pLimit = await P2PLimit.findOne({ transaction }); // Assuming you only have one P2PLimit record
        if (!p2pLimit) {
            await transaction.rollback();
            return res.status(500).json({ error: 'P2PLimit not configured. Contact administrator.' });
        }

        if (pointsToSell < p2pLimit.min_amount || pointsToSell > p2pLimit.max_amount) {
            await transaction.rollback();
            return res.status(400).json({ error: `number_of_points must be between ${p2pLimit.min_amount} and ${p2pLimit.max_amount}` });
        }


        console.log("Price", price);
        console.log("p2pLimit.min_price", p2pLimit.min_price);
        console.log("p2pLimit.max_price", p2pLimit.max_price);


        const priceNum = Number(price);
        const minPriceNum = Number(p2pLimit.min_price);
        const maxPriceNum = Number(p2pLimit.max_price);

        if (isNaN(priceNum) || isNaN(minPriceNum) || isNaN(maxPriceNum)) {
            await transaction.rollback();
            return res.status(400).json({ error: "Invalid price or limit value." });
        }


        if (priceNum < minPriceNum || priceNum > maxPriceNum) {
            await transaction.rollback();
            return res.status(400).json({ error: `unit_price must be between ${p2pLimit.min_price} and ${p2pLimit.max_price}` });
        }

        // if (price < p2pLimit.min_price || price > p2pLimit.max_price) {
        //     await transaction.rollback();
        //     return res.status(400).json({ error: `unit_price must be between ${p2pLimit.min_price} and ${p2pLimit.max_price}` });
        // }

         // 2. Get user's level_id and check P2PSellBuyConfiguration.

         const user = await User.findByPk(seller_id, { transaction }); //Get user
         if (!user) {
           await transaction.rollback();
           return res.status(404).json({error: "user not found"});
         }
 
         const userLevelId = user.level_id;
         const sellConfig = await P2PSellBuyConfiguration.findOne({
             where: { level_id: userLevelId },
             transaction
         });
 
         if (!sellConfig) {
             await transaction.rollback();
             return res.status(400).json({ error: 'Please wait, the selling limit is not configured for your level.' });
         }
 
         const sellLimit = sellConfig.sell_limit;


          // 3. Check if user has exceeded sell_limit for today.
        const today = new Date();
        today.setHours(0, 0, 0, 0); // Start of today
        const tomorrow = new Date(today);
        tomorrow.setDate(today.getDate() + 1); // Start of tomorrow



        const sellsTodayCount = await P2PPoints.count({
            where: {
                seller_id: seller_id,
                createdAt: {
                    [Op.gte]: today,
                    [Op.lt]: tomorrow
                }
            },
            transaction
        });

        if (sellsTodayCount >= sellLimit) {
            await transaction.rollback();
            return res.status(400).json({ error: `You have reached your daily selling limit of ${sellLimit} offers.` });
        }



      
          // Calculate Total_amount.
          const totalAmount = price.mul(pointsToSell);
          
          // Check that the seller has enough points.
          const sellerPointBalance = await UserPointBalance.findOne({
            where: { user_id: seller_id },
            transaction
          });
          if (!sellerPointBalance) {
            await transaction.rollback();
            return res.status(404).json({ error: 'Seller point balance not found' });
          }
          if (sellerPointBalance.points < pointsToSell) {
            await transaction.rollback();
            return res.status(400).json({ error: 'Insufficient points in seller balance' });
          }


      
        // Create the sell offer with status "Pending".
        const sellOffer = await P2PPoints.create({
          seller_id,
          number_of_points: pointsToSell,
          unit_price: price.toFixed(2),
          Total_amount: totalAmount.toFixed(2),
          status: 'Pending'
        }, { transaction });
      
          await transaction.commit();
          return res.status(201).json({
            message: 'Sell offer created successfully',
            data: sellOffer
          });
        } catch (error) {
          await transaction.rollback();
          console.error("Error in createSellOffer:", error);
          return res.status(500).json({ error: error.message });
        }
}

// Endpoint to get all pending sell offers.
async getPendingOffers(req, res) {
    try {
      const offers = await P2PPoints.findAll(
        {
          where: {
            status: 'Pending'
          },
          include: [
            {
              model: User,
              as: 'Seller',
              attributes: ['username']
            }
          ],
          attributes: ['id','number_of_points', 'unit_price', 'Total_amount', 'status', 'createdAt']
        }
      );

        return res.status(200).json(offers);
    } catch (error) {
        console.error("Error in getPendingOffers:", error);
        return res.status(500).json({ error: error.message });
    }
}

// Buyer purchases an offer.
async buyOffer(req, res) {
const transaction = await sequelize.transaction();
try {
const { id } = req.params; // offer id from URL parameter.
const buyer_id = req.user.id;

  if (!buyer_id) {
    await transaction.rollback();
    return res.status(400).json({ error: 'buyer_id is required' });
  }
  
  // Retrieve the offer; it must be pending.
  const offer = await P2PPoints.findOne({
    where: { id, status: 'Pending' },
    transaction
  });
  if (!offer) {
    await transaction.rollback();
    return res.status(404).json({ error: 'Offer not found or not available' });
  }
  
  // Optionally, prevent a seller from buying his own offer.
  if (offer.seller_id === buyer_id) {
    await transaction.rollback();
    return res.status(400).json({ error: 'Seller cannot buy their own offer' });
  }
  
  const totalAmount = new Decimal(offer.Total_amount);
  const pointsToTransfer = offer.number_of_points;
  
  // Check that the buyer has sufficient financial balance.
  const buyerBalance = await UserBalance.findOne({
    where: { user_id: buyer_id },
    transaction
  });
  if (!buyerBalance) {
    await transaction.rollback();
    return res.status(404).json({ error: 'Buyer balance not found' });
  }
  if (new Decimal(buyerBalance.current_balance).lt(totalAmount)) {
    await transaction.rollback();
    return res.status(400).json({ error: 'Buyer has insufficient funds to complete purchase' });
  }
  
  // Double-check seller’s point balance in case it has changed.
  const sellerPointBalance = await UserPointBalance.findOne({
    where: { user_id: offer.seller_id },
    transaction
  });
  if (!sellerPointBalance) {
    await transaction.rollback();
    return res.status(404).json({ error: 'Seller point balance not found' });
  }
  if (sellerPointBalance.points < pointsToTransfer) {
    await transaction.rollback();
    return res.status(400).json({ error: 'Seller does not have enough points to sell' });
  }

   //--------------- NEW VALIDATION FOR BUYER-----------------------
    // 1. Get buyer's level_id and check P2PSellBuyConfiguration.

    const buyer = await User.findByPk(buyer_id, { transaction }); //Get buyer
    if (!buyer) {
      await transaction.rollback();
      return res.status(404).json({error: "buyer not found"});
    }

    const buyerLevelId = buyer.level_id;
    const buyConfig = await P2PSellBuyConfiguration.findOne({
        where: { level_id: buyerLevelId },
        transaction
    });

    if (!buyConfig) {
        await transaction.rollback();
        return res.status(400).json({ error: 'Please wait, the buying limit is not configured for your level.' });
    }

    const buyLimit = buyConfig.buy_limit;


     // 2. Check if user has exceeded buy_limit for today.
     const today = new Date();
     today.setHours(0, 0, 0, 0); // Start of today
     const tomorrow = new Date(today);
     tomorrow.setDate(today.getDate() + 1); // Start of tomorrow

     const buysTodayCount = await P2PPoints.count({
         where: {
             buyer_id: buyer_id,
             createdAt: {
                 [Op.gte]: today,
                 [Op.lt]: tomorrow
             }
         },
         transaction
     });

     if (buysTodayCount >= buyLimit) {
         await transaction.rollback();
         return res.status(400).json({ error: `You have reached your daily buying limit of ${buyLimit} offers.` });
     }








  
  // Deduct points from the seller's point balance.
  sellerPointBalance.points = sellerPointBalance.points - pointsToTransfer;
  await sellerPointBalance.save({ transaction });
  
  // Add points to the buyer's point balance.
  let buyerPointBalance = await UserPointBalance.findOne({
    where: { user_id: buyer_id },
    transaction
  });
  if (!buyerPointBalance) {
    // Optionally, create the buyer's point balance record if none exists.
    buyerPointBalance = await UserPointBalance.create({
      user_id: buyer_id,
      points: 0
    }, { transaction });
  }
  buyerPointBalance.points = buyerPointBalance.points + pointsToTransfer;
  await buyerPointBalance.save({ transaction });
  
  // Update seller's financial balance.
  let sellerBalance = await UserBalance.findOne({
    where: { user_id: offer.seller_id },
    transaction
  });
  if (!sellerBalance) {
    // Optionally, create the seller's financial balance record if none exists.
    sellerBalance = await UserBalance.create({
      user_id: offer.seller_id,
      p2p_credit: 0,
      current_balance: 0,
      p2p_debit: 0,
      total_first_node_balance: 0,
      total_second_node_balance: 0,
      total_third_balance: 0,
      withdraw_up_to_date: 0,
      point_selling_credit: 0
    }, { transaction });
  }
  // Increase seller’s p2p_credit.
  sellerBalance.p2p_credit = new Decimal(sellerBalance.p2p_credit).plus(totalAmount).toFixed(2);
  // Recalculate the seller’s current_balance.
  sellerBalance.current_balance = new Decimal(sellerBalance.total_first_node_balance)
      .plus(new Decimal(sellerBalance.total_second_node_balance))
      .plus(new Decimal(sellerBalance.total_third_balance))
      .minus(new Decimal(sellerBalance.p2p_debit))
      .plus(new Decimal(sellerBalance.p2p_credit))
      .minus(new Decimal(sellerBalance.withdraw_up_to_date))
      .plus(new Decimal(sellerBalance.point_selling_credit))
      .toFixed(2);
  await sellerBalance.save({ transaction });
  
  // Update buyer's financial balance.
  buyerBalance.p2p_debit = new Decimal(buyerBalance.p2p_debit).plus(totalAmount).toFixed(2);
  buyerBalance.current_balance = new Decimal(buyerBalance.total_first_node_balance)
      .plus(new Decimal(buyerBalance.total_second_node_balance))
      .plus(new Decimal(buyerBalance.total_third_balance))
      .minus(new Decimal(buyerBalance.p2p_debit))
      .plus(new Decimal(buyerBalance.p2p_credit))
      .minus(new Decimal(buyerBalance.withdraw_up_to_date))
      .plus(new Decimal(buyerBalance.point_selling_credit))
      .toFixed(2);
  await buyerBalance.save({ transaction });
  
  // Mark the offer as Approved and set buyer_id.
  offer.buyer_id = buyer_id;
  offer.status = 'Approved';
  await offer.save({ transaction });
  
  await transaction.commit();
  return res.status(200).json({
    message: 'Offer purchased successfully',
    data: offer
  });
  
} catch (error) {
  await transaction.rollback();
  console.error("Error in buyOffer:", error);
  return res.status(500).json({ error: error.message });
}
}

async getUserApprovedOffers(req, res) {
  try {
    const userId = req.user.id;

    // Find all approved P2PPoints where the user is seller or buyer.
    const offers = await P2PPoints.findAll({
      where: {
        status: 'Approved',
        [Op.or]: [
          { seller_id: userId },
          { buyer_id: userId }
        ]
      }
    });

    const result = await Promise.all(
      offers.map(async (offer) => {
        let transactionType;
        let otherUserName = null;

        // Determine role and fetch the other party's username.
        if (offer.seller_id === userId) {
          transactionType = "Credit";
          if (offer.buyer_id) {
            const buyer = await User.findByPk(offer.buyer_id, {
              attributes: ['username']
            });
            otherUserName = buyer ? buyer.username : null;
          }
        } else if (offer.buyer_id === userId) {
          transactionType = "Debit";
          const seller = await User.findByPk(offer.seller_id, {
            attributes: ['username']
          });
          otherUserName = seller ? seller.username : null;
        }

        return {
          offerId: offer.id,
          otherUserName, // username of the counterparty
          number_of_points: offer.number_of_points,
          unit_price: offer.unit_price,
          total_amount: offer.Total_amount,
          transactionType,
          createdAt: offer.createdAt
        };
      })
    );

    res.status(200).json(result);
  } catch (error) {
    console.error("Error fetching user approved offers:", error);
    res.status(500).json({ error: error.message });
  }
}


async getUserP2POffers(req, res) {
  try {
    const userId  = req.user.id;

    // Find all approved P2PPoints where the user is seller or buyer.
    const offers = await P2PPoints.findAll({
      where: {
        [Op.or]: [
          { seller_id: userId },
          { buyer_id: userId }
        ]
      }
    });

    const result = await Promise.all(
      offers.map(async (offer) => {
        let transactionType;
        let otherUserName = null;

        // Determine role and fetch the other party's username.
        if (offer.seller_id === userId) {
          transactionType = "Credit";
          if (offer.buyer_id) {
            const buyer = await User.findByPk(offer.buyer_id, {
              attributes: ['username']
            });
            otherUserName = buyer ? buyer.username : null;
          }
        } else if (offer.buyer_id === userId) {
          transactionType = "Debit";
          const seller = await User.findByPk(offer.seller_id, {
            attributes: ['username']
          });
          otherUserName = seller ? seller.username : null;
        }

        return {
          offerId: offer.id,
          otherUserName, // username of the counterparty
          number_of_points: offer.number_of_points,
          unit_price: offer.unit_price,
          total_amount: offer.Total_amount,
          transactionType,
          status: offer.status,
          createdAt: offer.createdAt
        };
      })
    );

    res.status(200).json(result);
  } catch (error) {
    console.error("Error fetching user approved offers:", error);
    res.status(500).json({ error: error.message });
  }
}


async getHistory(req, res) {
  try {
    const history = await P2PPoints.findAll({
      include: [
        {
          model: User,
          as: 'Seller',
          attributes: ['username']
        },
        {
          model: User,
          as: 'Buyer',
          attributes: ['username']
        }
      ]
    });
    res.status(200).json(history);
  } catch (error) {
    console.error("Error fetching history:", error);
    res.status(500).json({ error: error.message });
  }
}


}

module.exports = new P2PTradingController();