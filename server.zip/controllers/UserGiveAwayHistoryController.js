const BaseController = require('./BaseController');
const { UserGiveAwayHistory, User, UserAssignedToTaskGiveAwayPackage, TaskGiveAwayPackage,sequelize } = require('../models'); // Import necessary models

const { Op } = require('sequelize');

class UserGiveAwayHistoryController extends BaseController {
    constructor() {
        super(UserGiveAwayHistory);
        console.log('UserGiveAwayHistoryController initialized');
    }

    // Custom create with validation (and Transaction)
    // async create(req, res) {
    //     let transaction;
    //     try {
            

    //         transaction = await sequelize.transaction();
    //         req.body.user_id = req.user.id;

    //         const { username, user_id } = req.body; // Expect user_id from frontend

    //         const refferedUser = await User.findOne({
    //             where: { username },
    //             transaction
    //         });

    //         // Validate input
    //         if (!username || !user_id) { //Validate username and userId
    //             return res.status(400).json({ error: 'Username and user_id are required' });
    //         }

    //         // Validate that refferedUser exists in the User model
    //     if (!refferedUser) {
    //         return res.status(400).json({ error: 'Referred user does not exist.' });
    //     }

    //         // Validate that reffered_user_id exists in the User model
    //         const existingRefferedUser = await User.findByPk(refferedUser.id, { transaction });
    //         if (!existingRefferedUser) {
    //             return res.status(400).json({ error: 'reffered_user_id does not exist in User model' });
    //         }

    //         // Validate that user_id exists in the User model
    //         const existingUser = await User.findByPk(user_id, { transaction });
    //         if (!existingUser) {
    //             return res.status(400).json({ error: 'user_id does not exist in User model' });
    //         }

    //         // --- Fetch UserAssignedToTaskGiveAwayPackage for the given user that is currently active ---
    //         const today = new Date();
    //         const startDate = new Date();

    //         const userAssignedPackage = await UserAssignedToTaskGiveAwayPackage.findOne({
    //             where: {
    //                 user_id: user_id,
    //                 start_date: { [Op.lte]: today }, // startDate <= today
    //             },
    //             transaction,
    //             include: [{
    //                 model: TaskGiveAwayPackage,
    //                 as: 'TaskGiveAwayPackage',
    //                 where: {
    //                     status: 'Active' //Ensure that the package is "Active"
    //                 }
    //             }]
    //         });

    //         if (!userAssignedPackage) {
    //             return res.status(400).json({ error: 'No active UserAssignedToTaskGiveAwayPackage found for the given user' });
    //         }

    //         const user_assigned_to_task_give_away_package_id = userAssignedPackage.id;
    //         const taskGiveAwayPackage = userAssignedPackage.TaskGiveAwayPackage;

    //         // --- Check if the package is still within its active period ---
    //         const endDate = new Date(userAssignedPackage.start_date);
    //         endDate.setDate(endDate.getDate() + taskGiveAwayPackage.active_days); // Calculate end date
    //         if (today > endDate) {
    //             await transaction.rollback();
    //             return res.status(400).json({ error: 'The assigned TaskGiveAwayPackage is no longer active' });
    //         }

    //         // ----Validate Referral Limit (per day)----
    //         const todayStart = new Date();
    //         todayStart.setHours(0, 0, 0, 0);
    //         const todayEnd = new Date();
    //         todayEnd.setHours(23, 59, 59, 999);

    //         const referralCount = await UserGiveAwayHistory.count({
    //             where: {
    //                 user_assigned_to_task_give_away_package_id: user_assigned_to_task_give_away_package_id,
    //                 date: {
    //                     [Op.gte]: todayStart,
    //                     [Op.lte]: todayEnd
    //                 }
    //             },
    //             transaction
    //         });

    //         if (referralCount >= taskGiveAwayPackage.refferal_limit) {
    //             await transaction.rollback();
    //             return res.status(400).json({ error: `Referral limit reached for this package. Limit is ${taskGiveAwayPackage.refferal_limit}` });
    //         }

    //         // Set the System Date
    //         const date = new Date();

    //         // Create UserGiveAwayHistory record
    //         const item = await UserGiveAwayHistory.create({
    //             reffered_user_id,
    //             user_assigned_to_task_give_away_package_id,
    //             date: date, //Use current system timestamp
    //             status: 'Pending'
    //         }, { transaction });

    //         await transaction.commit(); // Commit the transaction if everything is successful
    //         return res.status(201).json({
    //             message: 'User Give Away History created successfully',
    //             data: item
    //         });

    //     } catch (error) {
    //         if (transaction) {
    //             await transaction.rollback(); // Rollback the transaction if any error occurs
    //         }
    //         console.error('UserGiveAwayHistory creation error:', error);
    //         res.status(500).json({ error: error.message });
    //     }
    // }


    async create(req, res) {
        let transaction;
        try {
            transaction = await sequelize.transaction();
            req.body.user_id = req.user.id;
    
            const { username, user_id } = req.body; // Expect user_id from frontend
    
            // const refferedUser = await User.findOne({
            //     where: { username },
            //     transaction
            // });

            // const UserGiveAwayHistory = await UserGiveAwayHistory.findOne({
            //     where: { reffered_user_id: refferedUser.id },
            //     transaction
            // });

            // if (UserGiveAwayHistory) {
            //     await transaction.rollback();
            //     return res.status(400).json({ error: 'User Give Away History already exists' });
            // }


            const refferedUser = await User.findOne({
                where: { username },
                transaction
            });
            
            if (!refferedUser) {
                await transaction.rollback();
                return res.status(400).json({ error: 'Referred user does not exist.' });
            }
            
            const currentDate = new Date();
            const startOfDay = new Date(
                currentDate.getFullYear(),
                currentDate.getMonth(),
                currentDate.getDate()
            ); // Set time to 00:00:00
            
            const endOfDay = new Date(
                currentDate.getFullYear(),
                currentDate.getMonth(),
                currentDate.getDate() + 1
            ); // Set time to 00:00:00 of the NEXT day
            
            const userGiveAwayHistoryy = await UserGiveAwayHistory.findOne({
                where: {
                    reffered_user_id: refferedUser.id,
                    date: {
                        [Op.gte]: startOfDay,
                        [Op.lt]: endOfDay
                    }
                },
                transaction
            });
            
            if (userGiveAwayHistoryy) {
                await transaction.rollback();
                return res.status(400).json({ error: 'User Give Away History already exists for today' });
            }
            
    
            // Validate input
            if (!username || !user_id) { //Validate username and userId
                return res.status(400).json({ error: 'Username and user_id are required' });
            }
    
            // Validate that refferedUser exists in the User model
            if (!refferedUser) {
                return res.status(400).json({ error: 'Referred user does not exist.' });
            }
    
            const existingUser = await User.findByPk(user_id, { transaction });
            if (!existingUser) {
                return res.status(400).json({ error: 'user_id does not exist in User model' });
            }
    
    
            // --- Fetch UserAssignedToTaskGiveAwayPackage for the given user that is currently active ---
            const today = new Date();
            const startDate = new Date();
    
            const userAssignedPackage = await UserAssignedToTaskGiveAwayPackage.findOne({
                where: {
                    user_id: user_id,
                    start_date: { [Op.lte]: today }, // startDate <= today
                },
                transaction,
                include: [{
                    model: TaskGiveAwayPackage,
                    as: 'TaskGiveAwayPackage',
                    where: {
                        status: 'Active' //Ensure that the package is "Active"
                    }
                }]
            });
    
            if (!userAssignedPackage) {
                return res.status(400).json({ error: 'No User Invited Today' });
            }
    
            const user_assigned_to_task_give_away_package_id = userAssignedPackage.id;
            const taskGiveAwayPackage = userAssignedPackage.TaskGiveAwayPackage;
    
            // --- Check if the package is still within its active period ---
            const endDate = new Date(userAssignedPackage.start_date);
            endDate.setDate(endDate.getDate() + taskGiveAwayPackage.active_days); // Calculate end date
            if (today > endDate) {
                await transaction.rollback();
                return res.status(400).json({ error: 'The assigned TaskGiveAwayPackage is no longer active' });
            }
    
            // ----Validate Referral Limit (per day)----
            const todayStart = new Date();
            todayStart.setHours(0, 0, 0, 0);
            const todayEnd = new Date();
            todayEnd.setHours(23, 59, 59, 999);
    
            const referralCount = await UserGiveAwayHistory.count({
                where: {
                    user_assigned_to_task_give_away_package_id: user_assigned_to_task_give_away_package_id,
                    date: {
                        [Op.gte]: todayStart,
                        [Op.lte]: todayEnd
                    }
                },
                transaction
            });
    
            if (referralCount > taskGiveAwayPackage.refferal_limit) {
                await transaction.rollback();
                return res.status(400).json({ error: `Referral limit reached for this package. Limit is ${taskGiveAwayPackage.refferal_limit}` });
            }
    
            // Set the System Date
            const date = new Date();
    
            // Create UserGiveAwayHistory record
            const item = await UserGiveAwayHistory.create({
                reffered_user_id: refferedUser.id,
                user_assigned_to_task_give_away_package_id,
                date: date, //Use current system timestamp
                status: 'Pending'
            }, { transaction });
    
            await transaction.commit(); // Commit the transaction if everything is successful
            return res.status(201).json({
                message: 'User Give Away History created successfully',
                data: item
            });
    
        } catch (error) {
            if (transaction) {
                await transaction.rollback(); // Rollback the transaction if any error occurs
            }
            console.error('UserGiveAwayHistory creation error:', error);
            res.status(500).json({ error: error.message });
        }
    }



    // Custom update with validation (and explicit field definition and Transaction)
    async update(req, res) {
        let transaction;
        try {
            transaction = await sequelize.transaction(); // Start a transaction

            const { id } = req.params;
            const { status } = req.body; // Only status is updateable

            // Validate Status Enums
            if (status && !['Pending', 'Accepted'].includes(status)) {
                return res.status(400).json({error: 'Invalid Status Value: Status must be "Pending" or "Accepted"'})
            }

            // Build the update object, only including allowed fields
            const updateData = {};
            if (status) {
                updateData.status = status
            }

            const [updated] = await this.model.update(updateData, {
                where: { id: req.params.id },
                transaction
            });

            if (updated) {
                const updatedItem = await this.model.findByPk(req.params.id, { transaction });
                await transaction.commit(); // Commit the transaction
                return res.status(200).json(updatedItem);
            } else {
                await transaction.rollback(); // Rollback the transaction
                return res.status(404).json({ error: 'UserGiveAwayHistory not found' });
            }

        } catch (error) {
            if (transaction) {
                await transaction.rollback(); // Rollback the transaction if any error occurs
            }
            console.error('UserGiveAwayHistory update error:', error);
            res.status(500).json({ error: error.message });
        }
    }

    // Inherited methods (explicitly listed for clarity)
    async findAll(req, res) {
        try {
            const items = await this.model.findAll(
                {
                    include: [
                        {
                            model: User,
                            as: 'RefferedUser',
                            attributes: ['id', 'username']
                        },
                        {
                            model: UserAssignedToTaskGiveAwayPackage,
                            as: 'UserAssignedToTaskGiveAwayPackage',
                            attributes: ['id'],
                            include: [{
                                model: User,
                                as: 'User',
                                attributes: ['id', 'username']
                            }]
                        }
                
                ]
                }
            );
            return res.status(200).json(items);
        } catch (error) {
            console.error('UserGiveAwayHistory findAll error:', error);
            res.status(500).json({ error: error.message });
        }
    }

   async findByUserId(req, res) {
    try {
        const user_id = req.user.id; // Get user_id from req.user

        // --- Find UserAssignedToTaskGiveAwayPackage for the given user that is currently active ---
        const today = new Date();
        const startDate = new Date();

        const userAssignedPackage = await UserAssignedToTaskGiveAwayPackage.findOne({
            where: {
                user_id: user_id,
                //start_date: { [Op.lte]: today }, // startDate <= today
                start_date: { [Op.lte]: today },
            },
            include: [{
                model: TaskGiveAwayPackage,
                as: 'TaskGiveAwayPackage',
                where: {
                    status: 'Active' //Ensure that the package is "Active"
                }
            }]
        });

        if (!userAssignedPackage) {
            return res.status(404).json({ error: 'No User Invited Today' });
        }

        const user_assigned_to_task_give_away_package_id = userAssignedPackage.id;

        // --- Find UserGiveAwayHistory by user_assigned_to_task_give_away_package_id ---
        const userGiveAwayHistories = await UserGiveAwayHistory.findAll({
            where: {
                user_assigned_to_task_give_away_package_id: user_assigned_to_task_give_away_package_id
            },
            include: [{
                model: User,
                as: 'RefferedUser' // Include the RefferedUser association
            }]
        });

        if (!userGiveAwayHistories || userGiveAwayHistories.length === 0) {
            return res.status(404).json({ error: 'No UserGiveAwayHistory found for the given user and package' });
        }

        return res.status(200).json(userGiveAwayHistories);

    } catch (error) {
        console.error('Error finding UserGiveAwayHistory by user ID:', error);
        return res.status(500).json({ error: error.message });
    }
}

    async delete(req, res) {
        return super.delete(req, res);
    }
}

module.exports = new UserGiveAwayHistoryController();