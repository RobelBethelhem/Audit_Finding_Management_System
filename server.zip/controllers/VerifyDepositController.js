const BaseController = require('./BaseController');
const { 
  VerifyDeposit,
  User,
  Level ,
  UserBalance,
  ParentUser,
  PaidChildrenLimit,
  FirstGeneration,
  SecondGeneration,
  ThirdGeneration,
  UserPointBalance,
  sequelize,
  AdminUser,
  BankAccountConfiguration,
  AmountRangeConfiguration,
  AccountNumberBalance,
  AccountNumberTransactionHistory,
  PointConfiguration,
  UserAssignedToTaskGiveAwayPackage,
  TaskGiveAwayPackage

} = require('../models');
const Decimal  = require('decimal.js');
const { sellConfig, commissionConfig } = require('./config-loader');
const { UserCanSellCoin, calculateCommission } = require('../functions');


class VerifyDepositController extends BaseController {
  constructor() {
    super(VerifyDeposit);
    console.log('VerifyDepositController initialized');

    this.create = this.create.bind(this);
    this.update = this.update.bind(this);
    this.findAll = this.findAll.bind(this);
    this.findById = this.findById.bind(this);
    this.delete = this.delete.bind(this);
  }

  async create(req, res) {
    const transaction = await sequelize.transaction();
    try {
      console.log("Reqqqqqqqqqqqq.body", req.body);
      const user_id = req.user.id;
      const { balance, transaction_id, bank_account_configuration_id } = req.body;
      const paymentReceiptFile = req.file;
      console.log('Payment receipt size:', paymentReceiptFile.buffer.length);

      if (paymentReceiptFile.buffer.length > 1 * 1024 * 1024) {
        await transaction.rollback();
        return res.status(400).json({ error: 'Payment receipt file is too large. Maximum size allowed is 4 MB.' });
      }

      // Validate required fields
      if (!user_id || !balance || !bank_account_configuration_id) {
        await transaction.rollback();
        return res.status(400).json({ error: 'user_id, balance, and bank_account_configuration_id are required' });
      }

      // Validate balance
      const balanceNumber = parseFloat(balance);
      if (isNaN(balanceNumber)) {
        await transaction.rollback();
        return res.status(400).json({ error: 'Balance must be a valid number' });
      }


      // Check if user exists
      const user = await User.findByPk(user_id, { transaction });
      if (!user) {
        await transaction.rollback();
        return res.status(404).json({ error: 'User not found' });
      }

      // Check if balance exists in levels
      const level = await Level.findOne({ 
        where: { amount: balanceNumber },
        transaction 
      });

      if (!level) {
        await transaction.rollback();
        return res.status(400).json({ error: 'Balance does not match any existing level' });
      }


      // Check if bank account configuration exists
      const bankAccount = await BankAccountConfiguration.findByPk(bank_account_configuration_id, { transaction });
      if (!bankAccount) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Bank account configuration not found' });
      }

      // Check for payment receipt
      if (!paymentReceiptFile) {
        await transaction.rollback();
        return res.status(400).json({ error: 'Payment receipt is required' });
      }

      // Check if the user already has an accepted deposit
      const hasAcceptedDeposit = await VerifyDeposit.findOne({
        where: {
          user_id: user_id,
          status: 'Accepted'
        },
        transaction
      });

      if (hasAcceptedDeposit) {
        await transaction.rollback();
        return res.status(400).json({
          error: 'We have already accepted a deposit. You cannot add another.'
        });
      }

      // Create deposit record
      const newDeposit = await VerifyDeposit.create({
        user_id,
        bank_account_configuration_id,
        balance: balanceNumber,
        transaction_id: transaction_id || null,
        payment_receipt: paymentReceiptFile.buffer,
        status: 'Pending'
      }, { transaction });

      await transaction.commit();
      res.status(201).json(this.transformDeposit(newDeposit));
    } catch (error) {
      await transaction.rollback();
      console.error('Create deposit error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async update(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { id } = req.params;
      const approved_byy = req.user.id;
      req.body.approved_by = approved_byy;
      const { status, approved_by } = req.body; // approved_by is the admin's ID
      const paymentReceiptFile = req.file;

      const deposit = await VerifyDeposit.findByPk(id, {
        include: [
          {
            model: BankAccountConfiguration,
            include: [AmountRangeConfiguration]
          }
        ],
        transaction
      });
      if (!deposit) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Deposit not found' });
      }

      if (status) {
        if (status === 'Accepted') {
          if (deposit.status !== 'Pending') {
            await transaction.rollback();
            return res.status(400).json({ error: 'Can only accept pending deposits' });
          }

          // Validate approved_by
          if (!approved_by) {
            await transaction.rollback();
            return res.status(400).json({ error: 'approved_by is required for acceptance' });
          }

          const admin = await AdminUser.findByPk(approved_by, { transaction });
          if (!admin) {
            await transaction.rollback();
            return res.status(400).json({ error: 'Invalid admin ID: Admin not found' });
          }

          // Check if admin manages the bank account
          if (deposit.bank_account_configuration.managed_by !== approved_by) {
            await transaction.rollback();
            return res.status(403).json({ error: 'Admin is not authorized to approve this bank account' });
          }

          // Validate amount against range
          const amountRange = deposit.bank_account_configuration.amount_range_configuration;
          if (!amountRange) {
            await transaction.rollback();
            return res.status(400).json({ error: 'No amount range configured for this bank account' });
          }
          const depositBalance = new Decimal(deposit.balance);
          const minimumAmount = new Decimal(amountRange.minimum_amount);
          const maximumAmount = new Decimal(amountRange.maximum_amount);


          if (depositBalance.lt(minimumAmount) || depositBalance.gt(maximumAmount)) {
            await transaction.rollback();
            return res.status(400).json({ error: 'Deposit amount is outside the allowed range' });
          }

          // Update deposit
          deposit.status = 'Accepted';
          deposit.approved_by = approved_by;

          // Update AccountNumberBalance
          let accountBalance = await AccountNumberBalance.findOne({
            where: { bank_account_configuration_id: deposit.bank_account_configuration_id },
            transaction
          });
          if (!accountBalance) {
            accountBalance = await AccountNumberBalance.create({
              bank_account_configuration_id: deposit.bank_account_configuration_id,
              account_balance: 0
            }, { transaction });
          }
          accountBalance.account_balance = new Decimal(accountBalance.account_balance).plus(deposit.balance).toFixed(2);
          await accountBalance.save({ transaction });

          // Record transaction in AccountNumberTransactionHistory
          await AccountNumberTransactionHistory.create({
            bank_account_configuration_id: deposit.bank_account_configuration_id,
            transaction_amount: deposit.balance,
            transaction_reference: deposit.transaction_id,
            transaction_type: 'Credit', // Deposit increases balance
            user_transaction_done_by: deposit.user_id,
            status: 'Approved',
            checked_by: approved_by // Assuming the approver also checks
          }, { transaction });

          // Update user balances and level (existing logic)
          await this.updateBalances(deposit.user_id, 1, null, deposit.user_id, transaction);

          const newlyUpdateduserBalance = deposit.balance;
          const newlyUpdateduserLevelid = await Level.findOne({
            where: { amount: newlyUpdateduserBalance },
            transaction
          });
          if (!newlyUpdateduserLevelid) {
            await transaction.rollback();
            return res.status(400).json({ error: 'Balance does not match any existing level' });
          }

          const userToUpdate = await User.findByPk(deposit.user_id, { transaction });
          if (!userToUpdate) {
            await transaction.rollback();
            return res.status(404).json({ error: 'User not found' });
          }
          await userToUpdate.update(
            { level_id: newlyUpdateduserLevelid.id, status: 'Active' },
            { transaction }
          );
        } else {
          deposit.status = status; // For 'Rejected' or other statuses
        }
      }

      if (paymentReceiptFile) deposit.payment_receipt = paymentReceiptFile.buffer;

      await deposit.save({ transaction });
      await UserBalance.create({
        user_id: deposit.user_id,
        withdraw_up_to_date: 0.00,
        total_third_balance: 0.00,
        total_second_node_balance: 0.00,
        total_first_node_balance: 0.00,
        p2p_debit: 0.00,
        p2p_credit: 0.00,
        point_selling_credit: 0.00,
        current_balance: 0.00
      }, { transaction });


      const newlyUpdateduserBalancee = deposit.balance;
      const newlyUpdateduserLevelidd = await Level.findOne({
        where: { amount: newlyUpdateduserBalancee },
        transaction
      });
      if (newlyUpdateduserLevelidd) {
        const pointConfiguration = await PointConfiguration.findOne({ where: { level_id: newlyUpdateduserLevelidd.id }, transaction });
        if (pointConfiguration) {
          await UserPointBalance.create({
            user_id: deposit.user_id,
            points: new Decimal(pointConfiguration.amount),
            
          }, { transaction });
        }

        const taskGiveAwayPackage = await TaskGiveAwayPackage.findOne({ where: { level_id: newlyUpdateduserLevelidd.id }, transaction });
        if (taskGiveAwayPackage) {
          await UserAssignedToTaskGiveAwayPackage.create({
            user_id: deposit.user_id,
            task_give_away_package_id: taskGiveAwayPackage.id,
            start_date: new Date()
          }, { transaction });
        }
      }

      await transaction.commit();
      res.status(200).json(this.transformDeposit(deposit));
    } catch (error) {
      await transaction.rollback();
      console.error('Update deposit error:', error);
      res.status(500).json({ error: error.message });
    }
  }







  transformDeposit(deposit) {
    const depositJson = deposit.toJSON();
    depositJson.payment_receipt = depositJson.payment_receipt.toString('base64');
    return depositJson;
  }

  async findAll(req, res) {
    try {
      const deposits = await VerifyDeposit.findAll({
        include: [
          {
            model: User,
            attributes: ['username'], // Only fetch the username
          },
          {
            model: AdminUser,
            as: 'Approver',  // This must match the alias in your association
            attributes: ['username'], // Only fetch the username
          },
          {
            model: BankAccountConfiguration,
            include: [
              {
                model: AdminUser,
                as: 'Manager',  // This must match the alias in your association
                attributes: ['username'], // Only fetch the username
              },
            ],
          },
        ],
      });

      const transformedDeposits = deposits.map(deposit => {
        return {
          id: deposit.id,
          user_id: deposit.user_id,
          balance: deposit.balance,
          transaction_id: deposit.transaction_id,
          status: deposit.status,
          payment_receipt: deposit.payment_receipt,
          createdAt: deposit.createdAt,
          username: deposit.User?.username || null, // Conditional chaining
          approved_by: deposit.Approver?.username || null,
          assigned_to: deposit.bank_account_configuration?.Manager?.username || null,
        };
      });

      res.status(200).json(transformedDeposits);
    } catch (error) {
      super.handleError(res, error);
    }
  }

  async findById(req, res) {
    try {
      const deposit = await VerifyDeposit.findByPk(req.params.id);
      if (!deposit) return res.status(404).json({ error: 'Deposit not found' });
      res.status(200).json(this.transformDeposit(deposit));
    } catch (error) {
      super.handleError(res, error);
    }
  }


  async delete(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const deposit = await VerifyDeposit.findByPk(req.params.id, { transaction });
      if (!deposit) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Deposit not found' });
      }
      await deposit.destroy({ transaction });
      await transaction.commit();
      res.status(200).json({ message: 'Deposit deleted successfully' });
    } catch (error) {
      await transaction.rollback();
      super.handleError(res, error);
    }
  }




  async updateBalances(childUserId, parentLevel = 1, initialChildBalance = null, initialChildUserID = childUserId, transaction) {
    try {

      // Ensure we always have the child's initial deposit balance
      if (initialChildBalance === null) {
        const childDeposit = await VerifyDeposit.findOne({
          where: { 
            user_id: childUserId
          },
          transaction
        });
  
        if (!childDeposit) {
          console.error('Childs deposit not found');
          return;
        }
  
        initialChildBalance = childDeposit.balance;
      }
  
      // Get the parent relationship
      const parentRecord = await ParentUser.findOne({
        where: { user_id: childUserId },
        transaction
      });
  
      if (!parentRecord || !parentRecord.parent_user_id) {
        // No parent, stop recursion
        return;
      }
  
      const parentId = parentRecord.parent_user_id;
  
      // Fetch the parent's generation limit configuration
      const paidChildrenLimits = await PaidChildrenLimit.findOne({
        transaction
      });
  
      if (!paidChildrenLimits) {
        console.error('Paid children limits not configured.');
        return;
      }
  
      // Determine the max allowed paid referrals for the current parent level
      let maxPaidReferrals;
      switch (parentLevel) {
        case 1:
          maxPaidReferrals = paidChildrenLimits.first_generation_limit;
          break;
        case 2:
          maxPaidReferrals = paidChildrenLimits.second_generation_limit;
          break;
        case 3:
          maxPaidReferrals = paidChildrenLimits.third_generation_limit;
          break;
        default:
          maxPaidReferrals = 0; 
          break;
      }
  
      // No commission distribution unless within valid generation levels
      if (parentLevel > 3) {
        console.log('Maximum parent levels reached.');
        return;
      }
  
      // Fetch the parent's generation model (FirstGeneration, etc.)
      const generationModel = (() => {
        switch (parentLevel) {
          case 1:
            return FirstGeneration;
          case 2:
            return SecondGeneration;
          case 3:
            return ThirdGeneration;
          default:
            return null;
        }
      })();
  
      if (!generationModel) {
        return; // Invalid generation level
      }
  
      // Check if the parent has an accepted deposit
      const parentDeposit = await VerifyDeposit.findOne({
        where: {
          user_id: parentId,
          status: 'Accepted'
        },
        transaction
      });
  
      if (!parentDeposit) {
        // Move to the next parent
        if (parentLevel <= 2) { // Move up two more levels
          await this.updateBalances(parentId, parentLevel + 1, initialChildBalance, initialChildUserID, transaction);
        }
        return;
      }
  
      // Fetch the parent's generation record
      const parentGenerationRecord = await generationModel.findOne({
        where: { user_id: parentId },
        transaction
      });
  
      if (!parentGenerationRecord) {
        console.error(`Parent generation record not found for user ${parentId} at level ${parentLevel}`);
        return;
      }
  
      let paidReferrals = [];
      // Handle paid_referral_users data type
      if (typeof parentGenerationRecord.paid_referral_users === 'string') {
        try {
          paidReferrals = JSON.parse(parentGenerationRecord.paid_referral_users);
          if (!Array.isArray(paidReferrals)) {
            console.error('Parsed paid_referral_users is not an array');
            paidReferrals = [];
          }
        } catch (parseError) {
          console.error('Error parsing paid_referral_users:', parseError);
          paidReferrals = [];
        }
      } else if (Array.isArray(parentGenerationRecord.paid_referral_users)) {
        paidReferrals = [...parentGenerationRecord.paid_referral_users];
      } else {
        console.error('Invalid paid_referral_users format');
        paidReferrals = [];
      }
  
      // Check if parent has reached paid referral limit
      if (paidReferrals.length >= maxPaidReferrals) {
        console.log(`Parent ${parentId} has reached the paid referral limit for level ${parentLevel}. Moving to next level.`);
        if (parentLevel <= 2) {
          await this.updateBalances(parentId, parentLevel + 1, initialChildBalance, initialChildUserID, transaction);
        }
        return;
      }
  
      // Parent is within the limit; proceed to calculate the commission
      // Get parent's initial deposit and level
      const parentLevelRecord = await Level.findOne({
        where: { amount: parentDeposit.balance },
        transaction
      });
      
      if (!parentLevelRecord) {
        console.error('Parents level not found');
        return; // Parent's level not found
      }
  
      // Get child deposit details
      const childLevelRecord = await Level.findOne({
        where: { amount: initialChildBalance },
        transaction
      });
      
      if (!childLevelRecord) {
        console.log('Childs level not found');
        return; // Child's level not found
      }
  
      // Calculate commission
      const X = parentDeposit.balance; // Parent's initial deposit
      const Y = initialChildBalance; // Child's initial deposit

      const pointBalance = await UserPointBalance.findOne({
        where: { user_id: parentId },
        transaction
      });

      //if (!pointBalance) {
       // console.log('Parent point balance not found');
       // return; // Parent's point balance not found
     // }
     const pointBalanceValue = pointBalance ? pointBalance.points : 0;
      const baseCommission = calculateCommission(X, Y, parentLevel);
      const result = UserCanSellCoin(X, Y, parentLevel, pointBalanceValue);

      console.log("baseCommissionbaseCommissionbaseCommission",baseCommission);
      console.log("resultresultresultresultresultresult",result)

      console.log(result.amount);  // Selling amount
      console.log(result.coins);   // Number of coins sold
      const roundedCommission = parseFloat(baseCommission.toFixed(2));
      const canSellCoinRounded = parseFloat(result.amount.toFixed(2));
  
      // Update paid_referral_users array
      paidReferrals.push(initialChildUserID);
  
      // Prepare updated data
      const updatedData = {
        paid_referral_users: paidReferrals
      };
  
      await parentGenerationRecord.update(updatedData, { transaction });
  
      // Update UserBalance based on the generation level
      let userBalance = await UserBalance.findOne({
        where: { user_id: parentId },
        transaction
      });
  
      if (!userBalance) {
        userBalance = await UserBalance.create({
          user_id: parentId,
          withdraw_up_to_date: 0.00,
          total_third_balance: 0.00,
          total_second_node_balance: 0.00,
          total_first_node_balance: 0.00,
          p2p_debit: 0.00,
          p2p_credit: 0.00,
          point_selling_credit: 0.00,
          current_balance: 0.00
        }, { transaction });
      }
  
      // Update balance based on generation level
      if (parentLevel === 1) {
        let currentBalance = new Decimal(userBalance.total_first_node_balance || 0);
        let PointSellingCredit = new Decimal(userBalance.point_selling_credit || 0);
        let newBalance = currentBalance.plus(roundedCommission).toFixed(2);
        let coinSold = PointSellingCredit.plus(canSellCoinRounded).toFixed(2);
        await userBalance.update({
          total_first_node_balance: newBalance,
          point_selling_credit: coinSold
        }, { transaction });
      } else if (parentLevel === 2) {
        let currentBalance = new Decimal(userBalance.total_second_node_balance || 0);
        let newBalance = currentBalance.plus(roundedCommission).toFixed(2);
        await userBalance.update({
          total_second_node_balance: newBalance
        }, { transaction });
      } else if (parentLevel === 3) {
        let currentBalance = new Decimal(userBalance.total_third_balance || 0);
        let newBalance = currentBalance.plus(roundedCommission).toFixed(2);
        await userBalance.update({
          total_third_balance: newBalance
        }, { transaction });
      }
  
      // Update current balance
      const totalFirst = new Decimal(userBalance.total_first_node_balance || 0);
      const totalSecond = new Decimal(userBalance.total_second_node_balance || 0);
      const totalThird = new Decimal(userBalance.total_third_balance || 0);
      const withdraw = new Decimal(userBalance.withdraw_up_to_date || 0);
      const p2pDebit = new Decimal(userBalance.p2p_debit || 0);
      const p2pCredit = new Decimal(userBalance.p2p_credit || 0);
      const pointSellingCredit = new Decimal(userBalance.point_selling_credit || 0);
  
      const currentBalance = totalFirst.plus(totalSecond)
                              .plus(totalThird)
                              .minus(withdraw)
                              .minus(p2pDebit)
                              .plus(p2pCredit)
                              .plus(pointSellingCredit)
                              .toFixed(2);


      if(pointBalance){
        await pointBalance.update({
          points: pointBalance.points - result.coins
        }, { transaction });
      }
      
  
      await userBalance.update({
        current_balance: currentBalance
      }, { transaction });
  
      // Proceed to next parent level if within limits
      if (parentLevel <= 2) {
        await this.updateBalances(parentId, parentLevel + 1, initialChildBalance, initialChildUserID, transaction);
      }
  
    } catch (error) {
      console.error('Error updating balances:', error);
      throw error;
    }
  }

  transformDeposit(deposit) {
    const depositJson = deposit.toJSON();
    depositJson.payment_receipt = depositJson.payment_receipt.toString('base64');
    return depositJson;
  }

}












































// function UserCanSellCoin(parentAmount, childAmount, parentLevel, pointBalance) {
//   // Extensive logging (consider removing in production)
 

//   // Only process for parent level 1
//   if (parentLevel === 1) {
//       // Convert inputs to Decimal for precise calculations
//       const decimalChildAmount = new Decimal(childAmount || 0);
//       const decimalParentAmount = new Decimal(parentAmount || 0);
//       const decimalPointBalance = new Decimal(pointBalance || 0);

//       // Early return if child or parent amount is zero
//       if (decimalChildAmount.isZero() || decimalParentAmount.isZero()) {
//           return { amount: 0, coins: 0 };
//       }

//       let maximumSellAmount = new Decimal(0);
//       const systemBuyOneCoin = new Decimal(22);
//       let youCanSellWith = new Decimal(0);

//       // Complex tiered selling logic based on parent and child amounts
//       if (decimalParentAmount.gte(25000) && decimalChildAmount.gte(1000)) {
//           maximumSellAmount = decimalChildAmount.mul(0.25);
//           youCanSellWith = new Decimal(22);
//       } else if (decimalParentAmount.lt(25000) && decimalParentAmount.gte(10000) && decimalChildAmount.gte(3000)) {
//           maximumSellAmount = decimalChildAmount.mul(0.25).mul(0.8);
//           youCanSellWith = new Decimal(20);
//       } else if (decimalParentAmount.lt(10000) && decimalParentAmount.gte(1000) && decimalChildAmount.gte(3000)) {
//           maximumSellAmount = decimalChildAmount.mul(0.25).mul(0.5);
//           youCanSellWith = new Decimal(18);
//       } else if (decimalParentAmount.lt(1000) && decimalChildAmount.gt(5000)) {
//           maximumSellAmount = decimalChildAmount.mul(0.25).mul(0.5);
//           youCanSellWith = new Decimal(15);
//       } else {
//           return { amount: 0, coins: 0 };
//       }

//       // Calculate number of coins user can sell
//       const userCanSellNumberOfCoin = maximumSellAmount.div(systemBuyOneCoin).floor();

//       // Return based on point balance
//       if (userCanSellNumberOfCoin.gt(decimalPointBalance)) {
//           return {
//               amount: decimalPointBalance.mul(youCanSellWith).toNumber(),
//               coins: decimalPointBalance.toNumber()
//           };
//       } else {
//           return {
//               amount: userCanSellNumberOfCoin.mul(youCanSellWith).toNumber(),
//               coins: userCanSellNumberOfCoin.toNumber()
//           };
//       }
//   } else {
//       // Non-level 1 users cannot sell
//       return { amount: 0, coins: 0 };
//   }
// }

// function calculateCommission(X, Y, parentLevel) {
//   if (parentLevel < 1 || parentLevel > 3) {
//       return null;
//   }

//   let baseRate, bonusRate;

//   switch (parentLevel) {
//       case 1:
//           baseRate = new Decimal(0.25);
//           bonusRate = new Decimal(0.022);
//           break;
//       case 2:
//           baseRate = new Decimal(0.15);
//           bonusRate = new Decimal(0.015);
//           break;
//       case 3:
//           baseRate = new Decimal(0.10);
//           bonusRate = new Decimal(0.01);
//           break;
//   }

//   const decimalX = new Decimal(X);
//   const decimalY = new Decimal(Y);

//   if (decimalY.lte(decimalX)) {
//       return decimalY.mul(baseRate).toNumber(); 
//   } else {
//       const commission = decimalX.mul(baseRate).plus(decimalY.sub(decimalX).mul(bonusRate));
//       return commission.toNumber(); 
//   }
// }





module.exports = new VerifyDepositController();