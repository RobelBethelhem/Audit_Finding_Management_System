const BaseController = require('./BaseController');
const { TaskGiveAwayPackage, Level, sequelize } = require('../models'); // Ensure Level model is imported
const sequelizee = require('sequelize');

class TaskGiveAwayPackageController extends BaseController {
    constructor() {
        super(TaskGiveAwayPackage);
        console.log('TaskGiveAwayPackageController initialized');
    }

    // Custom create with validation (override BaseController) and Transaction
    async create(req, res) {
        let transaction;
        try {
            transaction = await sequelize.transaction(); // Start a transaction

            console.log("rrrrrrrrrrrrrrrrrrrrrrrrrr", req.body)

            const { level_id, active_days, refferal_limit, status } = req.body;

            // Validate input
            if (!level_id || !active_days || !refferal_limit || !status) {
                return res.status(400).json({ error: 'level_id, active_days, refferal_limit, and status are required' });
            }

            // Check if level_id exists in Level model
            const existingLevel = await Level.findByPk(level_id, { transaction });
            if (!existingLevel) {
                return res.status(400).json({ error: 'level_id does not exist in Level model' });
            }

            // Create using BaseController's create (using transaction)
            const item = await this.model.create(req.body, { transaction });

            await transaction.commit(); // Commit the transaction if everything is successful
            return res.status(201).json(item);

        } catch (error) {
            if (transaction) {
                await transaction.rollback(); // Rollback the transaction if any error occurs
            }
            console.error('TaskGiveAwayPackage creation error:', error);
            res.status(500).json({ error: error.message });
        }
    }

    // Custom update with validation (override BaseController) and Transaction
    async update(req, res) {
        let transaction;
        try {
            transaction = await sequelize.transaction(); // Start a transaction

            const { id } = req.params;
            const { level_id, active_days, refferal_limit, status } = req.body; // Extract all potentially updateable fields

            if (level_id) {
                // Check if level_id exists in Level model
                const existingLevel = await Level.findByPk(level_id, { transaction });
                if (!existingLevel) {
                    return res.status(400).json({ error: 'level_id does not exist in Level model' });
                }
            }

            // Build the update object, only including allowed fields
            const updateData = {};
            if (level_id) {
                updateData.level_id = level_id;
            }
            if (active_days) {
                updateData.active_days = active_days;
            }
            if (refferal_limit) {
                updateData.refferal_limit = refferal_limit;
            }
            if (status) {
                updateData.status = status;
            }

            // Update using BaseController's update, passing only the allowed data and transaction
            const [updated] = await this.model.update(updateData, {
                where: { id: req.params.id },
                transaction
            });

            if (updated) {
                const updatedItem = await this.model.findByPk(req.params.id, { transaction });
                await transaction.commit(); // Commit the transaction
                return res.status(200).json(updatedItem);
            } else {
                await transaction.rollback(); //Rollback the transaction
                return res.status(404).json({ error: 'TaskGiveAwayPackage not found' }); // Explicitly handle not found
            }

        } catch (error) {
            if (transaction) {
                await transaction.rollback(); // Rollback the transaction if any error occurs
            }
            console.error('TaskGiveAwayPackage update error:', error);
            res.status(500).json({ error: error.message });
        }
    }



    // Inherited methods (explicitly listed for clarity)
    async findAll(req, res) {
        try {
            const items = await this.model.findAll({
                include: [{
                    model: Level,
                    as: 'Level',
                    attributes: ['id', 'short_code', 'amount']
                }]
            });
            return res.status(200).json(items);
        } catch (error) {
            console.error('TaskGiveAwayPackage findAll error:', error);
            res.status(500).json({ error: error.message });
        }
    }

    async delete(req, res) {
        return super.delete(req, res);
    }
}

module.exports = new TaskGiveAwayPackageController();