const BaseController = require('./BaseController');
const { UserBalance } = require('../models');

class UserBalanceController extends BaseController {
  constructor() {
    super(UserBalance);
    // Bind methods to preserve context
    this.findAll = this.findAll.bind(this);
    this.findById = this.findById.bind(this);

    console.log('UserBalanceController initialized');
  }

  async findAll(req, res) {
    return super.findAll(req, res);
  }

  // Overriding findById to search by user_id instead of the primary key
  async findById(req, res) {
    try {
      const { id } = req.params; // Here 'id' is the user_id from the route
      const userBalance = await this.model.findOne({ where: { user_id: id } });

      if (!userBalance) {
        return res.status(404).json({ error: 'User balance not found for this user id' });
      }
      return res.json(userBalance);
    } catch (error) {
      console.error('Error fetching user balance by user id:', error);
      return res.status(500).json({ error: error.message });
    }
  }
}

module.exports = new UserBalanceController();
