const BaseController = require('./BaseController');
const { VerifyDeposit, User, Level , UserBalance, ParentUser, PaidChildrenLimit, FirstGeneration, SecondGeneration, ThirdGeneration} = require('../models');
const Decimal  = require('decimal.js');

class VerifyDepositController extends BaseController {
  constructor() {
    super(VerifyDeposit);
    console.log('VerifyDepositController initialized');

    this.create = this.create.bind(this);
    this.update = this.update.bind(this);
    this.findAll = this.findAll.bind(this);
    this.findById = this.findById.bind(this);
    this.delete = this.delete.bind(this);
  }

  async create(req, res) {
    try {
      const { user_id, balance, transaction_id } = req.body;
      const paymentReceiptFile = req.file;

      // Validate required fields
      if (!user_id || !balance) {
        return res.status(400).json({ error: 'user_id and balance are required' });
      }

      // Validate balance
      const balanceNumber = parseFloat(balance);
      if (isNaN(balanceNumber)) {
        return res.status(400).json({ error: 'Balance must be a valid number' });
      }

      // Check if balance exists in levels
      const level = await Level.findOne({ where: { amount: balanceNumber } });
      if (!level) {
        return res.status(400).json({ error: 'Balance does not match any existing level' });
      }

      // Check if user exists
      const user = await User.findByPk(user_id);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Check for payment receipt
      if (!paymentReceiptFile) {
        return res.status(400).json({ error: 'Payment receipt is required' });
      }


       // Check if the user already has an accepted deposit
       const hasAcceptedDeposit = await VerifyDeposit.findOne({
        where: {
          user_id: user_id,
          status: 'Accepted'
        }
      });

      if (hasAcceptedDeposit) {
        return res.status(400).json({
          error: 'We have already accepted a deposit. You cannot add another.'
        });
      }

      // Create deposit record
      const newDeposit = await VerifyDeposit.create({
        user_id,
        balance: balanceNumber,
        transaction_id: transaction_id || null,
        payment_receipt: paymentReceiptFile.buffer,
        status: 'Pending'
      });

      res.status(201).json(this.transformDeposit(newDeposit));
    } catch (error) {
      console.error('Create deposit error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async update(req, res) {
    try {
      const { id } = req.params;
      const { user_id, balance, transaction_id, status } = req.body;
      const paymentReceiptFile = req.file;

      const deposit = await VerifyDeposit.findByPk(id);
      if (!deposit) {
        return res.status(404).json({ error: 'Deposit not found' });
      }

      // Validate user if changing
      if (user_id && user_id !== deposit.user_id) {
        const user = await User.findByPk(user_id);
        if (!user) {
          return res.status(404).json({ error: 'New user not found' });
        }
        deposit.user_id = user_id;
      }

      // Handle balance update
      if (balance) {
        const balanceNumber = parseFloat(balance);
        if (isNaN(balanceNumber)) {
          return res.status(400).json({ error: 'Balance must be a valid number' });
        }
        
        // Check if new balance exists in levels
        const level = await Level.findOne({ where: { amount: balanceNumber } });
        if (!level) {
          return res.status(400).json({ error: 'Balance does not match any existing level' });
        }
        
        deposit.balance = balanceNumber;
      }

      // Handle status update
      if (status) {
        if (status === 'Accepted' && deposit.status !== 'Pending') {
          return res.status(400).json({ error: 'Can only accept pending deposits' });
        }

        // Final validation when accepting
        if (status === 'Accepted') {

             // Calculate commission and update balances
          await this.updateBalances(deposit.user_id);

          const newlyUpdateduserBalance = deposit.balance;
            const newlyUpdateduserLevelid = await Level.findOne({ where: { amount: newlyUpdateduserBalance } });
  
            if(!newlyUpdateduserLevelid){
              return res.status(400).json({ error: 'Balance does not match with any existing level' });
            }
  
            const userToUpdate = await User.findByPk(deposit.user_id);
            if (!userToUpdate) {
              return res.status(404).json({ error: 'User not found' });
            }
  
            await userToUpdate.update(
              { 
                  level_id: newlyUpdateduserLevelid.id,
                  status: 'Active'
               }
              );

        }

        deposit.status = status;
      }

      // Update other fields
      if (transaction_id) deposit.transaction_id = transaction_id;
      if (paymentReceiptFile) deposit.payment_receipt = paymentReceiptFile.buffer;

      await deposit.save();
     

      res.status(200).json(this.transformDeposit(deposit));
    } catch (error) {
      console.error('Update deposit error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  transformDeposit(deposit) {
    const depositJson = deposit.toJSON();
    depositJson.payment_receipt = depositJson.payment_receipt.toString('base64');
    return depositJson;
  }

  async findAll(req, res) {
    try {
      const deposits = await VerifyDeposit.findAll();
      res.status(200).json(deposits.map(d => this.transformDeposit(d)));
    } catch (error) {
      super.handleError(res, error);
    }
  }

  async findById(req, res) {
    try {
      const deposit = await VerifyDeposit.findByPk(req.params.id);
      if (!deposit) return res.status(404).json({ error: 'Deposit not found' });
      res.status(200).json(this.transformDeposit(deposit));
    } catch (error) {
      super.handleError(res, error);
    }
  }


  async delete(req, res) {
    try {
      const deposit = await VerifyDeposit.findByPk(req.params.id);
      if (!deposit) {
        return res.status(404).json({ error: 'Deposit not found' });
      }
      await deposit.destroy();
      res.status(200).json({ message: 'Deposit deleted successfully' });
    } catch (error) {
      super.handleError(res, error);
    }
  }




  async updateBalances(childUserId, parentLevel = 1, initialChildBalance = null, initialChildUserID = childUserId) {
    try {

      // Ensure we always have the child's initial deposit balance
    if (initialChildBalance === null) {
        const childDeposit = await VerifyDeposit.findOne({
          where: { 
            user_id: childUserId,
            // status: 'Accepted'
          }
        });
  
        if (!childDeposit) {
          console.error('Child’s deposit not found');
          return;
        }
  
        initialChildBalance = childDeposit.balance;
      }


      // Get the parent relationship
      const parentRecord = await ParentUser.findOne({
        where: { user_id: childUserId }
      });

      if (!parentRecord || !parentRecord.parent_user_id) {
        // No parent, stop recursion
        return;
      }

      const parentId = parentRecord.parent_user_id;

       // Fetch the parent's generation limit configuration
        const paidChildrenLimits = await PaidChildrenLimit.findOne({});

        if (!paidChildrenLimits) {
        console.error('Paid children limits not configured.');
        return;
        }

         // Determine the max allowed paid referrals for the current parent level
    let maxPaidReferrals;
    switch (parentLevel) {
      case 1:
        maxPaidReferrals = paidChildrenLimits.first_generation_limit;
        break;
      case 2:
        maxPaidReferrals = paidChildrenLimits.second_generation_limit;
        break;
      case 3:
        maxPaidReferrals = paidChildrenLimits.third_generation_limit;
        break;
      default:
        maxPaidReferrals = 0; 
        break;
    }


     // No commission distribution unless within valid generation levels
     if (parentLevel > 3) {
        console.log('Maximum parent levels reached.');
        return;
      }

       // Fetch the parent's generation model (FirstGeneration, etc.)
       const generationModel = (() => {
        switch (parentLevel) {
          case 1:
            return FirstGeneration;
          case 2:
            return SecondGeneration;
          case 3:
            return ThirdGeneration;
          default:
            return null;
        }
      })();

      if (!generationModel) {
        return; // Invalid generation level
      }

      // Check if the parent has an accepted deposit
      const parentDeposit = await VerifyDeposit.findOne({
        where: {
          user_id: parentId,
          status: 'Accepted'
        }
      });

      if (!parentDeposit) {
        // Move to the next parent
        if (parentLevel <= 2) { // Move up two more levels
          await this.updateBalances(parentId, parentLevel + 1, initialChildBalance, initialChildUserID);
        }
        return;
      }


      // Fetch the parent's generation record
     const parentGenerationRecord = await generationModel.findOne({
        where: { user_id: parentId }
      });

      if (!parentGenerationRecord) {
        console.error(`Parent generation record not found for user ${parentId} at level ${parentLevel}`);
        return;
      }


      let paidReferrals = [];
      // Handle paid_referral_users data type
     if (typeof parentGenerationRecord.paid_referral_users === 'string') {
        try {
          paidReferrals = JSON.parse(parentGenerationRecord.paid_referral_users);
          if (!Array.isArray(paidReferrals)) {
            console.error('Parsed paid_referral_users is not an array');
            paidReferrals = [];
          }
        } catch (parseError) {
          console.error('Error parsing paid_referral_users:', parseError);
          paidReferrals = [];
        }
      } else if (Array.isArray(parentGenerationRecord.paid_referral_users)) {
        paidReferrals = [...parentGenerationRecord.paid_referral_users];
      } else {
        console.error('Invalid paid_referral_users format');
        paidReferrals = [];
      }
 
      // Check if parent has reached paid referral limit
      if (paidReferrals.length >= maxPaidReferrals) {
        console.log(`Parent ${parentId} has reached the paid referral limit for level ${parentLevel}. Moving to next level.`);
        if (parentLevel <= 2) {
          await this.updateBalances(parentId, parentLevel + 1, initialChildBalance, initialChildUserID);
        }
        return;
      }


       // Parent is within the limit; proceed to calculate the commission
      // Get parent's initial deposit and level
      const parentLevelRecord = await Level.findOne({
        where: { amount: parentDeposit.balance }
      });
      
      if (!parentLevelRecord) {
        console.error('Parent’s level not found');
        return; // Parent's level not found
      }


      // Get child deposit details
      const childLevelRecord = await Level.findOne({
        where: { amount: initialChildBalance }
      });
      
      if (!childLevelRecord) {
        console.error('Child’s level not found');
        return; // Child's level not found
      }

      // Calculate z
      const X = parentDeposit.balance; // Parent's initial deposit
      const Y = initialChildBalance; // Child's initial deposit


      const P = parentLevel === 1 ? 25 : parentLevel === 2 ? 15 : 10;

      const Z = (100 / P) * ((Math.pow(X, 2) + 100000 * Y) / (X * Y));

      const baseCommission = calculateCommission(X,Y, parentLevel);

      const roundedCommission = parseFloat(baseCommission.toFixed(2));

    //   // Calculate commission
    //   const commission = (Math.pow(X, 2) / 100000 + Y) / Z;

    //   // Apply percentage based on parent's level
    //   const commissionWithPercentage = commission * (parentLevelRecord.percentage / 100);
    //   const roundedCommission = parseFloat(commissionWithPercentage.toFixed(2));

      console.log("initialChildUserIDinitialChildUserIDinitialChildUserIDinitialChildUserIDinitialChildUserIDinitialChildUserIDinitialChildUserIDinitialChildUserIDinitialChildUserID", initialChildUserID)
    
       // Update paid_referral_users array
     paidReferrals.push(initialChildUserID);

        // Prepare updated data
        const updatedData = {
            paid_referral_users: paidReferrals
        };

     await parentGenerationRecord.update(updatedData);

      // Update UserBalance based on the generation level
      let userBalance = await UserBalance.findOne({
        where: { user_id: parentId }
      });


      if (!userBalance) {
        userBalance = await UserBalance.create({
          user_id: parentId,
          withdraw_up_to_date: 0.00,
          total_third_balance: 0.00,
          total_second_node_balance: 0.00,
          total_first_node_balance: 0.00,
        });
      }

       // Update balance based on generation level
    if (parentLevel === 1) {
        let currentBalance = new Decimal(userBalance.total_first_node_balance);
        let newBalance = currentBalance.plus(roundedCommission).toFixed(2);
        await userBalance.update({
            total_first_node_balance: newBalance
          });

        // userBalance.total_first_node_balance = (
        //     parseFloat(userBalance.total_first_node_balance) + roundedCommission
        //   ).toFixed(2);

      } else if (parentLevel === 2) {
        let currentBalance = new Decimal(userBalance.total_second_node_balance);
        let newBalance = currentBalance.plus(roundedCommission).toFixed(2);
        await userBalance.update({
            total_second_node_balance: newBalance
          });


        // userBalance.total_second_node_balance = (
        //     parseFloat(userBalance.total_second_node_balance) + roundedCommission
        //   ).toFixed(2);
      } else if (parentLevel === 3) {

        let currentBalance = new Decimal(userBalance.total_third_balance);
        let newBalance = currentBalance.plus(roundedCommission).toFixed(2);
        await userBalance.update({
            total_third_balance: newBalance
          });

        // userBalance.total_third_balance = (
        //     parseFloat(userBalance.total_third_balance) + roundedCommission
        //   ).toFixed(2);
      }

        // update current balance
        const totalFirst = new Decimal(userBalance.total_first_node_balance);
        const totalSecond = new Decimal(userBalance.total_second_node_balance);
        const totalThird = new Decimal(userBalance.total_third_balance);
        const withdraw = new Decimal(userBalance.withdraw_up_to_date || 0);

        const currentBalance = totalFirst.plus(totalSecond)
                                .plus(totalThird)
                                .minus(withdraw)
                                .toFixed(2);

        userBalance.current_balance = currentBalance;
        await userBalance.save();
  
      // Update current balance
    //   userBalance.current_balance = (
    //     userBalance.total_first_node_balance +
    //     userBalance.total_second_node_balance +
    //     userBalance.total_third_balance
    //   ) - (userBalance.withdraw_up_to_date || 0);
  
    //   await userBalance.save();

      // Proceed to next parent level if within limits
      if (parentLevel <= 2) {
        await this.updateBalances(parentId, parentLevel + 1, initialChildBalance, initialChildUserID);
      }

    } catch (error) {
      console.error('Error updating balances:', error);
      throw error;
    }
  }

  transformDeposit(deposit) {
    const depositJson = deposit.toJSON();
    depositJson.payment_receipt = depositJson.payment_receipt.toString('base64');
    return depositJson;
  }

}


function calculateCommission(X, Y, parentLevel) {
    if (parentLevel < 1 || parentLevel > 3) {
        return null; // Return null if parentLevel is not 1, 2, or 3
    }

    let baseRate, bonusRate;

    // Define rates based on parentLevel
    switch (parentLevel) {
        case 1:
            baseRate = 0.25;
            bonusRate = 0.022;
            break;
        case 2:
            baseRate = 0.15;
            bonusRate = 0.015;
            break;
        case 3:
            baseRate = 0.10;
            bonusRate = 0.01;
            break;
    }

    
   
    if (Y <= X) {
        return Y * baseRate;
    } else {
        return (X * baseRate) + ((Y - X) * bonusRate);
    }
}


module.exports = new VerifyDepositController();