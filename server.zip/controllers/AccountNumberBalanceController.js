const BaseController = require('./BaseController');
const { AccountNumberBalance, sequelize } = require('../models');

class AccountNumberBalanceController extends BaseController {
  constructor() {
    super(AccountNumberBalance);
    this.create = this.create.bind(this);
  }

  async create(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { bank_account_configuration_id, account_balance } = req.body;

      if (!bank_account_configuration_id || account_balance === undefined) {
        await transaction.rollback();
        return res.status(400).json({ error: 'All fields are required' });
      }

      // Create new account number balance
      const newBalance = await AccountNumberBalance.create({
        bank_account_configuration_id,
        account_balance
      }, { transaction });

      await transaction.commit();
      res.status(201).json({ message: 'Account balance configured successfully', balance: newBalance });
    } catch (error) {
      await transaction.rollback();
      console.error('Account balance configuration error:', error);
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = new AccountNumberBalanceController();