const BaseController = require('./BaseController');
const { DailyTaskGame, DailyTaskConfiguration, DailyTaskPoint, sequelize } = require('../models');

const { Op } = require('sequelize');
const moment = require('moment');

class DailyTaskGameController extends BaseController {
  constructor() {
    super(DailyTaskGame);
    console.log('DailyTaskGameController initialized');

     // Set up automatic game expiration
     this.setupGameExpirationJob();
  }



   // Automatic game expiration job
   setupGameExpirationJob() {
    console.log('Setting up Automatic game expiration job');
    // Check and expire games every hour
    setInterval(async () => {
      try {
        await this.expireOldGames();
      } catch (error) {
        console.error('Error in game expiration job:', error);
      }
    }, 60 * 60 * 1000); // 1 hour
  }

  // Method to expire old games
  async expireOldGames() {
    const oneDayAgo = moment().subtract(1, 'days').toDate();
    
    await DailyTaskGame.update(
      { isExpired: true },
      { 
        where: { 
          isExpired: false,
          createdAt: { [Op.lt]: oneDayAgo }
        }
      }
    );
  }



  // Custom create with validation (override BaseController)
  async create(req, res) {
    const transaction = await sequelize.transaction();
    
    try {
      const { daily_task_id, value } = req.body;
      
      // Validate input
      if (!daily_task_id || !value) {
        return res.status(400).json({ error: 'daily_task_id and value are required' });
      }

       // Verify that the daily_task_id exists
       const taskConfiguration = await DailyTaskConfiguration.findByPk(daily_task_id, { transaction });
       if (!taskConfiguration) {
         await transaction.rollback();
         return res.status(400).json({ error: 'Invalid daily_task_id' });
       }

       // Check for existing active game for this task
       const existingActiveGame = await DailyTaskGame.findOne({ 
        where: { 
          daily_task_id,
          isExpired: false
        },
        transaction
      });
      
      if (existingActiveGame) {
        await transaction.rollback();
        return res.status(400).json({ error: 'An active game already exists for this task' });
      }

      // Create using BaseController's create
      // Create game
      const newGame = await DailyTaskGame.create({
        daily_task_id,
        value
      }, { transaction });
      // Commit transaction
      await transaction.commit();

      return res.status(201).json(newGame);
    } catch (error) {
      await transaction.rollback();
      console.error('DailyTaskGame creation error:', error);
      
      // Handle Sequelize validation errors
      if (error.name === 'SequelizeValidationError') {
        return res.status(400).json({ 
          error: 'Validation failed',
          details: error.errors.map(e => e.message)
        });
      }

      res.status(500).json({ error: error.message });
    }
  }


  async getCipherHint(req, res){
    try {
      const activeGameConfig = await DailyTaskConfiguration.findOne({
        where: {
          task_name: {
              [Op.or]: ['Cipher', 'FreeCipher']
          }
      },
        attributes: ['id'],
        include: [{
          model: DailyTaskGame,
          where: { isExpired: false },
          attributes: ['value'],
        }],
      });

      console.log("activeGameConfig:", JSON.stringify(activeGameConfig, null, 2));

      if (!activeGameConfig) {
        return res.status(404).json({ error: 'No active Cipher game configuration found' });
      }


      const cipherValue = activeGameConfig.daily_task_games?.[0]?.value;

      if (!cipherValue || typeof cipherValue !== 'string') {
        return res.status(400).json({ error: 'Invalid or missing value in Cipher game' });
      }

    const firstLetter = cipherValue.charAt(0);

      return res.status(200).json(firstLetter);
    } catch (error) {
      console.error('Error fetching active games:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Get active games
  async getActiveGames(req, res) {
    try {
      const activeGames = await DailyTaskGame.findAll({
        where: { isExpired: false },
        attributes: ['id', 'daily_task_id', 'createdAt'],
        include: [{
          model: DailyTaskConfiguration,
          attributes: ['task_name', 'description']
        }]
      });
      
      return res.status(200).json(activeGames);
    } catch (error) {
      console.error('Error fetching active games:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Mark all games as expired
  async expireAllGames(req, res) {
    try {
      await DailyTaskGame.update(
        { isExpired: true },
        { where: { isExpired: false } }
      );
      
      return res.status(200).json({ message: 'All games marked as expired' });
    } catch (error) {
      console.error('Error expiring games:', error);
      res.status(500).json({ error: error.message });
    }
  }



  async expireGame(req, res) {
    try {
      const { id } = req.params;
      
      const result = await DailyTaskGame.update(
        { isExpired: true },
        { 
          where: { 
            id,
            isExpired: false 
          }
        }
      );

      if (result[0] === 0) {
        return res.status(404).json({ error: 'Game not found or already expired' });
      }
      
      return res.status(200).json({ message: 'Game marked as expired' });
    } catch (error) {
      console.error('Error expiring game:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Inherited methods
  async findAll(req, res) {
    try {
      const dailyTaskGames = await DailyTaskGame.findAll({
        include: [{
          model: DailyTaskConfiguration,
          attributes: ['task_name']
        }]
      });

      // Map the response to include task_name
      const response = dailyTaskGames.map(game => ({
        id: game.id,
        daily_task_id: game.daily_task_id,
        value: game.value,
        isExpired: game.isExpired,
        createdAt: game.createdAt,
        updatedAt: game.updatedAt,
        task_name: game.daily_task_configuration ? game.daily_task_configuration.task_name : null
      }));
  
      return res.status(200).json(response);
    } catch (error) {
      console.error('DailyTaskGame findAll error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async findById(req, res) {
    return super.findById(req, res);
  }

  async update(req, res) {
    return super.update(req, res);
  }

  async delete(req, res) {
    return super.delete(req, res);
  }
}

module.exports = new DailyTaskGameController();