const BaseController = require('./BaseController');
const { DailyTaskPoint, DailyTaskConfiguration } = require('../models');
const sequelize = require('sequelize');

class DailyTaskPointController extends BaseController {
  constructor() {
    super(DailyTaskPoint);
    console.log('DailyTaskPointController initialized');
  }

  // Custom create with validation (override BaseController)
  async create(req, res) {
    try {
      const { daily_task_id, points } = req.body;
      
      // Validate input
      if (!daily_task_id || points === undefined) {
        return res.status(400).json({ error: 'daily_task_id and points are required' });
      }

      // Verify that the daily_task_id exists
      const taskExists = await DailyTaskConfiguration.findByPk(daily_task_id);
      if (!taskExists) {
        return res.status(400).json({ error: 'Invalid daily_task_id' });
      }

      // Check for existing points for this task
      const existingPoints = await DailyTaskPoint.findOne({ where: { daily_task_id } });
      if (existingPoints) {
        return res.status(400).json({ error: 'Points already exist for this task' });
      }

      // Create using BaseController's create
      return super.create(req, res);
    } catch (error) {
      console.error('DailyTaskPoint creation error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Custom update with validation (override BaseController)
  async update(req, res) {
    try {
      const { id } = req.params;
      const { points } = req.body;

      if (points === undefined) {
        return res.status(400).json({ error: 'points is required' });
      }

      // Update using BaseController's update
      return super.update(req, res);
    } catch (error) {
      console.error('DailyTaskPoint update error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Inherited methods
  // async findAll(req, res) {
  //   return super.findAll(req, res);
  // }

  async findAll(req, res) {
    try {
      const dailyTaskPoints = await DailyTaskPoint.findAll({
        include: [{
          model: DailyTaskConfiguration,
          attributes: ['task_name']
        }]
      });

      // Map the response to include task_name
      const response = dailyTaskPoints.map(point => ({
        id: point.id,
        daily_task_id: point.daily_task_id,
        points: point.points,
        createdAt: point.createdAt,
        updatedAt: point.updatedAt,
        task_name: point.daily_task_configuration ? point.daily_task_configuration.task_name : null
      }));
  
      return res.status(200).json(response);
    } catch (error) {
      console.error('DailyTaskPoint findAll error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async findById(req, res) {
    return super.findById(req, res);
  }

  async delete(req, res) {
    return super.delete(req, res);
  }
}

module.exports = new DailyTaskPointController();