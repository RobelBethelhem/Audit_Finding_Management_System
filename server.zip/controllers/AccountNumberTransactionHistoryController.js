const BaseController = require('./BaseController');
const { AccountNumberTransactionHistory, AdminUser, User, Level, AccountNumberBalance, BankAccountConfiguration, sequelize } = require('../models');
const Decimal = require('decimal.js');

class AccountNumberTransactionHistoryController extends BaseController {
  constructor() {
    super(AccountNumberTransactionHistory);
    this.create = this.create.bind(this);
    this.getByAccount = this.getByAccount.bind(this);
  }

  async create(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { bank_account_configuration_id, transaction_amount, transaction_type, transaction_done_by } = req.body;

      if (!bank_account_configuration_id || !transaction_amount || !transaction_type || !transaction_done_by) {
        await transaction.rollback();
        return res.status(400).json({ error: 'All fields are required' });
      }

      // Fetch the account balance
      const accountBalance = await AccountNumberBalance.findOne({
        where: { bank_account_configuration_id },
        transaction
      });

      if (!accountBalance) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Bank account not found' });
      }

      let newBalance;
      if (transaction_type === 'Credit') {
        newBalance = new Decimal(accountBalance.account_balance).plus(transaction_amount);
      } else if (transaction_type === 'Debit') {
        if (new Decimal(accountBalance.account_balance).lessThan(transaction_amount)) {
          await transaction.rollback();
          return res.status(400).json({ error: 'Insufficient funds' });
        }
        newBalance = new Decimal(accountBalance.account_balance).minus(transaction_amount);
      } else {
        await transaction.rollback();
        return res.status(400).json({ error: 'Invalid transaction type' });
      }

      // Update account balance
      await accountBalance.update({ account_balance: newBalance.toFixed(2) }, { transaction });

      // Create transaction history
      const newTransaction = await AccountNumberTransactionHistory.create({
        bank_account_configuration_id,
        transaction_amount,
        transaction_type,
        transaction_done_by,
        status: 'Pending'
      }, { transaction });

      await transaction.commit();
      res.status(201).json({ message: 'Transaction recorded successfully', transaction: newTransaction });
    } catch (error) {
      await transaction.rollback();
      console.error('Transaction history error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async getByAccount(req,res){
    const transaction = await sequelize.transaction();
    try {
      const { bank_account_configuration_id } = req.params;
      const availableBalance = await AccountNumberBalance.findOne({
        where: { bank_account_configuration_id },
        attributes: ['account_balance'],
        transaction
      });
      const transactions = await AccountNumberTransactionHistory.findAll({
        where: { bank_account_configuration_id },
        include: [
          {
            model: BankAccountConfiguration,
            as: 'BankAccountConfiguration',
            attributes: ['bank_name', 'account_number','account_holder_name'],
            include: [
              {
                model: AdminUser,
                as: 'Manager',
                attributes: ['id', 'username', 'status'],
              }
            ]
          },    
          {
            model: AdminUser,
            as: 'AdminInitiator',
            attributes: ['id', 'username', 'status'],
          },
          {
            model: AdminUser,
            as: 'TransactionChecker',
            attributes: ['id', 'username', 'status'],
          },
          {
            model: User,
            as: 'UserInitiator',
            attributes: ['id', 'username', 'level_id', 'status'],
            include: [
              {
                model: Level,
                attributes: ['id', 'short_code', 'amount'],
              }
            ]
          }
        ],
        transaction
      });

      await transaction.commit();
      res.status(200).json({ transactions,availableBalance });
    } catch (error) {
      console.error('Error fetching transactions:', error);
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = new AccountNumberTransactionHistoryController();