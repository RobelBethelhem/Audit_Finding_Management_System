const axios = require('axios');
const { DailyTaskConfiguration, DailyTaskGame } = require('../models'); // Adjust based on your model imports

async function checkPuzzleSequence(req, res) {
  try {
    // Extract the clicked number and user ID
    const { clickedNumber } = req.body;
    const userId = req.user.id; // Assuming middleware sets req.user

    if (!clickedNumber || isNaN(clickedNumber)) {
      return res.status(400).json({ error: 'Invalid or missing clickedNumber' });
    }

    // Fetch the active Cipher game configuration
    const activeGameConfig = await DailyTaskConfiguration.findOne({
      where: { task_name: 'Puzzle' },
      attributes: ['id'],
      include: [{
        model: DailyTaskGame,
        where: { isExpired: false },
        attributes: ['value'],
      }],
    });

    if (!activeGameConfig) {
      return res.status(404).json({ error: 'No active Puzzle game configuration found' });
    }

    //console.log("activeGameConfigactiveGameConfig",activeGameConfig.daily_task_games);

    const cipherValue = activeGameConfig.daily_task_games?.[0]?.value;

    if (!cipherValue || typeof cipherValue !== 'string') {
      return res.status(400).json({ error: 'Invalid or missing value in Cipher game' });
    }

    // Convert the cipher value (e.g., "6-12-3-11-4-8") into an array of numbers
    const correctSequence = cipherValue.split('-').map(Number); // [6, 12, 3, 11, 4, 8]

    // Initialize or retrieve the user's progress from the session
    if (!req.session.sequenceIndex) {
      req.session.sequenceIndex = 0; // Start at the first number
    }

    const currentIndex = req.session.sequenceIndex;
    const expectedNumber = correctSequence[currentIndex];

    // Check if the clicked number matches the expected number
    if (parseInt(clickedNumber) === expectedNumber) {
      // Correct input
      req.session.sequenceIndex += 1; // Move to the next number in the sequence

      // Check if the entire sequence is completed
      if (req.session.sequenceIndex === correctSequence.length) {
        // Sequence completed successfully
        const dailyTaskId = activeGameConfig.id; // Get the daily_task_id
        const answer = cipherValue; // The full sequence as the answer

        // Automatically submit the task
        //await submitTaskCompletion(userId, dailyTaskId, answer);

        // Reset the user's progress
        delete req.session.sequenceIndex;

        return res.status(200).json({ message: 'Sequence completed successfully', data: {dailyTaskId, answer} });
      } else {
        // Sequence not yet complete, but the input was correct
        return res.status(200).json({ message: 'Correct, continue' });
      }
    } else {
      // Incorrect input
      req.session.sequenceIndex = 0; // Reset progress
      return res.status(400).json({ error: 'Incorrect number, sequence reset' });
    }
  } catch (error) {
    console.error('Error checking sequence:', error);
    return res.status(500).json({ error: error.message });
  }
}

// Helper function to submit the task
async function submitTaskCompletion(userId, dailyTaskId, answer) {
  try {
    const source = 'backend';
    const response = await axios.post('http://localhost:3000/api/user-tasks/submit', {
        userId,
        daily_task_id: dailyTaskId,
        answer,
        source
      }, {
        headers: { 
        },
        withCredentials: true  // Crucial for sending cookies (including session cookies) in CORS
      });
    console.log('Task submitted successfully:', response.data);
  } catch (error) {
    console.error('Error submitting task:', error);
    throw error;
  }
}

module.exports = { checkPuzzleSequence };