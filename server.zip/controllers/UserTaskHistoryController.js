const BaseController = require('./BaseController');
const { UserTaskHistory, User, UserAssignedToSystemSellTaskPackage, SystemSellTaskPackage, sequelize } = require('../models'); // Import necessary models
const { Op } = require('sequelize');
const { model } = require('./UserGiveAwayHistoryController');

class UserTaskHistoryController extends BaseController {
    constructor() {
        super(UserTaskHistory);
        console.log('UserTaskHistoryController initialized');
    }

    // Custom create with validation (and Transaction)

    async create(req, res) {
        let transaction;
        try {
    
            transaction = await sequelize.transaction();
            req.body.user_id = req.user.id;
    
            const { username, user_id } = req.body; // Expect user_id from frontend
    
            const refferedUser = await User.findOne({
                where: { username },
                transaction
            });


            if (!refferedUser) {
                await transaction.rollback();
                return res.status(400).json({ error: 'Referred user does not exist.' });
            }

            const currentDate = new Date();
            const startOfDay = new Date(
                currentDate.getFullYear(),
                currentDate.getMonth(),
                currentDate.getDate()
            ); // Set time to 00:00:00
            
            const endOfDay = new Date(
                currentDate.getFullYear(),
                currentDate.getMonth(),
                currentDate.getDate() + 1
            ); // Set time to 00:00:00 of the NEXT day
            
            const userTaskHistory = await UserTaskHistory.findOne({
                where: {
                    reffered_user_id: refferedUser.id,
                    date: {
                        [Op.gte]: startOfDay,
                        [Op.lt]: endOfDay
                    }
                },
                transaction
            });
            
            if (userTaskHistory) {
                await transaction.rollback();
                return res.status(400).json({ error: 'User Task History already exists for today' });
            }
            
    
            // Validate input
            if (!username || !user_id) {
                return res.status(400).json({ error: 'Username and user_id are required' });
            }
    
            if (!refferedUser) {
                return res.status(400).json({ error: 'Referred user does not exist.' });
            }
    
            // Validate that user_id exists in the User model
            const existingUser = await User.findByPk(user_id, { transaction });
            if (!existingUser) {
                return res.status(400).json({ error: 'user_id does not exist in User' });
            }
    
            // --- Fetch UserAssignedToSystemSellTaskPackage for the given user within the same day ---
            const today = new Date();
            today.setHours(0, 0, 0, 0); // Start of today
            const tomorrow = new Date(today);
            tomorrow.setDate(today.getDate() + 1); // Start of tomorrow
    
    
            const userAssignedPackage = await UserAssignedToSystemSellTaskPackage.findOne({
                where: {
                    user_id: user_id,
                    createdAt: {
                        [Op.gte]: today,
                        [Op.lt]: tomorrow
                    }
                },
                transaction,
                include: [{
                    model: SystemSellTaskPackage,
                    as: 'SystemSellTaskPackage'
                }]
            });
    
    
    
            if (!userAssignedPackage) {
                return res.status(400).json({ error: 'No User Invited today' });
            }
    
            const user_assigned_to_system_sell_task_package_id = userAssignedPackage.id;
            const systemSellTaskPackage = userAssignedPackage.SystemSellTaskPackage;
    
            // ----Validate  Refferal Limit ----
            const referralCount = await UserTaskHistory.count({
                where: {
                    user_assigned_to_system_sell_task_package_id: user_assigned_to_system_sell_task_package_id
                },
                transaction
            });
    
            if (referralCount > systemSellTaskPackage.refferal_limit) {
                await transaction.rollback();
                return res.status(400).json({ error: `Referral limit reached for this package. Limit is ${systemSellTaskPackage.refferal_limit}` });
            }
    
    
            //Set the System Date
    
            const date = new Date()
    
            // Create UserTaskHistory record
            const item = await UserTaskHistory.create({
                reffered_user_id: refferedUser.id,
                user_assigned_to_system_sell_task_package_id,
                date: date, //Use current system timestamp
                status: 'Pending'
            }, { transaction });
    
    
            await transaction.commit(); // Commit the transaction if everything is successful
            return res.status(201).json({
                message: 'User Task History created succesfully',
                data: item
            });
    
        } catch (error) {
            if (transaction) {
                await transaction.rollback(); // Rollback the transaction if any error occurs
            }
            console.error('UserTaskHistory creation error:', error);
            res.status(500).json({ error: error.message });
        }
    }


    // Custom update with validation (and explicit field definition and Transaction)
    async update(req, res) {
        let transaction;
        try {
            transaction = await sequelize.transaction(); // Start a transaction

            const { id } = req.params;
            const { status } = req.body; // Only status is updateable

            // Validate Status Enums
            if (status && !['Pending', 'Accepted'].includes(status)) {
                return res.status(400).json({error: 'Invalid Status Value: Status must be "Pending" or "Accepted"'})
            }


            // Build the update object, only including allowed fields
            const updateData = {};
            if (status) {
              updateData.status = status
            }

            const [updated] = await this.model.update(updateData, {
                where: { id: req.params.id },
                transaction
            });

            if (updated) {
                const updatedItem = await this.model.findByPk(req.params.id, { transaction });
                await transaction.commit(); // Commit the transaction
                return res.status(200).json(updatedItem);
            } else {
                await transaction.rollback(); // Rollback the transaction
                return res.status(404).json({ error: 'UserTaskHistory not found' });
            }

        } catch (error) {
            if (transaction) {
                await transaction.rollback(); // Rollback the transaction if any error occurs
            }
            console.error('UserTaskHistory update error:', error);
            res.status(500).json({ error: error.message });
        }
    }

    // Inherited methods (explicitly listed for clarity)
    async findAll(req, res) {
        try {
            const items = await this.model.findAll(
                {
                    include: [{
                        model: User,
                        as: 'RefferedUser',
                        attributes: ['id', 'username']
                    },
                    {
                        model: UserAssignedToSystemSellTaskPackage,
                        as: 'UserAssignedToSystemSellTaskPackage',
                        attributes: ['id'],
                        include: [{
                            model: User,
                            as: 'User',
                            attributes: ['id', 'username']
                        }]
                    }
                
                ],
                }
            );
            return res.status(200).json(items);
        } catch (error) {
            console.error('UserTaskHistory findAll error:', error);
            res.status(500).json({ error: error.message });
        }
    }

    async findByUserId(req, res) {
        try {
            const user_id = req.user.id; 

           
            const today = new Date();
            today.setHours(0, 0, 0, 0); // Start of today
            const tomorrow = new Date(today);
            tomorrow.setDate(today.getDate() + 1); // Start of tomorrow

            const userAssignedPackage = await UserAssignedToSystemSellTaskPackage.findOne({
                where: {
                    user_id: user_id,
                    createdAt: {
                        [Op.gte]: today,
                        [Op.lt]: tomorrow
                    }
                }
            });

            if (!userAssignedPackage) {
                return res.status(404).json({ error: 'No User Invited today' });
            }

            const user_assigned_to_system_sell_task_package_id = userAssignedPackage.id;

            // --- Find UserTaskHistory by user_assigned_to_system_sell_task_package_id ---
            const userTaskHistories = await UserTaskHistory.findAll({
                where: {
                    user_assigned_to_system_sell_task_package_id: user_assigned_to_system_sell_task_package_id
                },
                include: [{
                    model: User,
                    as: 'RefferedUser' 
                }]
            });

            if (!userTaskHistories || userTaskHistories.length === 0) {
                return res.status(404).json({ error: 'No UserTaskHistory found for the given user and package today' });
            }

            return res.status(200).json(userTaskHistories);


        } catch (error) {
            console.error('Error finding UserTaskHistory by user ID:', error);
            return res.status(500).json({ error: error.message });
        }
    }
    // async delete(req, res) {
    //     return super.delete(req, res);
    // }
}

module.exports = new UserTaskHistoryController();