const { 
    DailyTaskGame, 
    DailyTaskPoint, 
    UserPointBalance, 
    User,
    Level,
    AuditLog,
    UserTaskHistory,
    UserGiveAwayHistory,
    sequelize 
  } = require('../models');
  const { Op } = require('sequelize');
  const moment = require('moment');
  
  class UserTaskSubmissionController {
    
    // Submit answer for a daily task with transaction
    // async submitTaskAnswer(req, res) {

    //   const transaction = await sequelize.transaction();
    //   try {
        
    //     const userId = req.user.id;
    //     req.body.user_id = userId;
    //     const { user_id, daily_task_id, answer } = req.body;
        
    //     // Validate input
    //     if (!user_id || !daily_task_id || !answer) {
    //       await transaction.rollback();
    //       return res.status(400).json({ error: 'user_id, daily_task_id, and answer are required' });
    //     }
  
    //     // Verify user exists
    //     const user = await User.findByPk(user_id, { transaction });
    //     if (!user) {
    //       await transaction.rollback();
    //       return res.status(404).json({ error: 'User not found' });
    //     }
  
    //     console.log("user.status", user.status);
    //     if (user.status !== 'Active' || user.level_id === null) {
    //       await transaction.rollback();
    //       return res.status(400).json({ error: 'You are not an active user, first subscribe our plan to get the points' });
    //     }
        
    //     // Find the active game for this task
    //     const game = await DailyTaskGame.findOne({
    //       where: {
    //         daily_task_id,
    //         isExpired: false,
    //         // Check if the game was created today
    //         createdAt: {
    //           [Op.gte]: moment().startOf('day').toDate(),
    //           [Op.lte]: moment().endOf('day').toDate()
    //         }
    //       },
    //       transaction
    //     });
        
    //     if (!game) {
    //       await transaction.rollback();
    //       return res.status(404).json({ error: 'No active game found for this task today' });
    //     }
        
    //     // Check if the user has already completed this task today
    //     const existingSubmission = await AuditLog.findOne({
    //       where: {
    //         user_id,
    //         action_type: 'TASK_COMPLETED',
    //         'details.task_id': daily_task_id,
    //         createdAt: {
    //           [Op.gte]: moment().startOf('day').toDate(),
    //           [Op.lte]: moment().endOf('day').toDate()
    //         }
    //       },
    //       transaction
    //     });
        
    //     if (existingSubmission) {
    //       await transaction.rollback();
    //       return res.status(400).json({ error: 'Task already completed today' });
    //     }
        
    //     // Check if the answer is correct
    //     if (game.value !== answer) {
    //       await transaction.rollback();
    //       return res.status(400).json({ error: 'Incorrect answer' });
    //     }
        
    //     // Get the points for this task
    //     const taskPoints = await DailyTaskPoint.findOne({ 
    //       where: { daily_task_id },
    //       transaction
    //     });
    //     if (!taskPoints) {
    //       await transaction.rollback();
    //       return res.status(404).json({ error: 'No points defined for this task' });
    //     }
        
    //     // Get or create user point balance
    //     let userPointBalance = await UserPointBalance.findOne({ 
    //       where: { user_id },
    //       transaction
    //     });
        
    //     if (!userPointBalance) {
    //       userPointBalance = await UserPointBalance.create({
    //         user_id,
    //         points: taskPoints.points
    //       }, { transaction });
    //     } else {
    //       await userPointBalance.update({
    //         points: userPointBalance.points + taskPoints.points
    //       }, { transaction });
    //     }
        
    //     // Create audit log
    //     await AuditLog.create({
    //       user_id,
    //       action_type: 'TASK_COMPLETED',
    //       details: {
    //         task_id: daily_task_id,
    //         points_earned: taskPoints.points,
    //         date: new Date()
    //       }
    //     }, { transaction });
        
    //     // Commit the transaction if everything succeeded
    //     await transaction.commit();
        
    //     return res.status(200).json({
    //       message: 'Task completed successfully',
    //       points_earned: taskPoints.points,
    //       new_balance: userPointBalance.points
    //     });
        
    //   } catch (error) {
    //     // Roll back the transaction if any error occurred
    //     await transaction.rollback();
    //     console.error('Task submission error:', error);
    //     return res.status(500).json({ error: error.message });
    //   }
    // }


    async submitTaskAnswer(req, res) {

      const transaction = await sequelize.transaction();
      try {
        
        const userId = req.user.id;
        req.body.user_id = userId;
        const { user_id, daily_task_id, answer, answer_type } = req.body;
        
        // Validate input
        if (!user_id || !daily_task_id || !answer) {
          await transaction.rollback();
          return res.status(400).json({ error: 'user_id, daily_task_id, and answer are required' });
        }
  
        // Verify user exists
        const user = await User.findByPk(user_id, { transaction });
        if (!user) {
          await transaction.rollback();
          return res.status(404).json({ error: 'User not found' });
        }
  
        console.log("user.status", user.status);
        if (user.status !== 'Active' || user.level_id === null) {
          await transaction.rollback();
          return res.status(400).json({ error: 'You are not an active user, first subscribe our plan to get the points' });
        }

         // Calculate date difference for "free_for_45_days"
         const userCreatedAt = moment(user.createdAt);
         const now = moment();
         const diffInDays = now.diff(userCreatedAt, 'days');

          // Check if the user has already completed this task today
          const existingSubmission = await AuditLog.findOne({
            where: {
                user_id,
                action_type: 'TASK_COMPLETED',
                'details.task_id': daily_task_id,
                createdAt: {
                    [Op.gte]: moment().startOf('day').toDate(),
                    [Op.lte]: moment().endOf('day').toDate()
                }
            },
            transaction
        });

        if (existingSubmission) {
          await transaction.rollback();
          return res.status(400).json({ error: 'Task already completed today' });
      }

      let pointsEarned = 0; // Initialize points earned

      // --- Handle "free_for_45_days" answer type ---
      if (answer_type === 'free_for_45_days') {
        if (diffInDays > 45) {
            await transaction.rollback();
            return res.status(400).json({ error: 'This offer is only available for the first 45 days after registration.' });
        }

        // Find Level Amount
        const level = await Level.findByPk(user.level_id, {transaction})
         if (!level) {
                await transaction.rollback();
                return res.status(404).json({ error: 'No Level define to get this option' });
            }

        const amount = level.amount
        // Calculate Points
        pointsEarned = parseFloat((amount / 660).toFixed(2));

        // Get or create user point balance
        let userPointBalance = await UserPointBalance.findOne({
            where: { user_id },
            transaction
        });

        if (!userPointBalance) {
            userPointBalance = await UserPointBalance.create({
                user_id,
                points: pointsEarned
            }, { transaction });
        } else {
            await userPointBalance.update({
                points: userPointBalance.points + pointsEarned
            }, { transaction });
        }
        // Create audit log
        await AuditLog.create({
            user_id,
            action_type: 'TASK_COMPLETED',
            details: {
                task_id: daily_task_id,
                points_earned: pointsEarned,
                date: new Date()
            }
        }, { transaction });

        await transaction.commit();

        return res.status(200).json({
            message: 'Task completed successfully (free 45 days offer)',
            points_earned: pointsEarned,
            new_balance: userPointBalance.points
        });
        }

        else {


      // --- Check if the user is authorized to get coins (UserTaskHistory or UserGiveAwayHistory) ---
         const todayStart = moment().startOf('day').toDate();
         const todayEnd = moment().endOf('day').toDate();

         let historyRecord = await UserTaskHistory.findOne({
          where: {
              reffered_user_id: user_id,
              date: {
                  [Op.gte]: todayStart,
                  [Op.lte]: todayEnd
              },
              status: 'Pending'
          },
          transaction
          });

          if (!historyRecord) {
            historyRecord = await UserGiveAwayHistory.findOne({
                where: {
                    reffered_user_id: user_id,
                    date: {
                        [Op.gte]: todayStart,
                        [Op.lte]: todayEnd
                    },
                    status: 'Pending'
                },
                transaction
            });

            if (!historyRecord) {
                await transaction.rollback();
                return res.status(403).json({ error: 'You are not authorized to get coins for this task.' });
            }
        }


         // Change the Status to Accepted
         historyRecord.status = 'Accepted';
         await historyRecord.save({transaction})

         // Find the active game for this task
         const game = await DailyTaskGame.findOne({
          where: {
            daily_task_id,
            isExpired: false,
            // Check if the game was created today
            createdAt: {
              [Op.gte]: moment().startOf('day').toDate(),
              [Op.lte]: moment().endOf('day').toDate()
            }
          },
          transaction
        });
        
        if (!game) {
          await transaction.rollback();
          return res.status(404).json({ error: 'No active game found for this task today' });
        }
        
        // Check if the user has already completed this task today
        const existingSubmission = await AuditLog.findOne({
          where: {
            user_id,
            action_type: 'TASK_COMPLETED',
            'details.task_id': daily_task_id,
            createdAt: {
              [Op.gte]: moment().startOf('day').toDate(),
              [Op.lte]: moment().endOf('day').toDate()
            }
          },
          transaction
        });
        
        if (existingSubmission) {
          await transaction.rollback();
          return res.status(400).json({ error: 'Task already completed today' });
        }
        
        // Check if the answer is correct
        if (game.value !== answer) {
          await transaction.rollback();
          return res.status(400).json({ error: 'Incorrect answer' });
        }
        
        // Get the points for this task
        const taskPoints = await DailyTaskPoint.findOne({ 
          where: { daily_task_id },
          transaction
        });
        if (!taskPoints) {
          await transaction.rollback();
          return res.status(404).json({ error: 'No points defined for this task' });
        }
        
        // Get or create user point balance
        let userPointBalance = await UserPointBalance.findOne({ 
          where: { user_id },
          transaction
        });
        
        if (!userPointBalance) {
          userPointBalance = await UserPointBalance.create({
            user_id,
            points: taskPoints.points
          }, { transaction });
        } else {
          await userPointBalance.update({
            points: userPointBalance.points + taskPoints.points
          }, { transaction });
        }
        
        // Create audit log
        await AuditLog.create({
          user_id,
          action_type: 'TASK_COMPLETED',
          details: {
            task_id: daily_task_id,
            points_earned: taskPoints.points,
            date: new Date()
          }
        }, { transaction });
        
        // Commit the transaction if everything succeeded
        await transaction.commit();
        
        return res.status(200).json({
          message: 'Task completed successfully',
          points_earned: taskPoints.points,
          new_balance: userPointBalance.points
        });
      }
        
      } catch (error) {
        // Roll back the transaction if any error occurred
        await transaction.rollback();
        console.error('Task submission error:', error);
        return res.status(500).json({ error: error.message });
      }
    }


  
    // Get user point balance
    async getUserPointBalance(req, res) {
      try {
        const { user_id } = req.params;
        
        if (!user_id) {
          return res.status(400).json({ error: 'user_id is required' });
        }
  
        // Find user
        const user = await User.findByPk(user_id);
        if (!user) {
          return res.status(404).json({ error: 'User not found' });
        }
  
        // Get point balance
        const pointBalance = await UserPointBalance.findOne({ where: { user_id } });
        
        if (!pointBalance) {
          return res.status(200).json({
            user_id,
            points: 0
          });
        }
  
        return res.status(200).json(pointBalance);
        
      } catch (error) {
        console.error('Error fetching user point balance:', error);
        res.status(500).json({ error: error.message });
      }
    }
  
    // Get task completion history for a user
    async getUserTaskHistory(req, res) {
      try {
        const { user_id } = req.params;
        
        if (!user_id) {
          return res.status(400).json({ error: 'user_id is required' });
        }
  
        // Find user
        const user = await User.findByPk(user_id);
        if (!user) {
          return res.status(404).json({ error: 'User not found' });
        }
  
        // Get task completion logs
        const taskLogs = await AuditLog.findAll({
          where: {
            user_id,
            action_type: 'TASK_COMPLETED'
          },
          order: [['createdAt', 'DESC']]
        });
  
        return res.status(200).json(taskLogs);
        
      } catch (error) {
        console.error('Error fetching user task history:', error);
        res.status(500).json({ error: error.message });
      }
    }
  }
  
  module.exports = new UserTaskSubmissionController();