const BaseController = require('./BaseController');
const { GLAccount, GLAccountHistory, sequelize } = require('../models');

class GLAccountController extends BaseController {
  constructor() {
    super(GLAccount); 
  }

  async create(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { account_number, available_balance, gl_account_type } = req.body;

      // Validate required fields
      if (!account_number || !available_balance || !gl_account_type) {
        await transaction.rollback();
        return res.status(400).json({ error: 'account_number, available_balance, and gl_account_type are required' });
      }

      // Create new GL account
      const newGLAccount = await GLAccount.create({
        account_number,
        available_balance,
        gl_account_type
      }, { transaction });

      await transaction.commit();
      res.status(201).json(newGLAccount);
    } catch (error) {
      await transaction.rollback();
      console.error('Create GL account error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async update(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { id } = req.params;
      const { account_number, available_balance, gl_account_type } = req.body;

      const glAccount = await GLAccount.findByPk(id, { transaction });
      if (!glAccount) {
        await transaction.rollback();
        return res.status(404).json({ error: 'GL account not found' });
      }

      // Update fields if provided
      if (account_number) glAccount.account_number = account_number;
      if (available_balance !== undefined) glAccount.available_balance = available_balance;
      if (gl_account_type) glAccount.gl_account_type = gl_account_type;

      await glAccount.save({ transaction });
      await transaction.commit();
      res.status(200).json(glAccount);
    } catch (error) {
      await transaction.rollback();
      console.error('Update GL account error:', error);
      res.status(500).json({ error: error.message });
    }
  }


  async findAll(req, res) {
    try {
      const glAccounts = await GLAccount.findAll();
      res.status(200).json(glAccounts);
    } catch (error) {
      console.error('GLAccount findAll error:', error);
      res.status(500).json({ error: error.message });
    }
  }


  async delete(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { id } = req.params;
      const glAccount = await GLAccount.findByPk(id, { transaction });
      if (!glAccount) {
        await transaction.rollback();
        return res.status(404).json({ error: 'GL account not found' });
      }

      const isGLAccountUsed = await GLAccountHistory.findOne({
        where: { gl_account_id: id },
        transaction
      });
      if (isGLAccountUsed) {
        await transaction.rollback();
        return res.status(409).json({ error: 'GL account is still in use' });
      }
      await glAccount.destroy({ transaction });
      await transaction.commit();
      res.status(200).json({ message: 'GL account deleted successfully' });
    } catch (error) {
      await transaction.rollback();
      console.error('Delete GL account error:', error);
      res.status(500).json({ error: error.message });
    }
  }

}

module.exports = new GLAccountController();