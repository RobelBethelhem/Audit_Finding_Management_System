const BaseController = require('./BaseController');
const { SystemSellTaskPackage, sequelize } = require('../models'); // Import the model
const sequelizee = require('sequelize');

class SystemSellTaskPackageController extends BaseController {
    constructor() {
        super(SystemSellTaskPackage);
        console.log('SystemSellTaskPackageController initialized');
    }

    // Custom create with validation (and Transaction)
    async create(req, res) {
        let transaction;
        try {
            transaction = await sequelize.transaction(); // Start a transaction

            const { package_name, value, refferal_limit, status } = req.body;

            // Validate input
            if (!package_name || !value || !refferal_limit || !status) {
                return res.status(400).json({ error: 'package_name, value, refferal_limit, and status are required' });
            }

            // Check for existing package_name (uniqueness)
            const existingPackage = await SystemSellTaskPackage.findOne({
                where: { package_name: package_name },
                transaction // Use the transaction
            });
            if (existingPackage) {
                return res.status(400).json({ error: 'package_name already exists' });
            }

            // Create using BaseController's create (with transaction)
            const item = await this.model.create(req.body, { transaction });

            await transaction.commit(); // Commit the transaction if everything is successful
            return res.status(201).json(item);

        } catch (error) {
            if (transaction) {
                await transaction.rollback(); // Rollback the transaction if any error occurs
            }
            console.error('SystemSellTaskPackage creation error:', error);
            res.status(500).json({ error: error.message });
        }
    }

    // Custom update with validation and explicit field definition (and Transaction)
    async update(req, res) {
        let transaction;
        try {
            transaction = await sequelize.transaction(); // Start a transaction

            const { id } = req.params;
            const { package_name, value, refferal_limit, status } = req.body;

            // Check for existing package_name (uniqueness), excluding the current record
            if (package_name) {
                const existingPackage = await SystemSellTaskPackage.findOne({
                    where: {
                        package_name: package_name,
                        id: { [sequelizee.Op.ne]: id }  // Exclude the current record
                    },
                    transaction // Use the transaction
                });
                if (existingPackage) {
                    return res.status(400).json({ error: 'package_name already exists' });
                }
            }

            // Build the update object, only including allowed fields
            const updateData = {};
            if (package_name) {
                updateData.package_name = package_name;
            }
            if (value) {
                updateData.value = value;
            }
            if (refferal_limit) {
                updateData.refferal_limit = refferal_limit;
            }
            if (status) {
                updateData.status = status;
            }

            const [updated] = await this.model.update(updateData, {
                where: { id: req.params.id },
                transaction // Use the transaction
            });

            if (updated) {
                const updatedItem = await this.model.findByPk(req.params.id, {
                    transaction // Use the transaction
                });
                await transaction.commit(); // Commit the transaction
                return res.status(200).json(updatedItem);
            } else {
                await transaction.rollback(); // Rollback the transaction
                return res.status(404).json({ error: 'SystemSellTaskPackage not found' });
            }

        } catch (error) {
            if (transaction) {
                await transaction.rollback(); // Rollback the transaction if any error occurs
            }
            console.error('SystemSellTaskPackage update error:', error);
            res.status(500).json({ error: error.message });
        }
    }

    // Inherited methods (explicitly listed for clarity)
    async findAll(req, res) {
        return super.findAll(req, res);
    }

    async delete(req, res) {
        return super.delete(req, res);
    }
}

module.exports = new SystemSellTaskPackageController();