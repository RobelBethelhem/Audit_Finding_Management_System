const BaseController = require('./BaseController');
const { CategoryForInvesting, GLAccountHistory, sequelize } = require('../models');

class CategoryForInvestingController extends BaseController {
  constructor() {
    super(CategoryForInvesting); // Inherits findAll, findById, delete from BaseController
  }

  // CREATE: Add a new category
  async create(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { category_name, purpose } = req.body;

      // Validate required fields
      if (!category_name || !purpose) {
        await transaction.rollback();
        return res.status(400).json({ error: 'category_name and purpose are required' });
      }

      // Create new category
      const newCategory = await CategoryForInvesting.create(
        {
          category_name,
          purpose
        },
        { transaction }
      );

      await transaction.commit();
      res.status(201).json(newCategory);
    } catch (error) {
      await transaction.rollback();
      console.error('Create category error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // READ: Get all categories (inherited from BaseController's findAll)
  // Example route: GET /categories-for-investing
  // No additional implementation needed if BaseController provides findAll

  // READ: Get a single category by ID (inherited from BaseController's findById)
  // Example route: GET /categories-for-investing/:id
  // No additional implementation needed if BaseController provides findById

  // UPDATE: Modify an existing category
  async update(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { id } = req.params;
      const { category_name, purpose } = req.body;

      const category = await CategoryForInvesting.findByPk(id, { transaction });
      if (!category) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Category not found' });
      }

      // Update fields if provided
      if (category_name) category.category_name = category_name;
      if (purpose) category.purpose = purpose;

      await category.save({ transaction });
      await transaction.commit();
      res.status(200).json(category);
    } catch (error) {
      await transaction.rollback();
      console.error('Update category error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async findAll(req, res) {
    try {
      const categories = await CategoryForInvesting.findAll();
      res.status(200).json(categories);
    } catch (error) {
      console.error('CategoryForInvesting findAll error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async delete(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { id } = req.params;
      const category = await CategoryForInvesting.findByPk(id, { transaction });
      if (!category) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Category not found' });
      }

      const isCategoryUsed = await GLAccountHistory.findOne({
        where: { category_id: id },
        transaction
      });
      if (isCategoryUsed) {
        await transaction.rollback();
        return res.status(409).json({ error: 'Category is still in use' });
      }
      await category.destroy({ transaction });
      await transaction.commit();
      res.status(200).json({ message: 'Category deleted successfully' });
    } catch (error) {
      await transaction.rollback();
      console.error('Delete category error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // DELETE: Remove a category (inherited from BaseController's delete)
  // Example route: DELETE /categories-for-investing/:id
  // No additional implementation needed if BaseController provides delete
}

module.exports = new CategoryForInvestingController();