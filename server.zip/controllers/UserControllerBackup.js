const BaseController = require('./BaseController');
const { User, ParentUser, FirstGeneration, SecondGeneration, ThirdGeneration , Level , CashWithdrawHistory, PaymentInformation} = require('../models');
const bcrypt = require('bcrypt');
const { sequelize } = require('../models');
const { Op } = require('sequelize'); // Add this line
const Decimal = require('decimal.js');

class UserController extends BaseController {
  constructor() {
    super(User);

    console.log('UserController constructor called');

    this.register = this.register.bind(this);
    this.login = this.login.bind(this);
    this.create = this.create.bind(this);
    this.findAll = this.findAll.bind(this);
    this.findById = this.findById.bind(this);
    this.update = this.update.bind(this);
    this.delete = this.delete.bind(this);
    this.getReferralTree = this.getReferralTree.bind(this);
    this.hasActiveReferrals = this.hasActiveReferrals.bind(this);
    this.giveUp = this.giveUp.bind(this);
    this.getDefaultPaymentInfo =  this.getDefaultPaymentInfo.bind(this);
  }

  async register(req, res) {
    try {
      console.log('Register request received:', req.body);
      const { username, password, referral_code } = req.body;

      // Validate input
      if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required' });
      }

      // Check if username already exists
      const existingUser = await  User.findOne({ where: { username } });
      if (existingUser) {
        return res.status(400).json({ error: 'Username already exists' });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      let parentUser = null;

      console.log("referral_code", referral_code);

      // If referral code is provided, find the parent user
      if (referral_code) {
        console.log("referral_codeee", referral_code);
        parentUser = await  User.findOne({ where: { id: referral_code } });

        console.log("parentUser", parentUser);
        if (!parentUser) {
          return res.status(404).json({ error: 'Invalid referral code' });
        }
      }

      // Create new user
    //   const newUser = await User.create({
    //     username,
    //     password: hashedPassword,
    //     parent_user_id: parentUser ? parentUser.id : null,
    //     status: 'Inactive'
    //   });


    let newUser;
    try {
      newUser = await User.create({
        username,
        password: hashedPassword,
        parent_user_id: parentUser ? parentUser.id : null,
        status: 'Inactive'
      });
      console.log('New user created:', newUser.toJSON());
    } catch (createError) {
      console.error('User creation error:', createError);
      return res.status(500).json({ error: 'Failed to create user', details: createError.message });
    }


      // Create parent user record
      try {
      await ParentUser.create({
        user_id: newUser.id,
        parent_user_id: parentUser ? parentUser.id : null
      });
    } catch (parentUserError) {
        console.error('Parent user record creation error:', parentUserError);
        // Optionally, you might want to rollback the user creation here
      }

      // If parent user exists, update generation tables
      if (parentUser) {
        try {
        await this.updateGenerations(parentUser.id, newUser.id, 1);
        } catch (generationError) {
          console.error('Generation update error:', generationError);
          // Optionally, you might want to rollback the user creation here
        }
      }

      res.status(201).json({ 
        message: 'User registered successfully', 
        user: { 
          id: newUser.id, 
          username: newUser.username 
        } 
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async updateGenerations(parentUserId, newUserId, generationLevel) {
    if (generationLevel > 3) {
      return; // Stop recursion after the third generation
    }

    // Update the corresponding generation table
    switch (generationLevel) {
      case 1:
        await this.updateGenerationRecord(FirstGeneration, parentUserId, newUserId, 10);
        break;
      case 2:
        await this.updateGenerationRecord(SecondGeneration, parentUserId, newUserId, 20);
        break;
      case 3:
        await this.updateGenerationRecord(ThirdGeneration, parentUserId, newUserId, 30);
        break;
      default:
        console.log('No generation record created');
    }

    // Find the parent of the current parent user
    const parentUser = await ParentUser.findOne({ 
      where: { user_id: parentUserId } 
    });

    if (parentUser && parentUser.parent_user_id) {
      // Recursively update the next generation
      await this.updateGenerations(parentUser.parent_user_id, newUserId, generationLevel + 1);
    }
  }

  async updateGenerationRecord(Model, parentUserId, newUserId, maxReferrals) {
    
    try{
    const existingRecord = await Model.findOne({ 
      where: { user_id: parentUserId } 
    });

      // Parse existing referral users or start with an empty array
    // const referralUsers = existingRecord && existingRecord.referral_users 
    //   ? JSON.parse(existingRecord.referral_users) 
    //   : [];

    let referralUsers = [];

     if (existingRecord) {
      // Handle existing data that might be stored as JSON string
      if (typeof existingRecord.referral_users === 'string') {
        referralUsers = JSON.parse(existingRecord.referral_users);
      } else if (Array.isArray(existingRecord.referral_users)) {
        referralUsers = [...existingRecord.referral_users];
      }
    }

      // Add debug logging
      console.log('Current referral users:', referralUsers);
      console.log('Type of referralUsers:', typeof referralUsers);


       // Prevent duplicates
    if (!referralUsers.includes(newUserId)) {
        referralUsers.push(newUserId);
      }

    //if (referralUsers.length < maxReferrals) {
      //referralUsers.push(newUserId);

      if (existingRecord) {
        await existingRecord.update({ 
         // referral_users: JSON.stringify(referralUsers) 
         referral_users: referralUsers
        });
      } else {
        await Model.create({
          user_id: parentUserId,
          referral_users: referralUsers
        });
      }
    // } 
    // else {
    //   throw new Error(`Maximum ${maxReferrals} referrals reached for this generation`);
    // }
    console.log('Updated referral users:', referralUsers);
    }
    catch (error) {
        console.error('Error in updateGenerationRecord:', error);
        throw error; // Re-throw to catch in the parent method
      }

  }

  async login(req, res) {
    try {
      const { username, password } = req.body;
      const user = await  User.findOne({ where: { username } });
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Compare passwords
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }
    req.session.userSession = req.user; // Set user session
      res.status(200).json({ 
        message: 'Login successful', 
        user: { 
          id: user.id, 
          username: user.username 
        } 
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async getReferralTree(req, res) {
    try {
      const { userId } = req.params;
  
      // Check if user exists
      const user = await User.findByPk(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
  
      // Get parent information
      const parentRecord = await ParentUser.findOne({
        where: { user_id: userId },
        include: [{
          model: User,
          as: 'Parent',
          attributes: ['id', 'username']
        }]
      });
  
      const parent = parentRecord && parentRecord.parent_user_id
        ? {
            id: parentRecord.Parent.id,
            username: parentRecord.Parent.username
          }
        : null;
  
      // Get first generation with user details
      const firstGeneration = await FirstGeneration.findOne({
        where: { user_id: userId },
        include: [{
          model: User,
          as: 'PrimaryUser',
          attributes: ['id', 'username']
        }]
      });
  
      let firstGenReferrals = [];
      let firstGenPaidReferrals = [];
      if (firstGeneration) {
        const referralUsers = Array.isArray(firstGeneration.referral_users)
          ? firstGeneration.referral_users
          : typeof firstGeneration.referral_users === 'string'
            ? JSON.parse(firstGeneration.referral_users)
            : [];
        const paidReferralUsers = Array.isArray(firstGeneration.paid_referral_users)
          ? firstGeneration.paid_referral_users
          : typeof firstGeneration.paid_referral_users === 'string'
            ? JSON.parse(firstGeneration.paid_referral_users)
            : [];
  
        firstGenReferrals = await User.findAll({
          where: { id: { [sequelize.Op.in]: referralUsers } },
          attributes: ['id', 'username']
        }).then(users => users.map(u => ({ id: u.id, username: u.username })));
  
        firstGenPaidReferrals = await User.findAll({
          where: { id: { [sequelize.Op.in]: paidReferralUsers } },
          attributes: ['id', 'username']
        }).then(users => users.map(u => ({ id: u.id, username: u.username })));
      }
  
      // Get second generation with user details (using the same userId)
      const secondGeneration = await SecondGeneration.findOne({
        where: { user_id: userId },
        include: [{
          model: User,
          as: 'PrimaryUser',
          attributes: ['id', 'username']
        }]
      });
  
      let secondGenReferrals = [];
      let secondGenPaidReferrals = [];
      if (secondGeneration) {
        const referralUsers = Array.isArray(secondGeneration.referral_users)
          ? secondGeneration.referral_users
          : typeof secondGeneration.referral_users === 'string'
            ? JSON.parse(secondGeneration.referral_users)
            : [];
        const paidReferralUsers = Array.isArray(secondGeneration.paid_referral_users)
          ? secondGeneration.paid_referral_users
          : typeof secondGeneration.paid_referral_users === 'string'
            ? JSON.parse(secondGeneration.paid_referral_users)
            : [];
  
        secondGenReferrals = await User.findAll({
          where: { id: { [sequelize.Op.in]: referralUsers } },
          attributes: ['id', 'username']
        }).then(users => users.map(u => ({ id: u.id, username: u.username })));
  
        secondGenPaidReferrals = await User.findAll({
          where: { id: { [sequelize.Op.in]: paidReferralUsers } },
          attributes: ['id', 'username']
        }).then(users => users.map(u => ({ id: u.id, username: u.username })));
      }
  
      // Get third generation with user details (using the same userId)
      const thirdGeneration = await ThirdGeneration.findOne({
        where: { user_id: userId },
        include: [{
          model: User,
          as: 'PrimaryUser',
          attributes: ['id', 'username']
        }]
      });
  
      let thirdGenReferrals = [];
      let thirdGenPaidReferrals = [];
      if (thirdGeneration) {
        const referralUsers = Array.isArray(thirdGeneration.referral_users)
          ? thirdGeneration.referral_users
          : typeof thirdGeneration.referral_users === 'string'
            ? JSON.parse(thirdGeneration.referral_users)
            : [];
        const paidReferralUsers = Array.isArray(thirdGeneration.paid_referral_users)
          ? thirdGeneration.paid_referral_users
          : typeof thirdGeneration.paid_referral_users === 'string'
            ? JSON.parse(thirdGeneration.paid_referral_users)
            : [];
  
        thirdGenReferrals = await User.findAll({
          where: { id: { [sequelize.Op.in]: referralUsers } },
          attributes: ['id', 'username']
        }).then(users => users.map(u => ({ id: u.id, username: u.username })));
  
        thirdGenPaidReferrals = await User.findAll({
          where: { id: { [sequelize.Op.in]: paidReferralUsers } },
          attributes: ['id', 'username']
        }).then(users => users.map(u => ({ id: u.id, username: u.username })));
      }
  
      // Construct response
      const response = {
        parent: parent,
        first_generation: {
          referral_users: firstGenReferrals,
          paid_referral_users: firstGenPaidReferrals
        },
        second_generation: {
          referral_users: secondGenReferrals,
          paid_referral_users: secondGenPaidReferrals
        },
        third_generation: {
          referral_users: thirdGenReferrals,
          paid_referral_users: thirdGenPaidReferrals
        }
      };
  
      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching referral tree:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async giveUp(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const {userId} = req.params;
      const user_id = userId;
    
      //1. validate user exists
      const user = await User.findByPk(user_id, { transaction });
    
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      if(user.status === 'Give_up') {
        return res.status(400).json({ error: 'User is already Give_up' });
      }

      // 2. Check parent status
      const parentUser = await ParentUser.findOne({
        where: { user_id },
        attributes: ['parent_user_id'],
        transaction
      });
      const hasParent = parentUser?.parent_user_id ? true : false;

      // 3. Check children status
      const hasChildren = await this.hasActiveReferrals(user_id, transaction);
      if (hasChildren) {
        return res.status(400).json({
          error: 'You cannot give up - you have active referrals'
        });
      }

       // 4. Determine eligibility
       let withdrawalPercentage = 0;
       if (!hasParent && !hasChildren) {
         withdrawalPercentage = 90;
       } else if (hasParent && !hasChildren) {
         withdrawalPercentage = 40;
       } else {
         return res.status(400).json({
           error: 'You are not eligible to give up'
         });
       }

        // 5. Calculate withdrawal amount
      const level = await Level.findByPk(user.level_id, { transaction });
      if (!level) {
        return res.status(400).json({ error: 'You are Not eligibe' });
      }
      
      const initialDeposit = new Decimal(level.amount);
      const withdrawalAmount = initialDeposit.mul(withdrawalPercentage).div(100);

      // 6. Create withdrawal request
      const paymentInfo = await this.getDefaultPaymentInfo(user_id, transaction);
      if (!paymentInfo) {
        return res.status(400).json({
          error: 'No payment information found. Please configure first'
        });
      }

      await User.update(
        { status: 'Give_up' },
        { 
          where: { id: user_id },
          transaction 
        }
      );

      await CashWithdrawHistory.create({
        payment_information_id: paymentInfo.id,
        amount: withdrawalAmount.toNumber(),
        status: 'Pending',
        reason: 'Give_up'
      }, { transaction });

      // 7. Update user status after approval (handled in withdrawal update)
      await transaction.commit();
      res.status(201).json({
        message: 'Give-up request submitted successfully',
        withdrawal_amount: withdrawalAmount.toNumber()
      });
  }
  catch (error) {
    await transaction.rollback();
    console.error('Give-up error:', error);
    res.status(500).json({ error: error.message });
  }

}

  async hasActiveReferrals(user_id, transaction) {
   
    const checks = [
        FirstGeneration.findOne({ 
            where: { 
                user_id, 
                paid_referral_users: { [Op.ne]: [] } 
            }, 
            transaction 
        }),
        SecondGeneration.findOne({ 
            where: { 
                user_id, 
                paid_referral_users: { [Op.ne]: [] } 
            }, 
            transaction 
        }),
        ThirdGeneration.findOne({ 
            where: { 
                user_id, 
                paid_referral_users: { [Op.ne]: [] } 
            }, 
            transaction 
        })
    ];

    const results = await Promise.all(checks);
    return results.some(result => result !== null);
}


  async getDefaultPaymentInfo(user_id, transaction) {
    return PaymentInformation.findOne({
      where: { user_id },
      order: [['createdAt', 'ASC']], // Get oldest payment info
      transaction
    });
  }



}

module.exports = new UserController();