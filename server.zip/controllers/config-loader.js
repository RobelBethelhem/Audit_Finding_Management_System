const {Configuration} = require('../models'); // Path to your Configuration model
const sellConfig = {}; // Object to store sell configurations
const commissionConfig = {}; // Object to store commission configurations

async function loadConfigurationFromDB() {
  try {
    const configurations = await Configuration.findAll();

    configurations.forEach(config => {
      try {
        const parsedValue = JSON.parse(config.configValue); // Parse JSON from database
        if (config.category === 'sell') {
          sellConfig[config.configKey] = parsedValue;
        } else if (config.category === 'commission') {
          commissionConfig[config.configKey] = parsedValue;
        } else {
          // Handle other categories or store in a general config object if needed
          // genericConfig[config.configKey] = parsedValue;
        }
      } catch (error) {
        console.error(`Error parsing JSON for configKey: ${config.configKey}`, error);
        // Handle JSON parsing error (e.g., log, use default value, etc.)
      }
    });

    // After loading, you can access configurations like:
    // sellConfig.systemBuyOneCoin, sellConfig.sellTiers, commissionConfig.commissionTiers
    console.log('Configuration loaded from database.');
  } catch (error) {
    console.error('Error loading configuration from database:', error);
    // Handle database connection or query errors (e.g., exit application, use default config, etc.)
    throw error; // Re-throw to stop application startup if config loading is critical
  }
}

module.exports = { loadConfigurationFromDB, sellConfig, commissionConfig };