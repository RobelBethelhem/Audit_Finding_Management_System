const BaseController = require('./BaseController');
const { PaidChildrenLimit } = require('../models');
const sequelize = require('sequelize');

class PaidChildrenLimitController extends BaseController {
  constructor() {
    super(PaidChildrenLimit);
    console.log('PaidChildrenLimitController initialized');
  }

  // Custom create with validation (override BaseController)
  async create(req, res) {
    try {
      const { first_generation_limit, second_generation_limit,third_generation_limit } = req.body;
      
      // Validate input
      if (!first_generation_limit || !second_generation_limit || !third_generation_limit) {
        return res.status(400).json({ error: 'first_generation_limit, second_generation_limit,third_generation_limit are required' });
      }

      const existingConfig = await PaidChildrenLimit.findOne();
      if (existingConfig) {
        return res.status(400).json({ error: 'Configuration already exists. Please use update instead.' });
      }

      // Create using BaseController's create
      return super.create(req, res);
    } catch (error) {
      console.error('Level creation error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Custom update with validation (override BaseController)
  async update(req, res) {
    try {
      const { id } = req.params;
      const { first_generation_limit, second_generation_limit,third_generation_limit } = req.body;

      console.log("updateupdate", id, first_generation_limit, second_generation_limit,third_generation_limit);


      // Update using BaseController's update
      return super.update(req, res);
    } catch (error) {
      console.error('Level update error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Inherited methods (explicitly listed for clarity)
  async findAll(req, res) {
    return super.findAll(req, res);
  }

  async findById(req, res) {
    return super.findById(req, res);
  }

  async delete(req, res) {
    return super.delete(req, res);
  }
}

module.exports = new PaidChildrenLimitController();