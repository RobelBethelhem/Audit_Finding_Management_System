const BaseController = require('./BaseController');
const { DailyTaskConfiguration } = require('../models');
const sequelize = require('sequelize');

class DailyTaskConfigurationController extends BaseController {
  constructor() {
    super(DailyTaskConfiguration);
    console.log('DailyTaskConfigurationController initialized');
  }

  // Custom create with validation (override BaseController)
  async create(req, res) {
    try {
      const { task_name } = req.body;
      
      // Validate input
      if (!task_name) {
        return res.status(400).json({ error: 'task_name is required' });
      }

      // Check for existing task_name
      const existingTask = await DailyTaskConfiguration.findOne({ where: { task_name } });
      if (existingTask) {
        return res.status(400).json({ error: 'task_name already exists' });
      }

      // Create using BaseController's create
      return super.create(req, res);
    } catch (error) {
      console.error('DailyTaskConfiguration creation error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Custom update with validation (override BaseController)
  async update(req, res) {
    try {
      const { id } = req.params;
      const { task_name } = req.body;

      // Check for existing task_name excluding current record
      if (task_name) {
        const existingTask = await DailyTaskConfiguration.findOne({
          where: {
            task_name,
            id: { [sequelize.Op.ne]: id }
          }
        });
        if (existingTask) {
          return res.status(400).json({ error: 'task_name already exists' });
        }
      }

      // Update using BaseController's update
      return super.update(req, res);
    } catch (error) {
      console.error('DailyTaskConfiguration update error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Inherited methods
  async findAll(req, res) {
    return super.findAll(req, res);
  }

  async findById(req, res) {
    return super.findById(req, res);
  }

  async delete(req, res) {
    return super.delete(req, res);
  }
}

module.exports = new DailyTaskConfigurationController();