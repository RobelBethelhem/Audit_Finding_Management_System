const BaseController = require('./BaseController');
const { AmountRangeConfiguration, AdminUser, BankAccountConfiguration, sequelize } = require('../models');

class AmountRangeConfigurationController extends BaseController {
  constructor() {
    super(AmountRangeConfiguration);
  }

  async create(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { bank_account_configuration_id, minimum_amount, maximum_amount } = req.body;

      // Validate required fields
      if (!bank_account_configuration_id || !minimum_amount || !maximum_amount) {
        await transaction.rollback();
        return res.status(400).json({ error: 'All fields are required' });
      }

      // Check if the bank account configuration exists
      const bankConfig = await BankAccountConfiguration.findByPk(bank_account_configuration_id, { transaction });
      if (!bankConfig) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Bank account configuration not found' });
      }

      // Additional validation: ensure minimum_amount < maximum_amount
      if (parseFloat(minimum_amount) >= parseFloat(maximum_amount)) {
        await transaction.rollback();
        return res.status(400).json({ error: 'Minimum amount must be less than maximum amount' });
      }

      // Check for existing configuration for the same bank account
      const existingRange = await AmountRangeConfiguration.findOne({
        where: {
          bank_account_configuration_id: bank_account_configuration_id,
        },
        transaction,
      });

      if (existingRange) {
        await transaction.rollback();
        return res.status(409).json({ error: 'Amount range already configured for this bank account' }); // 409 Conflict status
      }

      // Create new amount range configuration
      const newRange = await AmountRangeConfiguration.create(
        {
          bank_account_configuration_id,
          minimum_amount,
          maximum_amount,
        },
        { transaction }
      );

      await transaction.commit();
      res.status(201).json(newRange);
    } catch (error) {
      await transaction.rollback();
      console.error('Create amount range configuration error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async update(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { id } = req.params;
      const { minimum_amount, maximum_amount } = req.body;

      const rangeConfig = await AmountRangeConfiguration.findByPk(id, { transaction });
      if (!rangeConfig) {
        await transaction.rollback();
        return res.status(404).json({ error: 'Amount range configuration not found' });
      }

      // Update fields if provided
      if (minimum_amount !== undefined) rangeConfig.minimum_amount = minimum_amount;
      if (maximum_amount !== undefined) rangeConfig.maximum_amount = maximum_amount;

      // Validate updated values
      if (
        rangeConfig.minimum_amount !== undefined &&
        rangeConfig.maximum_amount !== undefined &&
        parseFloat(rangeConfig.minimum_amount) >= parseFloat(rangeConfig.maximum_amount)
      ) {
        await transaction.rollback();
        return res.status(400).json({ error: 'Minimum amount must be less than maximum amount' });
      }

      await rangeConfig.save({ transaction });
      await transaction.commit();
      res.status(200).json(rangeConfig);
    } catch (error) {
      await transaction.rollback();
      console.error('Update amount range configuration error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async findAll(req, res) {
    try {
        const rangeConfigurations = await AmountRangeConfiguration.findAll({
            include: [{
                model: BankAccountConfiguration,
                attributes: ['id', 'bank_name', 'account_number', 'account_holder_name', 'managed_by'],
                include: [{
                    model: AdminUser,
                    as: 'Manager',
                    attributes: ['id', 'username', 'email', 'status']
                }],
                required: true 
            }]
        });

        const response = rangeConfigurations.map(range => ({
            id: range.id,
            minimum_amount: range.minimum_amount,
            maximum_amount: range.maximum_amount,
            bank_account_configuration_id: range.bank_account_configuration ? range.bank_account_configuration.id : null,
            BankAccount: range.bank_account_configuration ? {
                id: range.bank_account_configuration.id,
                bank_name: range.bank_account_configuration.bank_name,
                account_number: range.bank_account_configuration.account_number,
                account_holder_name: range.bank_account_configuration.account_holder_name,
                managed_by: range.bank_account_configuration.managed_by,
                Manager: range.bank_account_configuration.Manager ? {
                    id: range.bank_account_configuration.Manager.id,
                    username: range.bank_account_configuration.Manager.username,
                    email: range.bank_account_configuration.Manager.email,
                    status: range.bank_account_configuration.Manager.status
                } : null
            } : null,
            createdAt: range.createdAt,
            updatedAt: range.updatedAt
        }));

        res.status(200).json(response);
    } catch (error) {
        console.error('AmountRangeConfiguration findAll error:', error);
        res.status(500).json({ error: error.message });
    }
}

  async findById(req, res) {
    return super.findById(req, res);
  }

  async delete(req, res) {
    return super.delete(req, res);
  }

  // findAll, findById, and delete are inherited from BaseController
}

module.exports = new AmountRangeConfigurationController();