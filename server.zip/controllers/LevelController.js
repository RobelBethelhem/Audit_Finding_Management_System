const BaseController = require('./BaseController');
const { Level } = require('../models');
const sequelize = require('sequelize');

class LevelController extends BaseController {
  constructor() {
    super(Level);
    console.log('LevelController initialized');
  }

  // Custom create with validation (override BaseController)
  async create(req, res) {
    try {
      const { short_code, amount, percentage } = req.body;
      
      // Validate input
      if (!short_code || !amount) {
        return res.status(400).json({ error: 'short_code and amount are required' });
      }

      // Check for existing short_code
      const existingShortCode = await Level.findOne({ where: { short_code } });
      if (existingShortCode) {
        return res.status(400).json({ error: 'short_code already exists' });
      }

      // Check for existing amount
      const existingAmount = await Level.findOne({ where: { amount } });
      if (existingAmount) {
        return res.status(400).json({ error: 'amount already exists' });
      }

      // Create using BaseController's create
      return super.create(req, res);
    } catch (error) {
      console.error('Level creation error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Custom update with validation (override BaseController)
  async update(req, res) {
    try {
      const { id } = req.params;
      const { short_code, amount } = req.body;

      console.log("updateupdate", id, short_code, amount);

      // Check for existing short_code excluding current record
      if (short_code) {
        const existingShortCode = await Level.findOne({
          where: {
            short_code,
            id: { [sequelize.Op.ne]: id }
          }
        });
        if (existingShortCode) {
          return res.status(400).json({ error: 'short_code already exists' });
        }
      }

      // Check for existing amount excluding current record
      if (amount) {
        const existingAmount = await Level.findOne({
          where: {
            amount,
            id: { [sequelize.Op.ne]: id }
          }
        });
        if (existingAmount) {
          return res.status(400).json({ error: 'amount already exists' });
        }
      }

      // Update using BaseController's update
      return super.update(req, res);
    } catch (error) {
      console.error('Level update error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Inherited methods (explicitly listed for clarity)
  async findAll(req, res) {
    return super.findAll(req, res);
  }

  async findById(req, res) {
    return super.findById(req, res);
  }

  async delete(req, res) {
    return super.delete(req, res);
  }
}

module.exports = new LevelController();