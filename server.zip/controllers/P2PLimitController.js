const BaseController = require('./BaseController');
const { P2PLimit, sequelize } = require('../models'); // Import the model
const sequelizee = require('sequelize');

class P2PLimitController extends BaseController {
    constructor() {
        super(P2PLimit);
        console.log('P2PLimitController initialized');
    }

    // Custom create with validation (and Transaction)
    async create(req, res) {
        let transaction;
        try {
            transaction = await sequelize.transaction(); // Start a transaction

            const { min_amount, max_amount, min_price, max_price } = req.body;

            // Validate input
            if (!min_amount || !max_amount || !min_price || !max_price) {
                return res.status(400).json({ error: 'min_amount, max_amount, min_price, and max_price are required' });
            }

            // Check if min_amount and max_amount are valid numbers
            if (isNaN(parseFloat(min_amount)) || !isFinite(min_amount)) {
                return res.status(400).json({ error: 'min_amount must be a valid number' });
            }
            if (isNaN(parseFloat(max_amount)) || !isFinite(max_amount)) {
                return res.status(400).json({ error: 'max_amount must be a valid number' });
            }

            if (parseFloat(min_amount) >= parseFloat(max_amount)) {
                return res.status(400).json({ error: 'min_amount must be less than max_amount' });
            }

            if (isNaN(parseFloat(min_price)) || !isFinite(min_price)) {
                return res.status(400).json({ error: 'min_price must be a valid number' });
            }
            if (isNaN(parseFloat(max_price)) || !isFinite(max_price)) {
                return res.status(400).json({ error: 'max_price must be a valid number' });
            }

            if (parseFloat(min_price) >= parseFloat(max_price)) {
                return res.status(400).json({ error: 'min_price must be less than max_price' });
            }

            // Create using BaseController's create (with transaction)
            const item = await this.model.create(req.body, { transaction });

            await transaction.commit(); // Commit the transaction if everything is successful
            return res.status(201).json(item);

        } catch (error) {
            if (transaction) {
                await transaction.rollback(); // Rollback the transaction if any error occurs
            }
            console.error('P2PLimit creation error:', error);
            res.status(500).json({ error: error.message });
        }
    }

    // Custom update with validation (and explicit field definition and Transaction)
    async update(req, res) {
        let transaction;
        try {
            transaction = await sequelize.transaction(); // Start a transaction

            const { id } = req.params;
            const { min_amount, max_amount, min_price, max_price } = req.body;

            // Check if min_amount and max_amount are valid numbers (if they are being updated)
            if (min_amount && (isNaN(parseFloat(min_amount)) || !isFinite(min_amount))) {
                return res.status(400).json({ error: 'min_amount must be a valid number' });
            }
            if (max_amount && (isNaN(parseFloat(max_amount)) || !isFinite(max_amount))) {
                return res.status(400).json({ error: 'max_amount must be a valid number' });
            }


             // Validate input
             if (min_amount && max_amount && parseFloat(min_amount) >= parseFloat(max_amount)) {
                return res.status(400).json({ error: 'min_amount must be less than max_amount' });
            }

            if (min_price && (isNaN(parseFloat(min_price)) || !isFinite(min_price))) {
                return res.status(400).json({ error: 'min_price must be a valid number' });
            }
            if (max_price && (isNaN(parseFloat(max_price)) || !isFinite(max_price))) {
                return res.status(400).json({ error: 'max_price must be a valid number' });
            }

            if (min_price && max_price && parseFloat(min_price) >= parseFloat(max_price)) {
                return res.status(400).json({ error: 'min_price must be less than max_price' });
            }

            // Build the update object, only including allowed fields
            const updateData = {};
            if (min_amount) {
                updateData.min_amount = min_amount;
            }
            if (max_amount) {
                updateData.max_amount = max_amount;
            }
            if (min_price) {
                updateData.min_price = min_price;
            }
            if (max_price) {
                updateData.max_price = max_price;
            }

            const [updated] = await this.model.update(updateData, {
                where: { id: req.params.id },
                transaction // Use the transaction
            });

            if (updated) {
                const updatedItem = await this.model.findByPk(req.params.id, {
                    transaction // Use the transaction
                });
                await transaction.commit(); // Commit the transaction
                return res.status(200).json(updatedItem);
            } else {
                await transaction.rollback(); // Rollback the transaction
                return res.status(404).json({ error: 'P2PLimit not found' });
            }

        } catch (error) {
            if (transaction) {
                await transaction.rollback(); // Rollback the transaction if any error occurs
            }
            console.error('P2PLimit update error:', error);
            res.status(500).json({ error: error.message });
        }
    }

    // Inherited methods (explicitly listed for clarity)
    async findAll(req, res) {
        return super.findAll(req, res);
    }

    async delete(req, res) {
        return super.delete(req, res);
    }
}

module.exports = new P2PLimitController();