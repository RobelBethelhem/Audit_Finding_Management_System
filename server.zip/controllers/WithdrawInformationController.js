const BaseController = require('./BaseController');
const { WithdrawInformation, User, AuditLog, AccountLockHistory } = require('../models');
const bcrypt = require('bcrypt');
const { Op } = require('sequelize');

class WithdrawInformationController extends BaseController {
  constructor() {
    super(WithdrawInformation);
    console.log('WithdrawInformationController initialized');
    this.LOCKOUT_DURATION = 6 * 60 * 60 * 1000;
    this.MAX_ATTEMPTS = 3;
  }


   // Helper method for audit logging
   async logAction(userId, actionType, details = null) {
    await AuditLog.create({
      user_id: userId,
      action_type: actionType,
      details
    });
  }

   // Helper method to check and handle lockout
   async checkLockoutStatus(user) {
    if (user.lockout_until && user.lockout_until > new Date()) {
      return true; // Still locked out
    }

    // Reset lockout if expired
    if (user.status === 'LockeOut' && user.lockout_until <= new Date()) {
      await user.update({
        status: 'Active',
        failed_attempts: 0,
        lockout_until: null
      });
    }
    return false;
  }



  // Custom create with password validation
  async create(req, res) {
    try {
      const { user_id, withdraw_password, confirm_withdraw_password } = req.body;

      // Validate required fields
      if (!user_id || !withdraw_password || !confirm_withdraw_password) {
        return res.status(400).json({ 
          error: 'user_id, withdraw_password, and confirm_withdraw_password are required' 
        });
      }

      // Check if passwords match
      if (withdraw_password !== confirm_withdraw_password) {
        return res.status(400).json({ 
          error: 'Withdraw password and confirmation do not match' 
        });
      }

      // Check if user exists
      const user = await User.findByPk(user_id);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Check if user already has withdraw info
      const existingWithdrawInfo = await WithdrawInformation.findOne({
        where: { user_id }
      });

      if (existingWithdrawInfo) {
        return res.status(400).json({ 
          error: 'Withdraw information already exists for this user' 
        });
      }

      // Hash withdraw password
      const hashedPassword = await bcrypt.hash(withdraw_password, 10);

      // Create with hashed password
      const newWithdrawInfo = await WithdrawInformation.create({
        user_id,
        withdraw_password: hashedPassword
      });

      res.status(201).json({
        id: newWithdrawInfo.id,
        user_id: newWithdrawInfo.user_id,
        created_at: newWithdrawInfo.createdAt
      });

    } catch (error) {
      console.error('Withdraw info creation error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Custom update with password validation
  async update(req, res) {
    try {
      const id  = req.user.id;
      const { old_withdraw_password, new_withdraw_password, confirm_new_withdraw_password } = req.body;

      // Validate required fields
      if (!old_withdraw_password || !new_withdraw_password || !confirm_new_withdraw_password) {
        return res.status(400).json({ 
          error: 'old_withdraw_password, new_withdraw_password, and confirm_new_withdraw_password are required' 
        });
      }

       // Get withdraw info and associated user
       const withdrawInfo = await WithdrawInformation.findOne({
        where: {user_id: id},
        include: [
          {
            model: User,
            include: [
                        {
                            model: AccountLockHistory 
                        }
                    ]
          }
        ]
      });

      console.log('Withdraw info foundWithdraw info foundWithdraw info foundWithdraw info foundWithdraw info foundWithdraw info foundWithdraw info foundWithdraw info foundWithdraw info foundWithdraw info foundWithdraw info foundWithdraw info found:', withdrawInfo);

      if (!withdrawInfo || !withdrawInfo.User) {
        return res.status(404).json({ error: 'Withdraw information not found' });
      }

      const user = withdrawInfo.User;

       // Check lockout status
        const isLockedOut = await this.checkLockoutStatus(user);
        if (isLockedOut) {
        return res.status(403).json({
            error: `Account locked until ${user.lockout_until}. Try again later.`
        });
        }

    

      // Check if new passwords match
      if (new_withdraw_password !== confirm_new_withdraw_password) {
        return res.status(400).json({ 
          error: 'New password and confirmation do not match' 
        });
      }


      // Verify old password
      const isValid = await bcrypt.compare(old_withdraw_password, withdrawInfo.withdraw_password);

     
      if (!isValid) {
        // Increment failed attempts
       
        const newAttempts = user.failed_attempts + 1;
        const updateData = { failed_attempts: newAttempts };

        if (newAttempts >= this.MAX_ATTEMPTS) {

             // Store previous status
        await AccountLockHistory.create({
            user_id: user.id,
            previous_status: user.status
        });

          updateData.status = 'LockeOut';
          updateData.lockout_until = new Date(Date.now() + this.LOCKOUT_DURATION);
        }

        await user.update(updateData);

        return res.status(401).json({
          error: `Invalid old password. Remaining attempts: ${this.MAX_ATTEMPTS - newAttempts}`,
          remaining_attempts: this.MAX_ATTEMPTS - newAttempts
        });
      }

      // Prepare update data
      const updateData = {
        failed_attempts: 0,
        lockout_until: null
      };


       // Restore original status if account was locked
    if (user.status === 'LockeOut') {
        const latestLockHistory = await AccountLockHistory.findOne({
          where: { user_id: user.id },
          order: [['createdAt', 'DESC']]
        });
  
        if (latestLockHistory) {
          updateData.status = latestLockHistory.previous_status;
          await latestLockHistory.destroy();
        } else {
          // Fallback to Inactive if no history found
          updateData.status = 'Inactive';
        }
      }

       // Update user status
    await user.update(updateData);

      // Hash new password
      const hashedPassword = await bcrypt.hash(new_withdraw_password, 10);

      // Update password
      await WithdrawInformation.update(
        { withdraw_password: hashedPassword },
        { where: { user_id: id } }
      );

        // Audit log
        await this.logAction(user.id, 'WITHDRAW_PASSWORD_CHANGE', {
            changed_at: new Date(),
            ip_address: req.ip
          });


      const updatedInfo = await WithdrawInformation.findOne({
        where: { user_id: id },
      });
      return res.status(200).json({
        id: updatedInfo.id,
        user_id: updatedInfo.user_id,
        updated_at: updatedInfo.updatedAt
      });

     

    } catch (error) {
      console.error('Withdraw info update error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Find by user ID
  async findByUserId(req, res) {
    try {
      const { userId } = req.params;
      const withdrawInfo = await WithdrawInformation.findOne({
        where: { user_id: userId },
        include: [
          {
            model: User,
            attributes: ['id', 'username']
          }
        ]
      });

      if (!withdrawInfo) {
        return res.status(404).json({ error: 'No withdraw information found for this user' });
      }

      // Sanitize response - don't return password hash
      const response = {
        id: withdrawInfo.id,
        user_id: withdrawInfo.user_id,
        user: withdrawInfo.User,
        created_at: withdrawInfo.createdAt,
        updated_at: withdrawInfo.updatedAt
      };

      res.status(200).json(response);

    } catch (error) {
      console.error('Find by user ID error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Inherited methods
  async findAll(req, res) {
    return super.findAll(req, res);
  }

  async findById(req, res) {
    return super.findById(req, res);
  }

  async delete(req, res) {
    return super.delete(req, res);
  }
}

module.exports = new WithdrawInformationController();