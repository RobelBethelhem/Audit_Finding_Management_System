const BaseController = require('./BaseController');
const { 
  CashWithdrawHistory,
  UserBalance,
  WithdrawInformation,
  User,
  PaymentInformation,
  AccountLockHistory,
  AdminUser,
  BankAccountConfiguration,
  AccountNumberBalance,
  AccountNumberTransactionHistory,
} = require('../models');
const Decimal = require('decimal.js');
const bcrypt = require('bcrypt');
const { sequelize } = require('../models');
const { Op } = require('sequelize');

class CashWithdrawController extends BaseController {
  constructor() {
    super(CashWithdrawHistory);
    this.MIN_WITHDRAW_AMOUNT = new Decimal(100);
    this.LOCKOUT_DURATION = 6 * 60 * 60 * 1000;
    this.MAX_ATTEMPTS = 3;
  }

  async create(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const user_id = req.user.id;
      const { withdraw_password, amount, payment_information_id } = req.body;
      req.body.user_id = user_id;

      // Validate input
      if (!user_id || !withdraw_password || !amount || !payment_information_id) {
        return res.status(400).json({
          error: 'user_id, withdraw_password, amount, and payment_information_id are required'
        });
      }

      // Validate amount
      let withdrawAmount;
      try {
        withdrawAmount = new Decimal(amount);
        if (withdrawAmount.lessThan(this.MIN_WITHDRAW_AMOUNT)) {
          return res.status(400).json({
            error: `Minimum withdrawal amount is ${this.MIN_WITHDRAW_AMOUNT}`
          });
        }
      } catch (error) {
        return res.status(400).json({ error: 'Invalid amount format' });
      }

      // Check payment information exists and belongs to user
      const paymentInfo = await PaymentInformation.findOne({
        where: {
          id: payment_information_id,
          user_id: user_id
        },
        transaction
      });

      if (!paymentInfo) {
        return res.status(400).json({
          error: 'Payment information not found. Please configure your bank account first.'
        });
      }

      // Check withdraw information exists
      const withdrawInfo = await WithdrawInformation.findOne({
        where: { user_id },
        include: [{
          model: User,
          include: [AccountLockHistory]
        }],
        transaction
      });

      if (!withdrawInfo) {
        return res.status(400).json({
          error: 'Withdraw information not configured. Please set up withdraw password first.'
        });
      }

      const user = withdrawInfo.User;

      // Check lockout status
      const isLockedOut = await this.checkLockoutStatus(user);
      if (isLockedOut) {
        return res.status(403).json({
          error: `Account locked until ${user.lockout_until}. Try again later.`
        });
      }

      // Verify withdraw password
      const isValid = await bcrypt.compare(withdraw_password, withdrawInfo.withdraw_password);
      if (!isValid) {
        // Handle failed attempts
        const newAttempts = user.failed_attempts + 1;
        const updateData = { failed_attempts: newAttempts };

        if (newAttempts >= this.MAX_ATTEMPTS) {
          await AccountLockHistory.create({
            user_id: user.id,
            previous_status: user.status
          }, { transaction });

          updateData.status = 'LockeOut';
          updateData.lockout_until = new Date(Date.now() + this.LOCKOUT_DURATION);
        }

        await user.update(updateData, { transaction });

        return res.status(401).json({
          error: `Invalid password. Remaining attempts: ${this.MAX_ATTEMPTS - newAttempts}`,
          remaining_attempts: this.MAX_ATTEMPTS - newAttempts
        });
      }

      // Check user balance
      const userBalance = await UserBalance.findOne({ where: { user_id }, transaction });
      if (!userBalance) {
        return res.status(400).json({ error: 'User balance not found' });
      }

      // Calculate available balance
      const totalFirst = new Decimal(userBalance.total_first_node_balance);
      const totalSecond = new Decimal(userBalance.total_second_node_balance);
      const totalThird = new Decimal(userBalance.total_third_balance);
      const totalWithdrawn = new Decimal(userBalance.withdraw_up_to_date);
      const p2pCredit = new Decimal(userBalance.p2p_credit);
      const p2pDebit = new Decimal(userBalance.p2p_debit);
      const pointSellingCredit = new Decimal(userBalance.point_selling_credit);

      const availableBalance = totalFirst.plus(totalSecond)
        .plus(totalThird)
        .plus(pointSellingCredit)
        .plus(p2pCredit)
        .minus(p2pDebit)
        .minus(totalWithdrawn);

      if (availableBalance.lessThan(withdrawAmount)) {
        return res.status(400).json({ error: 'Insufficient funds' });
      }

      // Assign a specific bank account with sufficient balance
    const bankAccount = await this.assignBankAccountForWithdrawal(withdrawAmount.toNumber(), transaction);
    if (!bankAccount) {
      return res.status(400).json({
        error: 'No bank account with sufficient balance to handle this withdrawal'
      });
    }

      // Update user balance
      const newWithdrawnAmount = totalWithdrawn.plus(withdrawAmount);
      await UserBalance.update({
        withdraw_up_to_date: newWithdrawnAmount.toNumber(),
        current_balance: availableBalance.minus(withdrawAmount).toNumber()
      }, {
        where: { user_id },
        transaction
      });

      // Create withdrawal history with assigned admin
      const withdrawal = await CashWithdrawHistory.create({
        user_id,
        payment_information_id,
        amount: withdrawAmount.toNumber(),
        status: 'Pending',
        bank_account_configuration_id: bankAccount.id,
        assigned_to: bankAccount.Manager.id
      }, { transaction });

      // Reset failed attempts on success
      await user.update({
        failed_attempts: 0,
        lockout_until: null
      }, { transaction });

      await transaction.commit();

      res.status(201).json({
        message: 'Withdrawal request submitted',
        withdrawal_id: withdrawal.id,
        current_balance: availableBalance.minus(withdrawAmount).toNumber(),
        bank_details: {
          bank_name: paymentInfo.bank_name,
          account_number: paymentInfo.account_number
        }
      });

    } catch (error) {
      await transaction.rollback();
      console.error('Withdrawal error:', error);
      res.status(500).json({ error: error.message });
    }
  }


  async assignBankAccountForWithdrawal(amount, transaction) {
    const bankAccount = await BankAccountConfiguration.findOne({
      include: [{
        model: AccountNumberBalance,
        as: 'AccountNumberBalance',
        where: { account_balance: { [Op.gte]: amount } }},
        {
          model: AdminUser,
          as: 'Manager',
        }
     ],
      transaction
    });
    return bankAccount;
  }




  async updateStatus(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { id } = req.params;
      const admin_user_idd = req.user.id;
      req.body.admin_user_id = admin_user_idd;

      console.log("yyyyyyyyyyyyyyyyyyyyyyyyyyy", req.body);

      const { status , reference_number, admin_user_id} = req.body;

      // Validate inputs
      if (!status || !admin_user_id) {
        return res.status(400).json({ error: 'status and admin_user_id are required' });
      }

      // Validate status
      if (!['Approved', 'Rejected'].includes(status)) {
        return res.status(400).json({ error: 'Invalid status. Allowed values: Approved, Rejected' });
      }

      // Find withdrawal with associated data
      const withdrawal = await CashWithdrawHistory.findOne({
        where: { id },
        include: [
          { model: PaymentInformation, attributes: ['user_id'] },
          { 
            model: BankAccountConfiguration, 
            include: [{model:AccountNumberBalance, as: 'AccountNumberBalance'}] 
          }
        ],
        transaction
      });

     

      if (!withdrawal) {
        return res.status(404).json({ error: 'Withdrawal not found' });
      }

      // Validate status transition
      if (withdrawal.status !== 'Pending') {
        return res.status(400).json({ 
          error: `Cannot modify already ${withdrawal.status.toLowerCase()} withdrawal` 
        });
      }

      // Verify the admin_user_id matches the bank account's managed_by
      const bankAccount = withdrawal.bank_account_configuration;
      if (!bankAccount) {
        return res.status(400).json({ error: 'No bank account associated with this withdrawal' });
      }

      if (bankAccount.managed_by !== admin_user_id) {
        return res.status(403).json({ 
          error: 'You are not authorized to update this withdrawal. Only the assigned admin can perform this action.' 
        });
      }

    

      const withdrawalAmount = new Decimal(withdrawal.amount);
      const user_id = withdrawal.PaymentInformation.user_id;

      if(status === 'Approved'){
        if (!reference_number) {
          return res.status(400).json({ error: 'Reference number is required for approval' });
        }


        
        const accountBalanceRecord = bankAccount.AccountNumberBalance;
        if (!accountBalanceRecord) {
          return res.status(400).json({ error: 'Account balance record not found' });
        }
       
        const accountBalance = new Decimal(accountBalanceRecord.account_balance);

        if (accountBalance.lessThan(withdrawalAmount)) {
          return res.status(400).json({ error: 'Insufficient funds in the bank account' });
        }

        // Debit the bank account balance
        const newBalance = accountBalance.minus(withdrawalAmount);
        await accountBalanceRecord.update(
          { account_balance: newBalance.toNumber() },
          { transaction }
        );

        // Record the transaction
        await AccountNumberTransactionHistory.create({
          bank_account_configuration_id: bankAccount.id,
          transaction_amount: withdrawalAmount.toNumber(),
          transaction_type: 'Debit',
          admin_transaction_done_by: admin_user_id,
          status: 'Approved',
          checked_by: admin_user_id,
        }, { transaction });



        // Update withdrawal with reference number and status
      await withdrawal.update({ status, reference_number }, { transaction });

      }

      // Get user balance
      // const userBalance = await UserBalance.findOne({ 
      //   where: { user_id },
      //   transaction
      // });

      // if (!userBalance && !withdrawal.reason === 'Give_up') {
      //   return res.status(400).json({ error: 'User balance not found' });
      // }

      // let newCurrentBalance;


      else if (status === 'Rejected') {
        // Reverse the initial withdrawal deduction from user balance
        const userBalance = await UserBalance.findOne({ where: { user_id }, transaction });
        if (!userBalance && withdrawal.reason !== 'Give_up') {
          return res.status(400).json({ error: 'User balance not found' });
        }

        if (withdrawal.reason === 'Give_up') {
          return res.status(400).json({ error: 'Give_up cannot be rejected' });
        }

        const currentWithdrawn = new Decimal(userBalance.withdraw_up_to_date);
        const newWithdrawn = currentWithdrawn.minus(withdrawalAmount);

        const totalFirst = new Decimal(userBalance.total_first_node_balance);
        const totalSecond = new Decimal(userBalance.total_second_node_balance);
        const totalThird = new Decimal(userBalance.total_third_balance);
        const p2pDebit = new Decimal(userBalance.p2p_debit);
        const p2pCredit = new Decimal(userBalance.p2p_credit);
        const pointSellingCredit = new Decimal(userBalance.point_selling_credit);

        const newCurrentBalance = totalFirst.plus(totalSecond)
          .plus(totalThird)
          .minus(p2pDebit)
          .plus(p2pCredit)
          .minus(newWithdrawn)
          .plus(pointSellingCredit);

        await UserBalance.update({
          withdraw_up_to_date: newWithdrawn.toNumber(),
          current_balance: newCurrentBalance.toNumber()
        }, { where: { user_id }, transaction });

        // Update withdrawal status
        await withdrawal.update({ status }, { transaction });
      }

      await transaction.commit();

      res.status(200).json({
        message: `Withdrawal ${status.toLowerCase()} successfully`,
        withdrawal_id: id,
        new_status: status,
        ...(status === 'Approved' && { reference_number }),
        ...(status === 'Rejected' && { 
          current_balance: newCurrentBalance ? newCurrentBalance.toNumber() : null,
          refunded_amount: withdrawal.amount
        })
      });

    } catch (error) {
      await transaction.rollback();
      console.error('Withdrawal status update error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async checkLockoutStatus(user) {
    if (user.lockout_until && user.lockout_until > new Date()) {
      return true;
    }

    // Reset lockout if expired
    if (user.status === 'LockeOut' && user.lockout_until <= new Date()) {
      await user.update({
        status: 'Active',
        failed_attempts: 0,
        lockout_until: null
      });
    }
    return false;
  }

  async getUserWithdrawals(req, res) {
    try {
        const { user_id } = req.params;

        // Check if user exists
        const user = await User.findByPk(user_id);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Get all payment information for the user
        const paymentInfos = await PaymentInformation.findAll({
            where: { user_id },
            attributes: ['id']
        });

        // Extract payment information IDs
        const paymentInfoIds = paymentInfos.map(pi => pi.id);

        // Get withdrawal history with payment details
        const withdrawals = await CashWithdrawHistory.findAll({
            where: {
                payment_information_id: paymentInfoIds
            },
            include: [{
                model: PaymentInformation,
                attributes: ['bank_name', 'account_number']
            }],
            order: [['createdAt', 'DESC']]
        });

        res.status(200).json({
            user_id,
            withdrawal_count: withdrawals.length,
            withdrawals: withdrawals.map(w => ({
                id: w.id,
                amount: w.amount,
                status: w.status,
                created_at: w.createdAt,
                updated_at: w.updatedAt,
                bank_details: {
                    bank_name: w.PaymentInformation.bank_name,
                    account_number: w.PaymentInformation.account_number
                }
            }))
        });

    } catch (error) {
        console.error('Get withdrawals error:', error);
        res.status(500).json({ error: error.message });
    }
}



async findAll(req, res) {
  try {
    let { page = 1, limit = 10, sort = 'createdAt', order = 'DESC', ...filters } = req.query;

    page = parseInt(page, 10);
    limit = parseInt(limit, 10);

    if (isNaN(page) || page < 1) page = 1;
    if (isNaN(limit) || limit < 1) limit = 10;

    const offset = (page - 1) * limit;

    // Build where clause for filtering
    const whereClause = {};
    for (const key in filters) {
      if (filters.hasOwnProperty(key)) {
        whereClause[key] = filters[key]; // Add direct equality filtering
        // If you need more complex operators (like `like`, `gt`, etc.), adjust accordingly.
      }
    }

    const { count, rows } = await CashWithdrawHistory.findAndCountAll({
      where: whereClause,
      order: [[sort, order]],
      offset: offset,
      limit: limit,
      include: [
        {
          model: User,
          attributes: ['username'] // Include username from User
        },
        {
          model: AdminUser,
          as: 'AssignedAdmin', // Alias as defined in associations
          attributes: ['username'] // Include username from AdminUser
        },
        {
          model: PaymentInformation,
          attributes: ['bank_name', 'account_number', 'bank_name'] // Include bank details
        },
        {
          model: BankAccountConfiguration,
          attributes: ['bank_name', 'account_number', 'account_holder_name']
        },

      ]
    });

    const totalPages = Math.ceil(count / limit);


    console.log("rowsrowsrowsrowsrowsrows", rows);

    const response = {
      items: rows.map(withdrawInfo => {
        const plainWithdrawInfo = withdrawInfo.get({ plain: true });
        const { withdraw_password, ...safeWithdrawInfo } = plainWithdrawInfo; // Sanitize password

        return {
          id: safeWithdrawInfo.id,
          amount: safeWithdrawInfo.amount,
          reason: safeWithdrawInfo.reason,
          withdraw_date: safeWithdrawInfo.withdraw_date,
          status: safeWithdrawInfo.status,
          reference_number: safeWithdrawInfo.reference_number,
          createdAt: safeWithdrawInfo.createdAt,
          updatedAt: safeWithdrawInfo.updatedAt,
          username: withdrawInfo.User?.username || null, // Get username from included User
          assigned_admin_username: withdrawInfo.AssignedAdmin?.username || null, // Get username from included AdminUser
          bank_name: withdrawInfo.PaymentInformation?.bank_name || null, // Get bank_name from PaymentInformation
          account_number: withdrawInfo.PaymentInformation?.account_number || null, // Get account_number from PaymentInformation
          account_holder_name: withdrawInfo.PaymentInformation?.bank_name || null, // Get account_holder_name from PaymentInformation
          assigned_bank_name: withdrawInfo.bank_account_configuration.bank_name || null,
          assigned_account_number: withdrawInfo.bank_account_configuration.account_number || null,
          assigned_account_holder_name: withdrawInfo.bank_account_configuration.account_holder_name || null,
        };
      }),
      pagination: {
        currentPage: page,
        totalPages: totalPages,
        totalItems: count,
        itemsPerPage: limit
      }
    };

    res.status(200).json(response);
  } catch (error) {
    console.error('Error in findAll:', error);
    res.status(500).json({ error: error.message });
  }
}









}

module.exports = new CashWithdrawController();