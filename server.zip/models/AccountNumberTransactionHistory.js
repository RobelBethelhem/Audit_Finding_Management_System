const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const AccountNumberTransactionHistory = sequelize.define('account_number_transaction_histories', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    bank_account_configuration_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    transaction_amount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false
    },
    transaction_type: {
      type: DataTypes.ENUM('Credit', 'Debit'),
      allowNull: false,
      defaultValue: 'Debit'
    },
    admin_transaction_done_by: {
      type: DataTypes.UUID,
      allowNull: true // References AdminUser
    },
    user_transaction_done_by: {
      type: DataTypes.UUID,
      allowNull: true // References User
    },
    status: {
      type: DataTypes.ENUM('Approved', 'Rejected', 'Pending'),
      allowNull: false,
      defaultValue: 'Pending'
    },
    transaction_reference: { // Added field for tracking
      type: DataTypes.STRING,
      allowNull: true
    },
    checked_by: {
      type: DataTypes.UUID,
      allowNull: true // References AdminUser
    }
  }, {
    tableName: 'account_number_transaction_histories',
    timestamps: true,
    indexes: [
      {
        name: 'idx_account_number_transaction_history',
        fields: ['id', 'bank_account_configuration_id', 'checked_by', 'status', 'admin_transaction_done_by', 'user_transaction_done_by']
      }
    ]
  });

  return AccountNumberTransactionHistory;
};