const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const PointConfiguration = sequelize.define('point_configuration', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    level_id: {
      type: DataTypes.UUID,
      allowNull: false
    },

    amount: {
      type: DataTypes.INTEGER,
      allowNull: false
    }
  }, {
    tableName: 'point_configuration',
    timestamps: true
  });

  return PointConfiguration;
};