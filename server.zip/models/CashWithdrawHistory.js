const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const CashWithdrawHistory = sequelize.define('CashWithdrawHistory', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    payment_information_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    amount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
      validate: {
        min: {
          args: [100.00],
          msg: 'Amount must be at least 100.00' 
        }
      }
    },
    withdraw_date: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW
    },
    status: {
      type: DataTypes.ENUM('Pending', 'Approved', 'Rejected'),
      defaultValue: 'Pending'
    },
    reason: {
      type: DataTypes.ENUM('Give_up', 'Withdraw'),
      defaultValue: 'Withdraw'
    },
    assigned_to: {
      type: DataTypes.UUID,
      allowNull: true
    },
    reference_number: {
      type: DataTypes.STRING,
      allowNull: true
    },
    bank_account_configuration_id: {
      type: DataTypes.UUID,
      allowNull: false
    }

  }, {
    tableName: 'cash_withdraw_histories',
    timestamps: true
  });

  return CashWithdrawHistory;
};