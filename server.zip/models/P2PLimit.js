
const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const P2PLimit = sequelize.define('p2_p_limit', {
        id: {
            type: DataTypes.UUID,
            primaryKey: true,
            defaultValue: () => uuidv4()
        },
        min_amount: {
            type: DataTypes.DECIMAL(10, 2),
            allowNull: false
        },
        max_amount: {
            type: DataTypes.DECIMAL(10, 2),
            allowNull: false
        },
        min_price: {
            type: DataTypes.DECIMAL(10, 2),
            allowNull: false
        },
        max_price: {
            type: DataTypes.DECIMAL(10, 2),
            allowNull: false
        },
   
  }, {
    tableName: 'p2_p_limit',
    timestamps: true,
    indexes: [
      {
        fields: ['id', 'min_amount', 'max_amount'],
        name: 'idx_p2p_limit'
      }
    ]
  });

  return P2PLimit;
};

