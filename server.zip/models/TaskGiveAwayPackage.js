const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const TaskGiveAwayPackage = sequelize.define('task_give_away_package', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    level_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    active_days: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        min: 1
      }
    },

    refferal_limit: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        min: 1
      }
    },

    status: {
      type: DataTypes.ENUM('Active', 'Inactive'),
      defaultValue: 'Active'
    }
  
  }, {
    tableName: 'task_give_away_package',
    timestamps: true,
    indexes: [
      {
        fields: ['id', 'level_id']
      }
    ]
  });

  return TaskGiveAwayPackage;
};