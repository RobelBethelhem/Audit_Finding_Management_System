const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
    const PaidChildrenLimit = sequelize.define('paid_children_limits', {
      id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: () => uuidv4()
      },
      first_generation_limit: {
        type: DataTypes.INTEGER,
        allowNull: false
      },
      second_generation_limit: {
          type: DataTypes.INTEGER,
          allowNull: false
      },
      third_generation_limit: {
          type: DataTypes.INTEGER,
          allowNull: false
      },
     
    }, {
      tableName: 'paid_children_limits',
      timestamps: true
    });
  
    return PaidChildrenLimit;
  };

