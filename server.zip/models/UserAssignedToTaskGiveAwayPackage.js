const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const UserAssignedToTaskGiveAwayPackage = sequelize.define('user_assigned_to_task_give_away_package', {
    id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: () => uuidv4()
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    task_give_away_package_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    start_date: {
      type: DataTypes.DATE,
      allowNull: false,
    },
  }, {
    tableName: 'user_assigned_to_task_give_away_package',
    timestamps: true,
    indexes: [
      {
        name: 'idx_user_assigned_task_give_away',
        fields: ['id', 'task_give_away_package_id', 'user_id'],
      },
    ],
  });

  return UserAssignedToTaskGiveAwayPackage;
};