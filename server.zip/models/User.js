const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define('User', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    username: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false
    },
    parent_user_id: {
      type: DataTypes.UUID,
      allowNull: true
    },
    level_id: {
      type: DataTypes.UUID,
      allowNull: true
    },
    failed_attempts: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
    },
    lockout_until: {
      type: DataTypes.DATE,
      allowNull: true
    },
    status: {
      type: DataTypes.ENUM('Active', 'Inactive', 'Give_up', 'LockeOut'),
      defaultValue: 'Inactive'
    },
    
  }, {
    tableName: 'users',
    timestamps: true
  });

  return User;
};