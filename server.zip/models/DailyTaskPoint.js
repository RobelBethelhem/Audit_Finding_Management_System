
const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const DailyTaskPoint = sequelize.define('daily_task_points', {
    id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: () => uuidv4()
    },
    daily_task_id: {
        type: DataTypes.UUID,
        allowNull: false
      },
    points: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    },
   
  }, {
    tableName: 'daily_task_points',
    timestamps: true,
    indexes: [
      {
        fields: ['id', 'daily_task_id']
      }
    ]
  });

  return DailyTaskPoint;
};
