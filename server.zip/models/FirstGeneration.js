const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const FirstGeneration = sequelize.define('FirstGeneration', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    referral_users: {
      type: DataTypes.JSON, 
      validate: {
        isArray(value) {
          if (!Array.isArray(value)) {
            throw new Error('Referral users must be an array');
          }
        }
      }, 
      defaultValue: []
    },
    paid_referral_users: {
        type: DataTypes.JSON,
        defaultValue: [],
        validate: {
          isArray(value) {
                if (!Array.isArray(value)) {
                  throw new Error('Referral users must be an array');
                }
              },
          maxPaidReferrals(value) {
            if (value && value.length > 10) {
              throw new Error('Maximum 10 paid referral users allowed');
            }
          }
        }
      }
  }, {
    tableName: 'first_generations',
    timestamps: true
  });

  return FirstGeneration;
};