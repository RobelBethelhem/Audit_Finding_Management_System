const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const SystemSellTaskPackage = sequelize.define('system_sell_task_package', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    package_name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    value: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        min: 1
      }
    },

    refferal_limit: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        min: 1
      }
    },

    status: {
        type: DataTypes.ENUM('Active', 'Inactive'),
        defaultValue: 'Active'
      }
  
  }, {
    tableName: 'system_sell_task_package',
    timestamps: true,
    indexes: [
        {
          fields: ['id', 'package_name']
        }
      ]
  });

  return SystemSellTaskPackage;
};