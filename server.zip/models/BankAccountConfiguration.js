const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
    const BankAccountConfiguration = sequelize.define('bank_account_configurations', {
        id: {
            type: DataTypes.UUID,
            primaryKey: true,
            defaultValue: () => uuidv4()
          },
          bank_name: {
            type: DataTypes.STRING,
            allowNull: false
          },
          account_number: {
            type: DataTypes.STRING,
            allowNull: false
          },
          account_holder_name: {
              type: DataTypes.STRING,
              allowNull: false
            },
          managed_by: {
              type: DataTypes.UUID,
              allowNull: true
          },
        
    }, {
      tableName: 'bank_account_configurations',
      timestamps: true
    });
  
    return BankAccountConfiguration;
  };
