const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const UserTaskHistory = sequelize.define('user_task_history', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    reffered_user_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    user_assigned_to_system_sell_task_package_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('Pending', 'Accepted'),
      allowNull: false,
      defaultValue: 'Pending'
    },
    date: {
      type: DataTypes.DATE,
      allowNull: false
    },

  }, {
    tableName: 'user_task_history',
    timestamps: true,
    indexes: [
      {
        name: 'idx_user_task_history',
        fields: ['id', 'reffered_user_id', 'user_assigned_to_system_sell_task_package_id']
      }
    ]
  });

  return UserTaskHistory;
};