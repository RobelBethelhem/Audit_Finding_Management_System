const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const AmountRangeConfiguration = sequelize.define('amount_range_configurations', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    bank_account_configuration_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    minimum_amount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false
    },
    maximum_amount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false
    }
  }, {
    tableName: 'amount_range_configurations',
    timestamps: true,
    indexes: [
      {
        fields: ['bank_account_configuration_id']
      }
    ]
  });

  return AmountRangeConfiguration;
};