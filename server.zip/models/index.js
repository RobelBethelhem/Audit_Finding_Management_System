const { Sequelize, DataTypes } = require('sequelize');
const config = require('../config/database');

// Initialize Sequelize
const sequelize = new Sequelize(config.development);

// Import models
const User = require('./User')(sequelize, DataTypes);
const Level = require('./Level')(sequelize, DataTypes);
const WithdrawInformation = require('./WithdrawInformation')(sequelize, DataTypes);
const PaymentInformation = require('./PaymentInformation')(sequelize, DataTypes);
const CashWithdrawHistory = require('./CashWithdrawHistory')(sequelize, DataTypes);
const UserBalance = require('./UserBalance')(sequelize, DataTypes);
const FirstGeneration = require('./FirstGeneration')(sequelize, DataTypes);
const SecondGeneration = require('./SecondGeneration')(sequelize, DataTypes);
const ThirdGeneration = require('./ThirdGeneration')(sequelize, DataTypes);
const VerifyDeposit = require('./VerifyDeposit')(sequelize, DataTypes);
const ParentUser = require('./ParentUser')(sequelize, DataTypes);
const AccountLockHistory = require('./AccountLockHistory')(sequelize, DataTypes);
const AuditLog = require('./AuditLog')(sequelize, DataTypes);
const PaidChildrenLimit = require('./PaidChildrenLimit')(sequelize, DataTypes);
const AdminUser = require('./AdminUser')(sequelize, DataTypes);
const AmountRangeConfiguration = require('./AmountRangeConfiguration')(sequelize, DataTypes);
const BankAccountConfiguration = require('./BankAccountConfiguration')(sequelize, DataTypes);
const AccountNumberBalance = require('./AccountNumberBalance')(sequelize, DataTypes);
const AccountNumberTransactionHistory = require('./AccountNumberTransactionHistory')(sequelize, DataTypes);
const GLAccount = require('./GLAccount')(sequelize, DataTypes);
const GLAccountHistory = require('./GLAccountHistory')(sequelize, DataTypes);
const CategoryForInvesting = require('./CategoryForInvesting')(sequelize, DataTypes);
const DailyTaskConfiguration = require('./DailyTaskConfiguration')(sequelize, DataTypes);
const DailyTaskGame = require('./DailyTaskGame')(sequelize, DataTypes);
const DailyTaskPoint = require('./DailyTaskPoint')(sequelize, DataTypes);
const UserPointBalance = require('./UserPointBalance')(sequelize, DataTypes);
const P2PPoints = require('./P2PPoints')(sequelize, DataTypes);
const Configuration = require('./Configuration')(sequelize, DataTypes);
const PointConfiguration = require('./PointConfiguration')(sequelize, DataTypes);
const TaskGiveAwayPackage = require('./TaskGiveAwayPackage')(sequelize, DataTypes);
const UserAssignedToTaskGiveAwayPackage = require('./UserAssignedToTaskGiveAwayPackage')(sequelize, DataTypes);
const UserTaskHistory = require('./UserTaskHistory')(sequelize, DataTypes);
const UserAssignedToSystemSellTaskPackage = require('./UserAssignedToSystemSellTaskPackage')(sequelize, DataTypes);
const SystemSellTaskPackage = require('./SystemSellTaskPackage')(sequelize, DataTypes);
const P2PLimit = require('./P2PLimit')(sequelize, DataTypes);
const P2PSellBuyConfiguration = require('./P2PSellBuyConfiguration')(sequelize, DataTypes);
const UserGiveAwayHistory = require('./UserGiveAwayHistory')(sequelize, DataTypes);

// Define associations
function setupAssociations() {
  // User relationships
  User.belongsTo(Level, { foreignKey: 'level_id' });
  Level.hasMany(User, { foreignKey: 'level_id' });
  
  User.belongsTo(User, { foreignKey: 'parent_user_id', as: 'ParentUser' });
  User.hasMany(User, { foreignKey: 'parent_user_id', as: 'Children' });



  P2PSellBuyConfiguration.belongsTo(Level, { foreignKey: 'level_id', as: 'Level' });
  Level.hasOne(P2PSellBuyConfiguration, { foreignKey: 'level_id', as: 'P2PSellBuyConfiguration' });


  TaskGiveAwayPackage.belongsTo(Level, { foreignKey: 'level_id', as: 'Level' });
  Level.hasOne(TaskGiveAwayPackage, { foreignKey: 'level_id', as: 'TaskGiveAwayPackage' });


  // User Assigned to Task Give Away Package relationships
  UserAssignedToTaskGiveAwayPackage.belongsTo(TaskGiveAwayPackage, { foreignKey: 'task_give_away_package_id', as: 'TaskGiveAwayPackage' });
  TaskGiveAwayPackage.hasMany(UserAssignedToTaskGiveAwayPackage, { foreignKey: 'task_give_away_package_id', as: 'AssignedUsers' });

  UserAssignedToTaskGiveAwayPackage.belongsTo(User, { foreignKey: 'user_id', as: 'User' });
  User.hasOne(UserAssignedToTaskGiveAwayPackage, { foreignKey: 'user_id', as: 'AssignedTaskGiveAwayPackages' });

 

  UserAssignedToSystemSellTaskPackage.belongsTo(SystemSellTaskPackage, { foreignKey: 'system_sell_task_package_id', as: 'SystemSellTaskPackage' });
  SystemSellTaskPackage.hasMany(UserAssignedToSystemSellTaskPackage, { foreignKey: 'system_sell_task_package_id', as: 'AssignedUsers' });

  UserAssignedToSystemSellTaskPackage.belongsTo(User, { foreignKey: 'user_id', as: 'User' });
  User.hasMany(UserAssignedToSystemSellTaskPackage, { foreignKey: 'user_id', as: 'AssignedSystemSellTaskPackages' });

  // User Task History relationships
  UserTaskHistory.belongsTo(User, { foreignKey: 'reffered_user_id', as: 'RefferedUser' });
  User.hasMany(UserTaskHistory, { foreignKey: 'reffered_user_id', as: 'UserTaskHistories' });

  UserTaskHistory.belongsTo(UserAssignedToSystemSellTaskPackage, { foreignKey: 'user_assigned_to_system_sell_task_package_id', as: 'UserAssignedToSystemSellTaskPackage' });
  UserAssignedToSystemSellTaskPackage.hasMany(UserTaskHistory, { foreignKey: 'user_assigned_to_system_sell_task_package_id', as: 'UserTaskHistories' });
  


  UserGiveAwayHistory.belongsTo(User, { foreignKey: 'reffered_user_id', as: 'RefferedUser' });
  User.hasMany(UserGiveAwayHistory, { foreignKey: 'reffered_user_id', as: 'UserGiveAwayHistories' });

  UserGiveAwayHistory.belongsTo(UserAssignedToTaskGiveAwayPackage, { foreignKey: 'user_assigned_to_task_give_away_package_id', as: 'UserAssignedToTaskGiveAwayPackage' });
  UserAssignedToTaskGiveAwayPackage.hasMany(UserGiveAwayHistory, { foreignKey: 'user_assigned_to_task_give_away_package_id', as: 'UserGiveAwayHistories' });


  // Withdraw Information
  WithdrawInformation.belongsTo(User, { foreignKey: 'user_id' });
  User.hasOne(WithdrawInformation, { foreignKey: 'user_id' });

  // Payment Information
  PaymentInformation.belongsTo(User, { foreignKey: 'user_id' });
  User.hasOne(PaymentInformation, { foreignKey: 'user_id' });

  // Cash Withdraw History
  CashWithdrawHistory.belongsTo(PaymentInformation, { foreignKey: 'payment_information_id' });
  PaymentInformation.hasMany(CashWithdrawHistory, { foreignKey: 'payment_information_id' });



  CashWithdrawHistory.belongsTo(BankAccountConfiguration, { foreignKey: 'bank_account_configuration_id' });
  BankAccountConfiguration.hasMany(CashWithdrawHistory, { foreignKey: 'bank_account_configuration_id' });

  // User Balance
  UserBalance.belongsTo(User, { foreignKey: 'user_id' });
  User.hasOne(UserBalance, { foreignKey: 'user_id' });

  // Cash Withdraw History
  CashWithdrawHistory.belongsTo(User, { foreignKey: 'user_id' });
  User.hasMany(CashWithdrawHistory, { foreignKey: 'user_id' });

  CashWithdrawHistory.belongsTo(AdminUser, { foreignKey: 'assigned_to', as: 'AssignedAdmin' });
  AdminUser.hasMany(CashWithdrawHistory, { foreignKey: 'assigned_to', as: 'AssignedWithdraws' });

  // Verify Deposit
  VerifyDeposit.belongsTo(User, { foreignKey: 'user_id' });
  User.hasMany(VerifyDeposit, { foreignKey: 'user_id' });

  VerifyDeposit.belongsTo(BankAccountConfiguration, { foreignKey: 'bank_account_configuration_id' });
  BankAccountConfiguration.hasMany(VerifyDeposit, { foreignKey: 'bank_account_configuration_id' });

  VerifyDeposit.belongsTo(AdminUser, { foreignKey: 'approved_by', as: 'Approver' });
  AdminUser.hasMany(VerifyDeposit, { foreignKey: 'approved_by', as: 'ApprovedDeposits' });



  // Parent User (alternative relationship mapping)
  ParentUser.belongsTo(User, { foreignKey: 'user_id', as: 'Child' });
  User.hasOne(ParentUser, { foreignKey: 'user_id' });
  ParentUser.belongsTo(User, { foreignKey: 'parent_user_id', as: 'Parent' });

  // Account Lock History
  AccountLockHistory.belongsTo(User, { foreignKey: 'user_id' });
  User.hasMany(AccountLockHistory, { foreignKey: 'user_id' });

  // Audit Log
  AuditLog.belongsTo(User, { foreignKey: 'user_id' });
  User.hasMany(AuditLog, { foreignKey: 'user_id' });

  // Generation relationships
  FirstGeneration.belongsTo(User, { foreignKey: 'user_id', as: 'PrimaryUser' });
  User.hasOne(FirstGeneration, { foreignKey: 'user_id' });

  SecondGeneration.belongsTo(User, { foreignKey: 'user_id', as: 'PrimaryUser' });
  User.hasOne(SecondGeneration, { foreignKey: 'user_id' });
  
  ThirdGeneration.belongsTo(User, { foreignKey: 'user_id', as: 'PrimaryUser' });
  User.hasOne(ThirdGeneration, { foreignKey: 'user_id' });

  // Admin User relationships
     //AmountRangeConfiguration.belongsTo(AdminUser, { foreignKey: 'admin_user_id' });
     //AdminUser.hasMany(AmountRangeConfiguration, { foreignKey: 'admin_user_id' });
     
  AmountRangeConfiguration.belongsTo(BankAccountConfiguration, { foreignKey: 'bank_account_configuration_id' });
  BankAccountConfiguration.hasOne(AmountRangeConfiguration, { foreignKey: 'bank_account_configuration_id' });

  AccountNumberBalance.belongsTo(BankAccountConfiguration, { foreignKey: 'bank_account_configuration_id', as: 'BankAccountConfiguration' });
  BankAccountConfiguration.hasOne(AccountNumberBalance, { foreignKey: 'bank_account_configuration_id', as: 'AccountNumberBalance' });

  // Bank Account Configuration relationships
  BankAccountConfiguration.belongsTo(AdminUser, { foreignKey: 'managed_by', as: 'Manager' });
  AdminUser.hasMany(BankAccountConfiguration, { foreignKey: 'managed_by', as: 'ManagedAccounts' });

  // Account Number Transaction History relationships
  AccountNumberTransactionHistory.belongsTo(BankAccountConfiguration, { foreignKey: 'bank_account_configuration_id', as: 'BankAccountConfiguration', });
  BankAccountConfiguration.hasMany(AccountNumberTransactionHistory, { foreignKey: 'bank_account_configuration_id', as: 'AccountNumberTransactionHistories', });
  

  AccountNumberTransactionHistory.belongsTo(AccountNumberBalance, { foreignKey: 'bank_account_configuration_id', as: 'AccountNumberBalance' });
  AccountNumberBalance.hasMany(AccountNumberTransactionHistory, { foreignKey: 'bank_account_configuration_id', as: 'AccountNumberTransactionHistories' });

  AccountNumberTransactionHistory.belongsTo(AdminUser, { foreignKey: 'admin_transaction_done_by', as: 'AdminInitiator' });
  AdminUser.hasMany(AccountNumberTransactionHistory, { foreignKey: 'admin_transaction_done_by', as: 'AdminInitiatedTransactions' });

  AccountNumberTransactionHistory.belongsTo(User, { foreignKey: 'user_transaction_done_by', as: 'UserInitiator' });
  User.hasMany(AccountNumberTransactionHistory, { foreignKey: 'user_transaction_done_by', as: 'UserInitiatedTransactions' });

  
  AccountNumberTransactionHistory.belongsTo(AdminUser, { foreignKey: 'checked_by', as: 'TransactionChecker' });
  AdminUser.hasMany(AccountNumberTransactionHistory, { foreignKey: 'checked_by', as: 'CheckedTransactions' });

  // GL Account History relationships
  GLAccountHistory.belongsTo(GLAccount, { foreignKey: 'gl_account_id',as: 'GLAccount'  });
  GLAccount.hasMany(GLAccountHistory, { foreignKey: 'gl_account_id' });
  
  GLAccountHistory.belongsTo(CategoryForInvesting, { foreignKey: 'category_id', as: 'Category' });
  CategoryForInvesting.hasMany(GLAccountHistory, { foreignKey: 'category_id', as: 'GLTransactions' });
  
  GLAccountHistory.belongsTo(AdminUser, { foreignKey: 'transaction_done_by', as: 'TransactionInitiator' });
  AdminUser.hasMany(GLAccountHistory, { foreignKey: 'transaction_done_by', as: 'InitiatedGLTransactions' });
  
  GLAccountHistory.belongsTo(AdminUser, { foreignKey: 'checked_by', as: 'TransactionChecker' });
  AdminUser.hasMany(GLAccountHistory, { foreignKey: 'checked_by', as: 'CheckedGLTransactions' });

  // Daily Task Game relationships
  DailyTaskGame.belongsTo(DailyTaskConfiguration, { foreignKey: 'daily_task_id' });
  DailyTaskConfiguration.hasMany(DailyTaskGame, { foreignKey: 'daily_task_id' });

  // Daily Task Point relationships
  DailyTaskPoint.belongsTo(DailyTaskConfiguration, { foreignKey: 'daily_task_id' });
  DailyTaskConfiguration.hasMany(DailyTaskPoint, { foreignKey: 'daily_task_id' });

  // User Point Balance
  UserPointBalance.belongsTo(User, { foreignKey: 'user_id' });
  User.hasOne(UserPointBalance, { foreignKey: 'user_id' });


  // P2P Points relationships
  P2PPoints.belongsTo(User, { foreignKey: 'seller_id', as: 'Seller' });
  User.hasMany(P2PPoints, { foreignKey: 'seller_id', as: 'SellingPoints' });
   
  P2PPoints.belongsTo(User, { foreignKey: 'buyer_id', as: 'Buyer' });
  User.hasMany(P2PPoints, { foreignKey: 'buyer_id', as: 'PurchasedPoints' });

  // Point Configuration
  PointConfiguration.belongsTo(Level, { foreignKey: 'level_id' });
  Level.hasOne(PointConfiguration, { foreignKey: 'level_id' });
}

// Setup associations
setupAssociations();



module.exports = {
  sequelize,
  Sequelize,
  User,
  Level,
  WithdrawInformation,
  PaymentInformation,
  CashWithdrawHistory,
  UserBalance,
  FirstGeneration,
  SecondGeneration,
  ThirdGeneration,
  VerifyDeposit,
  ParentUser,
  AccountLockHistory,
  AuditLog,
  PaidChildrenLimit,
  AdminUser,
  AmountRangeConfiguration,
  BankAccountConfiguration,
  AccountNumberBalance,
  AccountNumberTransactionHistory,
  GLAccount,
  GLAccountHistory,
  CategoryForInvesting,
  DailyTaskConfiguration,
  DailyTaskGame, 
  DailyTaskPoint,
  UserPointBalance,
  P2PPoints,
  Configuration,
  PointConfiguration,
  UserAssignedToTaskGiveAwayPackage,
  TaskGiveAwayPackage,
  SystemSellTaskPackage,
  UserAssignedToSystemSellTaskPackage,
  UserTaskHistory,
  P2PLimit,
  P2PSellBuyConfiguration,
  UserGiveAwayHistory
};