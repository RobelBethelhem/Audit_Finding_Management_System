module.exports = {
    up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('system_sell_task_package', {
        id: {
          type: Sequelize.UUID,
          primaryKey: true,
          defaultValue: Sequelize.UUIDV4
        },
        package_name: {
          type: Sequelize.STRING,
          allowNull: false
        },
        value: {
          type: Sequelize.INTEGER,
          allowNull: false,
          validate: {
            min: 1
          }
        },
        refferal_limit: {
          type: Sequelize.INTEGER,
          allowNull: false,
          validate: {
            min: 1
          }
        },
        status: {
          type: Sequelize.ENUM('Active', 'Inactive'),
          defaultValue: 'Active'
        },
        createdAt: {
          type: Sequelize.DATE,
          allowNull: false
        },
        updatedAt: {
          type: Sequelize.DATE,
          allowNull: false
        }
      });
  
      await queryInterface.addIndex('system_sell_task_package', ['id', 'package_name']);
    },
    down: async (queryInterface) => {
      await queryInterface.dropTable('system_sell_task_package');
    }
  };