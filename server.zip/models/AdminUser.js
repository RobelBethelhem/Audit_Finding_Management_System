const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const AdminUser = sequelize.define('admin_users', {
    id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: () => uuidv4()
      },
      username: {
        type: DataTypes.STRING,
        allowNull: false
      },
      password: {
        type: DataTypes.STRING,
        allowNull: false
      },
      failed_attempts: {
          type: DataTypes.INTEGER,
          defaultValue: 0,
        },
        email: {
          type: DataTypes.STRING,
          allowNull: false
        },
      lockout_until: {
          type: DataTypes.DATE,
          allowNull: true
        },
      status: {
      type: DataTypes.ENUM('Active', 'Inactive',  'LockeOut'),
      defaultValue: 'Inactive'
      },
    
  }, {
    tableName: 'admin_users',
    timestamps: true
  });

  return AdminUser;
};
