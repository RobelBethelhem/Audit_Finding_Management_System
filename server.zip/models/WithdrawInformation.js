const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const WithdrawInformation = sequelize.define('WithdrawInformation', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    withdraw_password: {
      type: DataTypes.STRING,
      allowNull: false
    }
  }, {
    tableName: 'withdraw_informations',
    timestamps: true
  });

  return WithdrawInformation;
};