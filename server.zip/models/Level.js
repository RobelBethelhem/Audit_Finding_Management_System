const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const Level = sequelize.define('Level', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    percentage: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            min: 0,
            max: 100
        }
    },
    short_code: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        len: [2, 10]
      }
    },
    amount: {
      type: DataTypes.DECIMAL(10, 2),
      unique: true,
      allowNull: false,
      validate: {
        isDecimal: true,
        min: 0
      }
    }
  }, {
    tableName: 'levels',
    timestamps: true
  });

  return Level;
};