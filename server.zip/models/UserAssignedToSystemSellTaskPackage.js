const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const UserAssignedToSystemSellTaskPackage = sequelize.define('user_assigned_to_system_sell_task_package', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    system_sell_task_package_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    start_date: {
      type: DataTypes.DATE,
      allowNull: false
    },

  }, {
    tableName: 'user_assigned_to_system_sell_task_package',
    timestamps: true,
    indexes: [
        {
          name: 'user_assigned_task_pkg_idx', // Shortened index name
          fields: ['id', 'system_sell_task_package_id', 'user_id']
        }
    ]
  });

  return UserAssignedToSystemSellTaskPackage;
};