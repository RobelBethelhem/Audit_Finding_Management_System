
const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const AccountLockHistory = sequelize.define('account_lock_histories', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    previous_status: {
      type: DataTypes.ENUM('Active', 'Inactive', 'Give_up', 'LockeOut'),
      allowNull: false
    }
  }, {
    tableName: 'account_lock_histories',
    timestamps: true,
    indexes: [
      {
        fields: ['user_id']
      }
    ]
  });

  return AccountLockHistory;
};