
const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const GLAccount = sequelize.define('gl_accounts', {
    id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: () => uuidv4()
      },
      account_number: {
        type: DataTypes.STRING,
        allowNull: false
      },
      available_balance: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
      },
      gl_account_type: {
        type: DataTypes.ENUM('Debit', 'Credit'),
        defaultValue: 'Debit'
      },
    
  }, {
    tableName: 'gl_accounts',
    timestamps: true,
    indexes: [
      {
        fields: ['id', 'account_number', 'gl_account_type', 'available_balance']
      }
    ]
  });

  return GLAccount;
};

