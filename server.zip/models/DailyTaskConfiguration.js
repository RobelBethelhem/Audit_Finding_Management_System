
const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const DailyTaskConfiguration = sequelize.define('daily_task_configurations', {
    id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: () => uuidv4()
    },
    task_name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    description: {
        type: DataTypes.TEXT,
        allowNull: false
    },
  }, {
    tableName: 'daily_task_configurations',
    timestamps: true,
    indexes: [
      {
        fields: ['id', 'task_name']
      }
    ]
  });

  return DailyTaskConfiguration;
};
