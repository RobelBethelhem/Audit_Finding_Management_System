// const { DataTypes } = require('sequelize');
// const sequelize = require('./sequelize-config'); // Your Sequelize connection instance (configure this!)

// const Configuration = sequelize.define('Configuration', {
//   configKey: {
//     type: DataTypes.STRING,
//     allowNull: false,
//     unique: true,
//   },
//   configValue: {
//     type: DataTypes.TEXT,
//     allowNull: true, 
//   },
//   category: {
//     type: DataTypes.STRING,
//     allowNull: true,
//   },
//   description: {
//     type: DataTypes.TEXT,
//     allowNull: true,
//   },
// }, {
//   tableName: 'Configurations', 
//   timestamps: true,
//   indexes: [
//     {
//       fields: ['configKey']
//     }
//   ]
// });

// module.exports = Configuration;


const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const Configuration = sequelize.define('Configuration', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    configKey: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    configValue: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    category: {
      type: DataTypes.STRING,
      allowNull: true
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'Configurations',
    timestamps: true,
    indexes: [
      {
        fields: ['configKey']
      }
    ]
  });

  return Configuration;
};