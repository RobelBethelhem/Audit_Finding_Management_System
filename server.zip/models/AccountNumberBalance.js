
const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const AccountNumberBalance = sequelize.define('account_number_balances', {
    id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: () => uuidv4()
      },
      bank_account_configuration_id: {
        type: DataTypes.UUID,
        allowNull: false
      },
      account_balance: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
      },
  }, {
    tableName: 'account_number_balances',
    timestamps: true,
    indexes: [
      {
        name: 'idx_account_number_balance', 
        fields:['id', 'bank_account_configuration_id', 'account_balance']
      }
    ]
  });

  return AccountNumberBalance;
};
