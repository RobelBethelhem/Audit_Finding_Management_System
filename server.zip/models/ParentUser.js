const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const ParentUser = sequelize.define('ParentUser', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    parent_user_id: {
      type: DataTypes.UUID,
      allowNull: true
    },
    
  }, {
    tableName: 'parent_users',
    timestamps: true
  });

  return ParentUser;
};