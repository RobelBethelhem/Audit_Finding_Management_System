
const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const P2PPoints = sequelize.define('p2_p_points', {
        id: {
            type: DataTypes.UUID,
            primaryKey: true,
            defaultValue: () => uuidv4()
        },
     seller_id: {
        type: DataTypes.UUID,
        allowNull: false
      },
      buyer_id: {
        type: DataTypes.UUID,
        allowNull: true
      },
      number_of_points: {
          type: DataTypes.INTEGER,
          allowNull: false,
      },

      unit_price: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false,
        defaultValue: 1.00
      },

      Total_amount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false,
        defaultValue: 1.00
      },
      status: {
        type: DataTypes.ENUM('Pending', 'Approved', 'Rejected'),
        allowNull: false,
        defaultValue: 'Pending'
      },
   
  }, {
    tableName: 'p2_p_points',
    timestamps: true,
    indexes: [
      {
        fields: ['id', 'seller_id', 'buyer_id']
      }
    ]
  });

  return P2PPoints;
};

