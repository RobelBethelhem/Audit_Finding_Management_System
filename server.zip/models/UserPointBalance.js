
const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const UserPointBalance = sequelize.define('user_point_balance', {
    id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: () => uuidv4()
    },
    user_id: {
        type: DataTypes.UUID,
        allowNull: false
      },
    points: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    },
   
  }, {
    tableName: 'user_point_balance',
    timestamps: true,
    indexes: [
      {
        fields: ['id', 'user_id']
      }
    ]
  });

  return UserPointBalance;
};
