const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const VerifyDeposit = sequelize.define('VerifyDeposit', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    bank_account_configuration_id: {
      type: DataTypes.UUID,
      allowNull: false 
    },
    balance: {
      type: DataTypes.DECIMAL(10, 2), 
      allowNull: false
    },
    transaction_id: {
      type: DataTypes.STRING,
      allowNull: true
    },
    payment_receipt: {
      type: DataTypes.BLOB('long'),
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('Pending', 'Accepted', 'Rejected'),
      defaultValue: 'Pending'
    },
    approved_by: {
      type: DataTypes.UUID,
      allowNull: true 
    }
  }, {
    tableName: 'verify_deposits',
    timestamps: true
  });

  return VerifyDeposit;
};