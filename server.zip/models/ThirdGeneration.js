const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const ThirdGeneration = sequelize.define('ThirdGeneration', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    referral_users: {
      type: DataTypes.JSON,
      validate: {
        isArray(value) {
          if (!Array.isArray(value)) {
            throw new Error('Referral users must be an array');
          }
        }
      },
      defaultValue: []
    },
    paid_referral_users: {
        type: DataTypes.JSON,
        defaultValue: [],
        validate: {
            isArray(value) {
                if (!Array.isArray(value)) {
                  throw new Error('Referral users must be an array');
                }
              },
          maxPaidReferrals(value) {
            if (value && value.length > 30) {
              throw new Error('Maximum 30 paid referral users allowed');
            }
          }
        }
      }
  }, {
    tableName: 'third_generations',
    timestamps: true
  });

  return ThirdGeneration;
};