const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const PaymentInformation = sequelize.define('PaymentInformation', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    bank_name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    account_number: {
      type: DataTypes.STRING,
      allowNull: false
    }
  }, {
    tableName: 'payment_informations',
    timestamps: true
  });

  return PaymentInformation;
};