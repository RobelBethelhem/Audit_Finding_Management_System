const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const GLAccountHistory = sequelize.define('gl_account_histories', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    gl_account_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    
    category_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    transaction_amount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false
    },
    transaction_type: {
      type: DataTypes.ENUM('Credit', 'Debit'),
      allowNull: false,
      defaultValue: 'Debit'
    },
    transaction_done_by: {
      type: DataTypes.UUID,
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('Approved', 'Rejected', 'Pending'),
      allowNull: false,
      defaultValue: 'Pending'
    },
    checked_by: {
      type: DataTypes.UUID,
      allowNull: true
    },
    transaction_reference: { // Added field for tracking
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'gl_account_histories',
    timestamps: true,
    indexes: [
      {
        name: 'idx_gl_account_history',
        fields: ['id', 'gl_account_id', 'checked_by', 'status', 'transaction_done_by', 'transaction_reference']
      }
    ]
  });

  return GLAccountHistory;
};