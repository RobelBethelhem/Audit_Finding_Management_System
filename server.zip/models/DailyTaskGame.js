
const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const DailyTaskGame = sequelize.define('daily_task_games', {
    id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: () => uuidv4()
    },
    daily_task_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    value: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    isExpired: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false
    },
   
  }, {
    tableName: 'daily_task_games',
    timestamps: true,
    indexes: [
      {
        fields: ['id', 'daily_task_id']
      }
    ]
  });

  return DailyTaskGame;
};
