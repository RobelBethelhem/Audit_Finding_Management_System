
const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const P2PSellBuyConfiguration = sequelize.define('p2_p_sell_buy_configuration', {
        id: {
            type: DataTypes.UUID,
            primaryKey: true,
            defaultValue: () => uuidv4()
        },
        level_id: {
            type: DataTypes.UUID,
            allowNull: false
        },
        buy_limit: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        sell_limit: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
   
  }, {
    tableName: 'p2_p_sell_buy_configuration',
    timestamps: true,
    indexes: [
      {
        fields: ['id', 'level_id']
      }
    ]
  });

  return P2PSellBuyConfiguration;
};

