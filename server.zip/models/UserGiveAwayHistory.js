const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const UserGiveAwayHistory = sequelize.define('user_give_away_history', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: () => uuidv4()
    },
    reffered_user_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    user_assigned_to_task_give_away_package_id: {
      type: DataTypes.UUID,
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('Pending', 'Accepted'),
      allowNull: false,
      defaultValue: 'Pending'
    },
    date: {
      type: DataTypes.DATE,
      allowNull: false
    },

  }, {
    tableName: 'user_give_away_history',
    timestamps: true,
    indexes: [
      {
        name: 'idx_user_give_away_history',
        fields: ['id', 'reffered_user_id', 'user_assigned_to_task_give_away_package_id']
      }
    ]
  }
);

  return UserGiveAwayHistory;
};