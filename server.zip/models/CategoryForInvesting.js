const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const CategoryForInvesting = sequelize.define('categories_for_for_investing', {
    id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: () => uuidv4()
      },
      category_name: {
        type: DataTypes.STRING,
        allowNull: false
      },
      purpose: {
          type: DataTypes.STRING,
          allowNull: false
        },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false
      }
  }, {
    tableName: 'categories_for_for_investing',
    timestamps: true,
    indexes: [
        {
        fields: ['id', 'category_name']
        }
    ]
  });

  return CategoryForInvesting;
};
