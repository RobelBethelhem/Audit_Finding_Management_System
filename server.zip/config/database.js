// require('dotenv').config();

// module.exports = {
//   development: {
//     dialect: 'mysql',
//     host: 'localhost',
//     port: 3306,
//     username: 'root',
//     password: '',
//     database: 'billinore_db',
//     pool: {
//       max: 50,
//       min: 10,
//       idle: 30000,
//       acquire: 30000,
//       evict: 1800000,
//     },
//   }
// };

require('dotenv').config();

module.exports = {
  development: {
    dialect: 'mysql',
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 3306,
    username: process.env.DB_USER || 'movacash_movacashproduction',
    password: process.env.DB_PASSWORD || 'movacash_movacashproduction',
    database: process.env.DB_NAME || 'movacashproduction',
    pool: {
      max: 50,
      min: 10,
      idle: 30000,
      acquire: 30000,
      evict: 1800000,
    },
  }
};