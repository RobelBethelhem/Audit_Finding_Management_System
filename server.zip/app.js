// const express = require('express');
// const dotenv = require('dotenv');
// const { sequelize } = require('./models');

// // Import routes
// const userRoutes = require('./routes/userRoutes');
// const adminRoutes = require('./routes/adminRoutes');
// const levelRoutes = require('./routes/levelRoutes');
// const withdrawInfoRoutes = require('./routes/withdrawInfoRoutes');
// const paymentInfoRoutes = require('./routes/paymentInfoRoutes');
// const unlockExpiredAccounts = require('./unLockCronJob');
// const verifyDepositRoutes = require('./routes/verifyDepositRoutes');
// const paidChildrenLimitRoutes = require('./routes/paidChildrenLimitRoutes');
// const userBalanceRoutes = require('./routes/userBalanceRoutes');
// const cashWithdrawRoutes = require('./routes/cashWithdrawRoutes');
// const passport = require('passport');
// const LocalStrategy = require('passport-local').Strategy;
// const session = require('express-session');
// const cors = require('cors'); 
// const passportConfig = require('./passportConfiguration');

// const dailyTaskConfigurationRoutes = require('./routes/dailyTaskConfigurationRoutes');
// const dailyTaskGameRoutes = require('./routes/dailyTaskGameRoutes');
// const dailyTaskPointRoutes = require('./routes/dailyTaskPointRoutes');
// const userTaskSubmissionRoutes = require('./routes/userTaskSubmissionRoutes');
// const p2pTradingRoutes = require('./routes/p2pTradingRoutes');
// const bankAccountConfigurationRoutes = require('./routes/bankAccountConfigurationRoutes');
// const amountRangeConfigurationRoutes = require('./routes/amountRangeConfigurationRoutes');
// const glAccountRoutes = require('./routes/glAccountRoutes');
// const glTransactionRoutes = require('./routes/glTransactionRoutes')
// const categoryForInvestingRoutes = require('./routes/categoryForInvestingRoutes')
// const accountNumberTransactionHistoryRoutes = require('./routes/accountNumberTransactionHistoryRoutes');
// const configurationRoutes = require('./routes/configurationRoutes');
// const { loadConfigurationFromDB } =require('./controllers/config-loader');
// //const { UserCanSellCoin, calculateCommission } = require('./functions'); 


// // Import expire games cron job
// const expireAllGames = require('./expireGamesCronJob');


// // const cashWithdrawHistoryRoutes = require('./routes/cashWithdrawHistoryRoutes');


// dotenv.config();


// const app = express();
// const PORT = process.env.PORT || 3000;



// // Middleware
//    //passport configuration
// passportConfig(passport);


// // app.use(cors({
// //   origin: 'http://localhost:4000', // Or your allowed origin
// //   credentials: true,
// // }));


// app.use(cors({
//   origin: ['http://192.168.137.1:4000', 'http://localhost:4000', 'http://192.168.137.1:3000', 'http://192.168.137.1:4500', 'http://localhost:4500'], 
//   credentials: true, 
//   methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
//   allowedHeaders: ['Content-Type', 'Authorization']
// }));


// app.use(express.json());
// app.use(session({ secret: 'first_commission_based_millionare_project_poweredBy_movacash',
//    resave: false,
//    saveUninitialized: true,
//    cookie: {
//     maxAge: 200 * 60 * 1000 
//   }
//    }));
// app.use((req, res, next) => {
// if (req.session && req.session.cookie && req.session.cookie.expires) {
//   if (new Date() > new Date(req.session.cookie.expires)) {
//     req.logout((err) => {
//       if (err) return next(err);
//       return res.status(401).json({ message: 'Session expired' });
//     });
//     return;
//   }
// }
// next();
// });
// app.use(passport.initialize());
// app.use(passport.session());



// // Routes
// app.use('/api/users', userRoutes);
// app.use('/api/admins', adminRoutes);
// app.use('/api/account-number-transaction-history', accountNumberTransactionHistoryRoutes);
// app.use('/api/levels', levelRoutes);
// app.use('/api/withdraw-info', withdrawInfoRoutes);
// app.use('/api/payment-info', paymentInfoRoutes);
// app.use('/api/verify-deposit', verifyDepositRoutes);
// app.use('/api/paid-children-limit', paidChildrenLimitRoutes);
// app.use('/api/user-balance', userBalanceRoutes);
// app.use('/api/withdrawals', cashWithdrawRoutes);

// app.use('/api/daily-task-configurations', dailyTaskConfigurationRoutes);
// app.use('/api/daily-task-games', dailyTaskGameRoutes);
// app.use('/api/daily-task-points', dailyTaskPointRoutes);
// app.use('/api/user-tasks', userTaskSubmissionRoutes);
// app.use('/api/p2p-trading', p2pTradingRoutes);
// app.use('/api/bank-account-configurations', bankAccountConfigurationRoutes);
// app.use('/api/amount-range-configurations', amountRangeConfigurationRoutes);
// app.use('/api/glaccount', glAccountRoutes);
// app.use('/api/gl-transaction', glTransactionRoutes);
// app.use('/api/category-for-investing', categoryForInvestingRoutes)
// app.use('/api/configuration', configurationRoutes);



// // app.use('/api/cash-withdraw-history', cashWithdrawHistoryRoutes);

// // Error handling middleware
// app.use((err, req, res, next) => {
//   console.error(err.stack);
//   res.status(500).send('Something broke!');
// });

// await loadConfigurationFromDB();

// app.listen(PORT, async () => {
//   console.log(`Server running on port ${PORT}`);
//   try {
//     await sequelize.sync();
//     console.log('Database connected successfully');

//     // Start cron job
//     setInterval(unlockExpiredAccounts, 60 * 60 * 1000);
//     console.log('Account unlock cron job started');

//     // Start the game expiration cron job - runs at midnight every day
//     const runGameExpirationJob = async () => {
//       const now = new Date();
//       // Create a date for today at 6:00 AM
//       let next6AM = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 6, 0, 0);
    
//       // If it's already past 6:00 AM today, schedule for tomorrow
//       if (now >= next6AM) {
//         next6AM.setDate(next6AM.getDate() + 1);
//       }
    
//       const msUntil6AM = next6AM.getTime() - now.getTime();
      
//       // Schedule expireAllGames to run at 6:00 AM
//       setTimeout(async () => {
//         await expireAllGames();
//         // Then set an interval to run it every 24 hours at 6:00 AM
//         setInterval(expireAllGames, 24 * 60 * 60 * 1000);
//       }, msUntil6AM);
//     };
    
//     // Start scheduling the game expiration job
//     runGameExpirationJob();
//     console.log('Game expiration cron job scheduled');

//   } catch (error) {
//     console.error('Unable to connect to the database:', error);
//   }
// });


// const express = require('express');
// const dotenv = require('dotenv');
// const { sequelize } = require('./models');

// // Import routes
// const userRoutes = require('./routes/userRoutes');
// const adminRoutes = require('./routes/adminRoutes');
// const levelRoutes = require('./routes/levelRoutes');
// const withdrawInfoRoutes = require('./routes/withdrawInfoRoutes');
// const paymentInfoRoutes = require('./routes/paymentInfoRoutes');
// const unlockExpiredAccounts = require('./unLockCronJob');
// const verifyDepositRoutes = require('./routes/verifyDepositRoutes');
// const paidChildrenLimitRoutes = require('./routes/paidChildrenLimitRoutes');
// const userBalanceRoutes = require('./routes/userBalanceRoutes');
// const cashWithdrawRoutes = require('./routes/cashWithdrawRoutes');
// const passport = require('passport');
// const LocalStrategy = require('passport-local').Strategy;
// const session = require('express-session');
// const cors = require('cors');
// const passportConfig = require('./passportConfiguration');

// const dailyTaskConfigurationRoutes = require('./routes/dailyTaskConfigurationRoutes');
// const dailyTaskGameRoutes = require('./routes/dailyTaskGameRoutes');
// const dailyTaskPointRoutes = require('./routes/dailyTaskPointRoutes');
// const userTaskSubmissionRoutes = require('./routes/userTaskSubmissionRoutes');
// const p2pTradingRoutes = require('./routes/p2pTradingRoutes');
// const bankAccountConfigurationRoutes = require('./routes/bankAccountConfigurationRoutes');
// const amountRangeConfigurationRoutes = require('./routes/amountRangeConfigurationRoutes');
// const glAccountRoutes = require('./routes/glAccountRoutes');
// const glTransactionRoutes = require('./routes/glTransactionRoutes');
// const categoryForInvestingRoutes = require('./routes/categoryForInvestingRoutes');
// const accountNumberTransactionHistoryRoutes = require('./routes/accountNumberTransactionHistoryRoutes');
// const configurationRoutes = require('./routes/configurationRoutes');
// const { loadConfigurationFromDB } = require('./controllers/config-loader');
// const pointConfigurationRoutes = require('./routes/pointConfigurationRoutes');
// //const { UserCanSellCoin, calculateCommission } = require('./functions'); // Assuming functions.js is in controllers


// // Import expire games cron job
// const expireAllGames = require('./expireGamesCronJob');


// // const cashWithdrawHistoryRoutes = require('./routes/cashWithdrawHistoryRoutes');


// dotenv.config();


// const app = express();
// const PORT = process.env.PORT || 3000;


// // Middleware
// //passport configuration
// passportConfig(passport);


// // app.use(cors({
// //   origin: 'http://localhost:4000', // Or your allowed origin
// //   credentials: true,
// // }));


// app.use(cors({
//     origin: ['http://192.168.137.1:4000', 'http://192.168.43.215:4000', 'http://localhost:4000', 'http://192.168.137.1:3000', 'http://192.168.137.1:4500', 'http://localhost:4500'],
//     credentials: true,
//     methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
//     allowedHeaders: ['Content-Type', 'Authorization']
// }));


// app.use(express.json());
// app.use(session({
//     secret: 'first_commission_based_millionare_project_poweredBy_movacash',
//     resave: false,
//     saveUninitialized: true,
//     cookie: {
//         maxAge: 200 * 60 * 1000
//     }
// }));
// app.use((req, res, next) => {
//     if (req.session && req.session.cookie && req.session.cookie.expires) {
//         if (new Date() > new Date(req.session.cookie.expires)) {
//             req.logout((err) => {
//                 if (err) return next(err);
//                 return res.status(401).json({ message: 'Session expired' });
//             });
//             return;
//         }
//     }
//     next();
// });
// app.use(passport.initialize());
// app.use(passport.session());


// // Routes
// app.use('/api/users', userRoutes);
// app.use('/api/admins', adminRoutes);
// app.use('/api/account-number-transaction-history', accountNumberTransactionHistoryRoutes);
// app.use('/api/levels', levelRoutes);
// app.use('/api/withdraw-info', withdrawInfoRoutes);
// app.use('/api/payment-info', paymentInfoRoutes);
// app.use('/api/verify-deposit', verifyDepositRoutes);
// app.use('/api/paid-children-limit', paidChildrenLimitRoutes);
// app.use('/api/user-balance', userBalanceRoutes);
// app.use('/api/withdrawals', cashWithdrawRoutes);

// app.use('/api/daily-task-configurations', dailyTaskConfigurationRoutes);
// app.use('/api/daily-task-games', dailyTaskGameRoutes);
// app.use('/api/daily-task-points', dailyTaskPointRoutes);
// app.use('/api/user-tasks', userTaskSubmissionRoutes);
// app.use('/api/p2p-trading', p2pTradingRoutes);
// app.use('/api/bank-account-configurations', bankAccountConfigurationRoutes);
// app.use('/api/amount-range-configurations', amountRangeConfigurationRoutes);
// app.use('/api/glaccount', glAccountRoutes);
// app.use('/api/gl-transaction', glTransactionRoutes);
// app.use('/api/category-for-investing', categoryForInvestingRoutes);
// app.use('/api/configuration', configurationRoutes);
// app.use('/api/point-configuration', pointConfigurationRoutes);


// // app.use('/api/cash-withdraw-history', cashWithdrawHistoryRoutes);

// // Error handling middleware
// app.use((err, req, res, next) => {
//     console.error(err.stack);
//     res.status(500).send('Something broke!');
// });


// async function startServer() { // Make startServer async
//     try {
//         await sequelize.authenticate();
//         console.log('Database connection has been established successfully.');
//         await sequelize.sync(); // { force: true } to drop and recreate tables (for development - be careful in production!)
//         await loadConfigurationFromDB(); // Load configuration from DB at startup  <- KEEP IT HERE

//         app.listen(PORT, () => {
//             console.log(`Server running on port ${PORT}`);

//             // Start cron job
//             setInterval(unlockExpiredAccounts, 60 * 60 * 1000);
//             console.log('Account unlock cron job started');

//             // Start the game expiration cron job
//             const runGameExpirationJob = async () => {
//                 const now = new Date();
//                 // Create a date for today at 6:00 AM
//                 let next6AM = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 6, 0, 0);

//                 // If it's already past 6:00 AM today, schedule for tomorrow
//                 if (now >= next6AM) {
//                     next6AM.setDate(next6AM.getDate() + 1);
//                 }

//                 const msUntil6AM = next6AM.getTime() - now.getTime();

//                 // Schedule expireAllGames to run at 6:00 AM
//                 setTimeout(async () => {
//                     await expireAllGames();
//                     // Then set an interval to run it every 24 hours at 6:00 AM
//                     setInterval(expireAllGames, 24 * 60 * 60 * 1000);
//                 }, msUntil6AM);
//             };

//             // Start scheduling the game expiration job
//             runGameExpirationJob();
//             console.log('Game expiration cron job scheduled');

//         });


//     } catch (error) {
//         console.error('Unable to connect to the database or start server:', error);
//     }
// }


// startServer(); // Call the async startServer function





const express = require('express');
const dotenv = require('dotenv');
const { sequelize } = require('./models');

// Import routes
const userRoutes = require('./routes/userRoutes');
const adminRoutes = require('./routes/adminRoutes');
const levelRoutes = require('./routes/levelRoutes');
const withdrawInfoRoutes = require('./routes/withdrawInfoRoutes');
const paymentInfoRoutes = require('./routes/paymentInfoRoutes');
const unlockExpiredAccounts = require('./unLockCronJob');
const verifyDepositRoutes = require('./routes/verifyDepositRoutes');
const paidChildrenLimitRoutes = require('./routes/paidChildrenLimitRoutes');
const userBalanceRoutes = require('./routes/userBalanceRoutes');
const cashWithdrawRoutes = require('./routes/cashWithdrawRoutes');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const session = require('express-session');
const cors = require('cors');
const passportConfig = require('./passportConfiguration');

const dailyTaskConfigurationRoutes = require('./routes/dailyTaskConfigurationRoutes');
const dailyTaskGameRoutes = require('./routes/dailyTaskGameRoutes');
const dailyTaskPointRoutes = require('./routes/dailyTaskPointRoutes');
const userTaskSubmissionRoutes = require('./routes/userTaskSubmissionRoutes');
const p2pTradingRoutes = require('./routes/p2pTradingRoutes');
const bankAccountConfigurationRoutes = require('./routes/bankAccountConfigurationRoutes');
const amountRangeConfigurationRoutes = require('./routes/amountRangeConfigurationRoutes');
const glAccountRoutes = require('./routes/glAccountRoutes');
const glTransactionRoutes = require('./routes/glTransactionRoutes');
const categoryForInvestingRoutes = require('./routes/categoryForInvestingRoutes');
const accountNumberTransactionHistoryRoutes = require('./routes/accountNumberTransactionHistoryRoutes');
const configurationRoutes = require('./routes/configurationRoutes'); // Corrected filename
const { loadConfigurationFromDB } = require('./controllers/config-loader');
const pointConfigurationRoutes = require('./routes/pointConfigurationRoutes');

const taskGiveAwayPackageRoutes = require('./routes/taskGiveAwayPackageRoutes');
const systemSellTaskPackageRoutes = require('./routes/systemSellTaskPackageRoutes');
const userAssignedToTaskGiveAwayPackageRoutes = require('./routes/userAssignedToTaskGiveAwayPackageRoutes');
const userAssignedToSystemSellTaskPackageRoutes = require('./routes/userAssignedToSystemSellTaskPackageRoutes');
const p2pLimitRoutes = require('./routes/p2pLimitRoutes');
const p2pBuySellConfigurationRoutes = require('./routes/p2pBuySellConfigurationRoutes');
const userTaskHistoryRoutes = require('./routes/userTaskHistoryRoutes');
const userGiveAwayHistoryRoutes = require('./routes/userGiveAwayHistoryRoutes');


// Redis imports
const redis = require('redis');
const connectRedis = require('connect-redis'); // Import connect-redis

// Import expire games cron job
const expireAllGames = require('./expireGamesCronJob');
const expireP2PSell = require('./expireP2PSellCronJob');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// ===================================================================
// MIDDLEWARE (CORS FIRST!)
// ===================================================================

app.use(cors({
    origin: true, // Allow all origins (INSECURE - ONLY FOR DEVELOPMENT)
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());

// ===================================================================
// REDIS SETUP
// ===================================================================

// Correct way to create the client with redis v3
let redisClient;
let redisStore;

async function setupRedis() {
    try {
        redisClient = redis.createClient({
            host: process.env.REDIS_HOST || 'localhost',
            port: process.env.REDIS_PORT || 6379,
            // password: process.env.REDIS_PASSWORD  // If you have password uncomment
        });

        redisClient.on('error', (err) => {
            console.log('Redis error: ', err);
        });

        await new Promise((resolve, reject) => {
            redisClient.on('connect', resolve);
            redisClient.on('error', reject);
        });

        console.log('Redis client connected successfully.');

        const RedisStore = connectRedis(session);

        redisStore = new RedisStore({
            client: redisClient,
            prefix: 'myapp:',
        });

        // Initializing session storage
        app.use(session({
            store: redisStore,
            secret: process.env.SESSION_SECRET || 'first_commission_based_millionare_project_poweredBy_movacash',
            resave: false,
            saveUninitialized: false, // Change this to false
            cookie: {
                secure: process.env.NODE_ENV === 'production',
                httpOnly: true,
                maxAge: 200 * 60 * 1000,
                sameSite: 'lax',
            }
        }));
        //SessionStorage done

    } catch (error) {
        console.error('Error connecting to Redis:', error);
        // Handle the error appropriately (e.g., exit the process, use a fallback)
    }
}


// ===================================================================
// START SERVER
// ===================================================================

async function startServer() {
    try {
        await sequelize.authenticate();
        console.log('Database connection has been established successfully.');
        await sequelize.sync(); // { force: true } to drop and recreate tables (for development - be careful in production!)
        await loadConfigurationFromDB(); // Load configuration from DB at startup  <- KEEP IT HERE

        await setupRedis();  // Wait for Redis setup

        passportConfig(passport);

        app.use(passport.initialize());
        app.use(passport.session());

        app.use((req, res, next) => {
            if (req.session && req.session.cookie && req.session.cookie.expires) {
                if (new Date() > new Date(req.session.cookie.expires)) {
                    req.logout((err) => {
                        if (err) return next(err);
                        return res.status(401).json({ message: 'Session expired' });
                    });
                    return;
                }
            }
            next();
        });

        app.listen(PORT, () => {
            console.log(`Server running on port ${PORT}`);

            // Start cron job
            setInterval(unlockExpiredAccounts, 60 * 60 * 1000);
            console.log('Account unlock cron job started');

            // Start the game expiration cron job
            const runGameExpirationJob = async () => {
                const now = new Date();
                // Create a date for today at 6:00 AM
                let next6AM = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 6, 0, 0);

                // If it's already past 6:00 AM today, schedule for tomorrow
                if (now >= next6AM) {
                    next6AM.setDate(next6AM.getDate() + 1);
                }

                const msUntil6AM = next6AM.getTime() - now.getTime();

                // Schedule expireAllGames to run at 6:00 AM
                setTimeout(async () => {
                    await expireAllGames();
                    await expireP2PSell();
                    // Then set an interval to run it every 24 hours at 6:00 AM
                    setInterval(expireAllGames, 24 * 60 * 60 * 1000);
                    setInterval(expireP2PSell, 24 * 60 * 60 * 1000);
                }, msUntil6AM);
            };

            // Start scheduling the game expiration job
            runGameExpirationJob();
            console.log('Game expiration cron job scheduled');

        });
       // ===================================================================
        // ROUTES
        // ===================================================================

       app.use('/api/users', userRoutes);
       app.use('/api/admins', adminRoutes);
       app.use('/api/account-number-transaction-history', accountNumberTransactionHistoryRoutes);
       app.use('/api/levels', levelRoutes);
       app.use('/api/withdraw-info', withdrawInfoRoutes);
       app.use('/api/payment-info', paymentInfoRoutes);
       app.use('/api/verify-deposit', verifyDepositRoutes);
       app.use('/api/paid-children-limit', paidChildrenLimitRoutes);
       app.use('/api/user-balance', userBalanceRoutes);
       app.use('/api/withdrawals', cashWithdrawRoutes);

       app.use('/api/daily-task-configurations', dailyTaskConfigurationRoutes);
       app.use('/api/daily-task-games', dailyTaskGameRoutes);
       app.use('/api/daily-task-points', dailyTaskPointRoutes);
       app.use('/api/user-tasks', userTaskSubmissionRoutes);
       app.use('/api/p2p-trading', p2pTradingRoutes);
       app.use('/api/bank-account-configurations', bankAccountConfigurationRoutes);
       app.use('/api/amount-range-configurations', amountRangeConfigurationRoutes);
       app.use('/api/glaccount', glAccountRoutes);
       app.use('/api/gl-transaction', glTransactionRoutes);
       app.use('/api/category-for-investing', categoryForInvestingRoutes);
       app.use('/api/configuration', configurationRoutes);
       app.use('/api/point-configuration', pointConfigurationRoutes);
       app.use('/api/task-give-away-package', taskGiveAwayPackageRoutes);
       app.use('/api/system-sell-task-package', systemSellTaskPackageRoutes);
       app.use('/api/user-assigned-to-task-give-away-package', userAssignedToTaskGiveAwayPackageRoutes);
       app.use('/api/user-assigned-to-system-sell-task-package', userAssignedToSystemSellTaskPackageRoutes);
       app.use('/api/p2p-limit', p2pLimitRoutes);
       app.use('/api/p2p-buy-sell-configuration', p2pBuySellConfigurationRoutes);
       app.use('/api/user-task-history', userTaskHistoryRoutes);
       app.use('/api/user-give-away-history', userGiveAwayHistoryRoutes);
    


    } catch (error) {
        console.error('Unable to connect to the database or start server:', error);
    }

    // ===================================================================
        // ERROR HANDLING
        // ===================================================================

        app.use((err, req, res, next) => {
            console.error(err.stack);
            res.status(500).send('Something broke!');
        });
}

startServer();